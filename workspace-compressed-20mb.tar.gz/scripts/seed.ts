/**
 * BROSONROADS — database seed.
 * - Upserts the SiteSettings singleton from DEFAULT_SETTINGS.
 * - Replaces content tables with the defaults (only when empty,
 *   or with --reset to force-refresh).
 * - Ensures the AdminUser exists (username + password come from
 *   CLI args or env; nothing is printed or stored in plain text).
 *
 * Usage:
 *   bun scripts/seed.ts [--reset]
 *   ADMIN_USERNAME=... ADMIN_PASSWORD=... bun scripts/seed.ts
 */

import { PrismaClient } from "@prisma/client";
import { randomBytes, scryptSync } from "crypto";

const prisma = new PrismaClient();

async function main() {
  const reset = process.argv.includes("--reset");

  /* ---- import TS defaults via Bun transpile ---- */
  const mod = await import("../src/lib/defaults");
  const {
    DEFAULT_SETTINGS,
    DEFAULT_RIDES,
    DEFAULT_GALLERY,
    DEFAULT_VIDEOS,
    DEFAULT_INSTAGRAM,
    DEFAULT_STORIES,
    DEFAULT_CONTACTS,
  } = mod;

  /* ---- settings singleton ---- */
  const settingsData = {
    ...DEFAULT_SETTINGS,
    contactsJson: JSON.stringify(DEFAULT_CONTACTS),
    aboutLines: undefined as unknown as string,
  };
  const { aboutLines, contacts: _c, ...rest } = settingsData as Record<string, unknown>;
  await prisma.siteSettings.upsert({
    where: { id: "main" },
    update: {},
    create: {
      id: "main",
      ...rest,
      aboutLines: JSON.stringify(DEFAULT_SETTINGS.aboutLines),
    } as never,
  });
  console.log("✓ site settings ready");

  /* ---- rides ---- */
  const rideCount = await prisma.ride.count();
  if (rideCount === 0 || reset) {
    if (reset) await prisma.ride.deleteMany({});
    for (const r of DEFAULT_RIDES) {
      await prisma.ride.upsert({
        where: { slug: r.slug },
        update: {},
        create: {
          slug: r.slug,
          title: r.title,
          location: r.location,
          date: r.date,
          distance: r.distance,
          days: r.days,
          image: r.image,
          alt: r.alt,
          excerpt: r.excerpt,
          description: r.description,
          highlightsJson: JSON.stringify(r.highlights),
          routeJson: JSON.stringify(r.route),
          category: r.category,
          order: r.order,
        },
      });
    }
    console.log(`✓ rides seeded (${DEFAULT_RIDES.length})`);
  } else {
    console.log(`• rides already present (${rideCount}) — skipped`);
  }

  /* ---- gallery ---- */
  const gCount = await prisma.galleryImage.count();
  if (gCount === 0 || reset) {
    if (reset) await prisma.galleryImage.deleteMany({});
    for (const g of DEFAULT_GALLERY) {
      await prisma.galleryImage.create({
        data: { src: g.src, alt: g.alt, caption: g.caption, category: g.category, order: g.order },
      });
    }
    console.log(`✓ gallery seeded (${DEFAULT_GALLERY.length})`);
  } else {
    console.log(`• gallery already present (${gCount}) — skipped`);
  }

  /* ---- videos ---- */
  const vCount = await prisma.videoItem.count();
  if (vCount === 0 || reset) {
    if (reset) await prisma.videoItem.deleteMany({});
    for (const v of DEFAULT_VIDEOS) {
      await prisma.videoItem.create({
        data: { videoId: v.videoId, title: v.title, location: v.location, description: v.description, order: v.order },
      });
    }
    console.log(`✓ videos seeded (${DEFAULT_VIDEOS.length})`);
  } else {
    console.log(`• videos already present (${vCount}) — skipped`);
  }

  /* ---- instagram ---- */
  const iCount = await prisma.instagramPost.count();
  if (iCount === 0 || reset) {
    if (reset) await prisma.instagramPost.deleteMany({});
    for (const p of DEFAULT_INSTAGRAM) {
      await prisma.instagramPost.create({
        data: {
          src: p.src, alt: p.alt, caption: p.caption, location: p.location,
          likes: p.likes, dateLabel: p.dateLabel, permalink: p.permalink, order: p.order,
        },
      });
    }
    console.log(`✓ instagram seeded (${DEFAULT_INSTAGRAM.length})`);
  } else {
    console.log(`• instagram already present (${iCount}) — skipped`);
  }

  /* ---- real stories ---- */
  const sCount = await prisma.story.count();
  if (sCount === 0 || reset) {
    if (reset) await prisma.story.deleteMany({});
    for (const st of DEFAULT_STORIES) {
      await prisma.story.upsert({
        where: { slug: st.slug },
        update: {},
        create: {
          slug: st.slug,
          title: st.title,
          dek: st.dek,
          location: st.location,
          date: st.date,
          readTime: st.readTime,
          tag: st.tag,
          cover: st.cover,
          coverAlt: st.coverAlt,
          excerpt: st.excerpt,
          body: st.body,
          order: st.order,
        },
      });
    }
    console.log(`✓ stories seeded (${DEFAULT_STORIES.length})`);
  } else {
    console.log(`• stories already present (${sCount}) — skipped`);
  }

  /* ---- admin user (credentials from env/args — never printed) ---- */
  const username = process.env.ADMIN_USERNAME || process.argv[2] || "";
  const password = process.env.ADMIN_PASSWORD || process.argv[3] || "";

  const existing = await prisma.adminUser.count();
  if (existing > 0 && !username && !password) {
    console.log("• admin user already present — skipped");
  } else if (!username || !password) {
    console.log(
      "⚠ no ADMIN_USERNAME/ADMIN_PASSWORD provided — create one later with:\n" +
        "  ADMIN_USERNAME=... ADMIN_PASSWORD=... bun scripts/seed.ts"
    );
  } else {
    const salt = randomBytes(16).toString("hex");
    const hash = scryptSync(password, salt, 64).toString("hex");
    await prisma.adminUser.upsert({
      where: { username },
      update: { passwordHash: `${salt}:${hash}` },
      create: { username, passwordHash: `${salt}:${hash}` },
    });
    console.log(`✓ admin user ready (username: ${username})`);
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
