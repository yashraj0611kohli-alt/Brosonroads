import type { Metadata, Viewport } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { BROSONROADS } from "@/lib/site";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(BROSONROADS.siteUrl),
  title: "BrosonRoads | Motorcycle Rides, Himalayan Roads & Travel Stories",
  description:
    "BrosonRoads documents motorcycle journeys through Uttarakhand, Himachal Pradesh and the Himalayas — discovering mountain roads, hidden destinations, waterfalls and unforgettable rides.",
  keywords: [
    "motorcycle rides in Uttarakhand",
    "bike rides in Uttarakhand",
    "motorcycle touring Uttarakhand",
    "Himalayan motorcycle rides",
    "bike trips in Himalayas",
    "Uttarakhand road trips",
    "motorcycle destinations in Uttarakhand",
    "places to visit in Uttarakhand by bike",
    "Himalayan bike trip",
    "Spiti Valley motorcycle trip",
    "Chopta bike trip",
    "Valley of Flowers bike trip",
    "mountain bike rides India",
  ],
  authors: [{ name: "BrosonRoads" }],
  creator: "BrosonRoads",
  publisher: "BrosonRoads",
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "BrosonRoads | Motorcycle Rides, Himalayan Roads & Travel Stories",
    description:
      "Motorcycle journeys through Uttarakhand, Himachal and the Himalayas — mountain roads, hidden places and real riding experiences.",
    url: "/",
    siteName: "BrosonRoads",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "BrosonRoads | Motorcycle Rides, Himalayan Roads & Travel Stories",
    description:
      "Motorcycle journeys through Uttarakhand, Himachal and the Himalayas — mountain roads, hidden places and real riding experiences.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

export const viewport: Viewport = {
  themeColor: "#0B0B0B",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${spaceGrotesk.variable} antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
