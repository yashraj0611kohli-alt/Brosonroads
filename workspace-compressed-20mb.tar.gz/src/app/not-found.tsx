import Link from "next/link";

export default function NotFound() {
  return (
    <main className="grain relative flex min-h-[100svh] flex-col items-center justify-center bg-[#0B0B0B] px-6 text-center">
      <p className="eyebrow mb-6">404 — Off the map</p>
      <h1 className="display-title text-[22vw] font-bold leading-none text-white sm:text-[9rem]">
        4<span className="text-[#D97F3E]">0</span>4
      </h1>
      <p className="mt-6 max-w-md text-[15px] leading-relaxed text-[#929292]">
        This road doesn&apos;t exist — but plenty of good ones do. Head back
        before the weather changes.
      </p>
      <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
        <Link
          href="/"
          className="bg-white px-7 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-black transition-colors duration-300 hover:bg-[#D97F3E]"
        >
          Back home
        </Link>
        <Link
          href="/rides"
          className="border border-white/30 px-7 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition-all duration-300 hover:border-white hover:bg-white/10"
        >
          Explore rides
        </Link>
      </div>
    </main>
  );
}
