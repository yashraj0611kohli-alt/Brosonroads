import { NextRequest, NextResponse } from "next/server";
import { assertAdminApi } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET  /api/admin/stories — all stories (including drafts)
 * POST /api/admin/stories — create a story
 */

function slugify(input: string): string {
  return (
    input
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 80) || `story-${Date.now()}`
  );
}

export async function GET() {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;
  const stories = await db.story.findMany({
    orderBy: [{ order: "asc" }, { createdAt: "desc" }],
  });
  return NextResponse.json(stories);
}

export async function POST(req: NextRequest) {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const title = String(body.title ?? "").trim();
  if (!title) {
    return NextResponse.json({ error: "Title is required" }, { status: 400 });
  }

  let slug = slugify(String(body.slug ?? title));
  const clash = await db.story.findUnique({ where: { slug } });
  if (clash) slug = `${slug}-${Date.now().toString(36)}`;

  const created = await db.story.create({
    data: {
      slug,
      title,
      dek: String(body.dek ?? "").slice(0, 500),
      location: String(body.location ?? "").slice(0, 200),
      date: String(body.date ?? "").slice(0, 100),
      readTime: String(body.readTime ?? "").slice(0, 60),
      tag: String(body.tag ?? "Ride Journal").slice(0, 60),
      cover: String(body.cover ?? "").slice(0, 4000),
      coverAlt: String(body.coverAlt ?? "").slice(0, 500),
      excerpt: String(body.excerpt ?? "").slice(0, 1000),
      body: String(body.body ?? "").slice(0, 60000),
      order: Number.isFinite(Number(body.order)) ? Math.round(Number(body.order)) : 0,
      published: body.published === undefined ? true : Boolean(body.published),
    },
  });

  return NextResponse.json(created, { status: 201 });
}
