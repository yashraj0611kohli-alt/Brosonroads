import { NextRequest, NextResponse } from "next/server";
import { assertAdminApi, checkCredentials, currentAdminUsername, hashPassword } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/admin/password — { current, next }
 * Verifies the current password of the signed-in admin, then
 * stores the new one as a scrypt hash. The hash is never returned.
 */
export async function POST(req: NextRequest) {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;

  let body: { current?: string; next?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const current = body.current ?? "";
  const next = body.next ?? "";

  if (!current || next.length < 8) {
    return NextResponse.json(
      { error: "Current password and a new password (min 8 chars) are required." },
      { status: 400 }
    );
  }

  const username = await currentAdminUsername();
  if (!(await checkCredentials(username, current))) {
    return NextResponse.json({ error: "Current password is incorrect." }, { status: 401 });
  }

  await db.adminUser.update({
    where: { username },
    data: { passwordHash: hashPassword(next) },
  });

  return NextResponse.json({ ok: true });
}
