import { NextRequest, NextResponse } from "next/server";
import { assertAdminApi } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET  /api/admin/settings — full editable settings (parsed JSON fields)
 * PUT  /api/admin/settings — accepts the same shape back; string fields
 *                            are saved verbatim, contacts/aboutLines are
 *                            re-serialised. Image fields may be "" (→ the
 *                            public site falls back to bundled defaults).
 */

/* Only these keys may be written — nothing else is accepted. */
const TEXT_KEYS = [
  "heroEyebrow", "heroTitle", "heroSubtitle", "heroText",
  "heroVideoUrl", "heroPoster", "heroLocation", "heroMetaLabel",
  "ridesEyebrow", "ridesTitle1", "ridesTitle2", "ridesNote",
  "upcomingEyebrow", "upcomingTitle1", "upcomingTitle2", "upcomingNote",
  "aboutEyebrow", "aboutTitle1", "aboutTitle2", "aboutLead",
  "aboutQuote", "aboutImage", "aboutCaption",
  "galleryEyebrow", "galleryTitle1", "galleryTitle2",
  "watchEyebrow", "watchTitle1", "watchTitle2", "watchNote",
  "instagramEyebrow", "instagramTitle1", "instagramTitle2",
  "storiesEyebrow", "storiesTitle1", "storiesTitle2", "storiesNote",
  "joinEyebrow", "joinTitle1", "joinTitle2", "joinText",
  "upcomingBg", "joinBg",
  "popupTitle1", "popupTitle2", "popupText", "popupImage",
  "youtubeUrl", "youtubeHandle", "instagramUrl", "instagramHandle",
  "contactEmail",
  "ridesBannerImg", "ridesBannerEyebrow", "ridesBannerTitle", "ridesBannerSub",
  "aboutBannerImg", "aboutBannerEyebrow", "aboutBannerTitle", "aboutBannerSub",
  "galleryBannerImg", "galleryBannerEyebrow", "galleryBannerTitle", "galleryBannerSub",
  "watchBannerImg", "watchBannerEyebrow", "watchBannerTitle", "watchBannerSub",
  "joinBannerImg", "joinBannerEyebrow", "joinBannerTitle", "joinBannerSub",
  "storiesBannerImg", "storiesBannerEyebrow", "storiesBannerTitle", "storiesBannerSub",
] as const;

async function readSettingsJson() {
  const row = await db.siteSettings.findUnique({ where: { id: "main" } });
  if (!row) throw new Error("Settings row missing — run the seed script.");
  const { contactsJson, aboutLines, ...rest } = row;
  return {
    ...rest,
    aboutLines: JSON.parse(aboutLines) as string[],
    contacts: JSON.parse(contactsJson) as unknown,
  };
}

export async function GET() {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;
  return NextResponse.json(await readSettingsJson());
}

export async function PUT(req: NextRequest) {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const data: Record<string, string | boolean | number> = {};

  for (const key of TEXT_KEYS) {
    if (key in body && typeof body[key] === "string") {
      data[key] = (body[key] as string).slice(0, 4000);
    }
  }
  if ("popupEnabled" in body) data.popupEnabled = Boolean(body.popupEnabled);
  if ("popupDelaySec" in body) {
    const n = Number(body.popupDelaySec);
    data.popupDelaySec = Number.isFinite(n) ? Math.min(600, Math.max(3, Math.round(n))) : 20;
  }

  if ("contacts" in body) {
    const contacts = body.contacts;
    if (!Array.isArray(contacts) || contacts.length === 0 || contacts.length > 4) {
      return NextResponse.json({ error: "contacts must be a 1–4 item list" }, { status: 400 });
    }
    const clean = contacts.map((c) => {
      const o = c as Record<string, unknown>;
      return {
        name: String(o.name ?? "").slice(0, 80),
        role: String(o.role ?? "").slice(0, 80),
        phone: String(o.phone ?? "").slice(0, 40),
        dial: String(o.dial ?? "").slice(0, 40),
        email: o.email ? String(o.email).slice(0, 120) : undefined,
      };
    });
    if (clean.some((c) => !c.name || !c.dial)) {
      return NextResponse.json({ error: "Each contact needs at least a name and dial number" }, { status: 400 });
    }
    data.contactsJson = JSON.stringify(clean);
  }

  if ("aboutLines" in body) {
    if (!Array.isArray(body.aboutLines)) {
      return NextResponse.json({ error: "aboutLines must be a list" }, { status: 400 });
    }
    data.aboutLines = JSON.stringify(
      (body.aboutLines as unknown[]).map((l) => String(l).slice(0, 300)).slice(0, 12)
    );
  }

  try {
    await db.siteSettings.update({ where: { id: "main" }, data });
  } catch {
    return NextResponse.json({ error: "Could not save settings" }, { status: 500 });
  }

  return NextResponse.json(await readSettingsJson());
}
