import { db } from "@/lib/db";
import {
  makeCreate,
  makeListCreate,
  type CollectionConfig,
} from "@/lib/admin-crud";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const cfg: CollectionConfig = {
  delegate: (d) => d.videoItem as never,
  fields: {
    videoId: (v) => String(v).trim().slice(0, 32),
    title: (v) => String(v).slice(0, 300),
    location: (v) => String(v).slice(0, 120),
    description: (v) => String(v).slice(0, 2000),
    order: (v) => Math.round(Number(v)) || 0,
  },
  required: ["videoId", "title"],
};

export const GET = makeListCreate(cfg);
export const POST = makeCreate(cfg);
