import { NextRequest, NextResponse } from "next/server";
import {
  SESSION_COOKIE,
  checkCredentials,
  clearRateLimit,
  createSessionToken,
  rateLimited,
  sessionCookieOptions,
} from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/admin/login — { username, password }
 * Sets a signed HttpOnly session cookie on success. Errors are
 * intentionally generic (no username/password enumeration).
 */
export async function POST(req: NextRequest) {
  let body: { username?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const username = (body.username ?? "").trim();
  const password = body.password ?? "";
  if (!username || !password) {
    return NextResponse.json({ error: "Invalid credentials" }, { status: 400 });
  }

  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";

  if (rateLimited(ip)) {
    return NextResponse.json(
      { error: "Too many attempts — try again in 15 minutes." },
      { status: 429 }
    );
  }

  const ok = await checkCredentials(username, password);
  if (!ok) {
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  clearRateLimit(ip);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, createSessionToken(username), sessionCookieOptions);
  return res;
}

