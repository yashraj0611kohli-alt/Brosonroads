import { NextRequest, NextResponse } from "next/server";
import { assertAdminApi } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * PATCH  /api/admin/rides/[id] — partial update
 * DELETE /api/admin/rides/[id]
 */

function slugify(input: string): string {
  return (
    input
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 80) || `ride-${Date.now()}`
  );
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;

  const { id } = await params;
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const data: Record<string, string | boolean | number> = {};
  const strFields = [
    "title", "location", "date", "distance", "days", "image", "alt",
    "excerpt", "description",
  ] as const;
  for (const f of strFields) {
    if (f in body && typeof body[f] === "string") data[f] = (body[f] as string).slice(0, 8000);
  }
  if ("slug" in body && typeof body.slug === "string") data.slug = slugify(body.slug);
  if ("category" in body) data.category = body.category === "upcoming" ? "upcoming" : "featured";
  if ("published" in body) data.published = Boolean(body.published);
  if ("order" in body && Number.isFinite(Number(body.order))) {
    data.order = Math.round(Number(body.order));
  }
  if ("highlights" in body && Array.isArray(body.highlights)) {
    data.highlightsJson = JSON.stringify(body.highlights.map(String).slice(0, 12));
  }
  if ("route" in body && Array.isArray(body.route)) {
    data.routeJson = JSON.stringify(body.route.map(String).slice(0, 12));
  }

  try {
    const updated = await db.ride.update({ where: { id }, data });
    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "Ride not found" }, { status: 404 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;

  const { id } = await params;
  try {
    await db.ride.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Ride not found" }, { status: 404 });
  }
}
