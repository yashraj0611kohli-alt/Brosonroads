import { NextRequest, NextResponse } from "next/server";
import { assertAdminApi } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET  /api/admin/rides — all rides (including unpublished)
 * POST /api/admin/rides — create a ride
 */

function slugify(input: string): string {
  return (
    input
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 80) || `ride-${Date.now()}`
  );
}

export async function GET() {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;
  const rides = await db.ride.findMany({
    orderBy: [{ category: "asc" }, { order: "asc" }, { createdAt: "desc" }],
  });
  return NextResponse.json(rides);
}

export async function POST(req: NextRequest) {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const title = String(body.title ?? "").trim();
  if (!title) {
    return NextResponse.json({ error: "Title is required" }, { status: 400 });
  }

  let slug = slugify(String(body.slug ?? title));
  const clash = await db.ride.findUnique({ where: { slug } });
  if (clash) slug = `${slug}-${Date.now().toString(36)}`;

  const created = await db.ride.create({
    data: {
      slug,
      title,
      location: String(body.location ?? ""),
      date: String(body.date ?? ""),
      distance: String(body.distance ?? ""),
      days: String(body.days ?? ""),
      image: String(body.image ?? ""),
      alt: String(body.alt ?? title),
      excerpt: String(body.excerpt ?? ""),
      description: String(body.description ?? ""),
      highlightsJson: JSON.stringify(
        Array.isArray(body.highlights) ? body.highlights.map(String).slice(0, 12) : []
      ),
      routeJson: JSON.stringify(
        Array.isArray(body.route) ? body.route.map(String).slice(0, 12) : []
      ),
      category: body.category === "upcoming" ? "upcoming" : "featured",
      order: Number.isFinite(Number(body.order)) ? Math.round(Number(body.order)) : 0,
      published: body.published === undefined ? true : Boolean(body.published),
    },
  });

  return NextResponse.json(created, { status: 201 });
}
