import { db } from "@/lib/db";
import {
  makeUpdate,
  makeDeleteFor,
  type CollectionConfig,
} from "@/lib/admin-crud";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const cfg: CollectionConfig = {
  delegate: (d) => d.galleryImage as never,
  fields: {
    src: (v) => String(v).trim().slice(0, 4000),
    alt: (v) => String(v).slice(0, 500),
    caption: (v) => String(v).slice(0, 300),
    category: (v) => String(v).slice(0, 80) || "Riders",
    order: (v) => Math.round(Number(v)) || 0,
  },
  required: ["src"],
};

export const PATCH = makeUpdate(cfg);
export const DELETE = makeDeleteFor(cfg);
