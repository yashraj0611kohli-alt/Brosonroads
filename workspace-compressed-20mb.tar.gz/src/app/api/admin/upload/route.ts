import { NextRequest, NextResponse } from "next/server";
import { assertAdminApi } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/admin/upload — multipart image upload used by the admin
 * panel. Stores the bytes in the Upload table (base64) and returns a
 * durable public URL: /api/media/<id>. Only common image types are
 * accepted, max ~4 MB.
 */

const ALLOWED = new Map([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
  ["image/avif", "avif"],
  ["image/gif", "gif"],
]);

const MAX_BYTES = 4 * 1024 * 1024;

export async function POST(req: NextRequest) {
  const unauthorized = await assertAdminApi();
  if (unauthorized) return unauthorized;

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "Expected multipart form data" }, { status: 400 });
  }

  const file = form.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "No file received" }, { status: 400 });
  }
  const ext = ALLOWED.get(file.type);
  if (!ext) {
    return NextResponse.json(
      { error: "Unsupported image type — use JPG, PNG, WEBP, AVIF or GIF." },
      { status: 415 }
    );
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ error: "Image is too large — max 4 MB." }, { status: 413 });
  }

  const buf = Buffer.from(await file.arrayBuffer());
  const name = (form.get("name") as string | null)?.slice(0, 200) || file.name || "image";

  try {
    const row = await db.upload.create({
      data: { mime: file.type, data: buf.toString("base64"), name },
    });
    return NextResponse.json({ url: `/api/media/${row.id}` }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not store the image" }, { status: 500 });
  }
}
