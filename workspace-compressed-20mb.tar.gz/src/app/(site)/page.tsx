import { Hero } from "@/components/site/hero";
import { FeaturedRides } from "@/components/site/rides";
import { UpcomingRides } from "@/components/site/upcoming";
import { About } from "@/components/site/about";
import { Gallery } from "@/components/site/gallery";
import { YouTubeSection, InstagramSection } from "@/components/site/social";
import { StoriesSection } from "@/components/site/stories";
import { JoinUs } from "@/components/site/join";
import { RidePopup } from "@/components/site/ride-popup";
import { BROSONROADS } from "@/lib/site";
import { getGallery, getInstagram, getRides, getSettings, getStories, getVideos } from "@/lib/store";

/**
 * BROSONROADS homepage — cinematic motorcycle touring & travel
 * publication. All content is served from the database (editable
 * at /admin) with safe defaults as fallback.
 */
export const dynamic = "force-dynamic";

export default async function Home() {
  const [s, featured, upcoming, gallery, videos, instagram, stories] = await Promise.all([
    getSettings(),
    getRides("featured"),
    getRides("upcoming"),
    getGallery(),
    getVideos(),
    getInstagram(),
    getStories(),
  ]);

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: BROSONROADS.name,
    alternateName: "BrosOnRoads",
    url: BROSONROADS.siteUrl,
    description:
      "Motorcycle touring and adventure travel brand documenting journeys through Uttarakhand, Himachal Pradesh and the Himalayas.",
    slogan: BROSONROADS.tagline,
    sameAs: [s.youtubeUrl, s.instagramUrl],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <Hero s={s} />
      <FeaturedRides rides={featured} s={s} showAll />
      <UpcomingRides rides={upcoming} s={s} />
      <About s={s} />
      <Gallery images={gallery.slice(0, 12)} s={s} />
      <YouTubeSection videos={videos} s={s} showAll />
      <InstagramSection posts={instagram} s={s} />
      <StoriesSection stories={stories} s={s} />
      <JoinUs s={s} />

      {/* Timed "ride with us" popup — call / text / email */}
      <RidePopup s={s} />
    </>
  );
}
