import type { Metadata } from "next";
import { PageBanner } from "@/components/site/page-banner";
import { About } from "@/components/site/about";
import { YouTubeSection } from "@/components/site/social";
import { getSettings, getVideos } from "@/lib/store";
import { Reveal } from "@/components/site/reveal";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "About | BrosonRoads — Who We Are & How We Ride",
  description:
    "BrosonRoads is two brothers documenting motorcycle journeys through the Himalayas — the mountain roads, the early starts, the unexpected weather and the stories in between.",
  alternates: { canonical: "/about" },
};

const STATS = [
  { value: "7+", label: "Rides documented" },
  { value: "2,000+", label: "Kilometres ridden" },
  { value: "3", label: "Himalayan states" },
  { value: "1", label: "Road — the story" },
];

export default async function AboutPage() {
  const [s, videos] = await Promise.all([getSettings(), getVideos()]);

  return (
    <>
      <PageBanner
        image={s.aboutBannerImg}
        eyebrow={s.aboutBannerEyebrow}
        title={s.aboutBannerTitle}
        subtitle={s.aboutBannerSub}
      />

      {/* Editorial split — same section as the homepage, fully CMS-driven */}
      <About s={s} />

      {/* Stats band */}
      <section className="border-y border-white/10 bg-[#0B0B0B]">
        <div className="mx-auto grid max-w-[1600px] grid-cols-2 divide-x divide-white/10 md:grid-cols-4">
          {STATS.map((stat, i) => (
            <Reveal key={stat.label} delay={i * 80}>
              <div className="px-4 py-10 text-center md:py-14">
                <p className="display-title text-3xl font-bold text-white md:text-5xl">
                  {stat.value}
                </p>
                <p className="eyebrow mt-3">{stat.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Why we ride — editorial copy block */}
      <section className="bg-[#F5F4F0] py-24 md:py-32">
        <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
            <Reveal className="lg:col-span-5">
              <p className="eyebrow eyebrow-dark mb-4">Why we ride</p>
              <h2 className="display-title text-4xl font-bold text-[#111111] sm:text-5xl">
                The Road Is<br />
                <span className="text-outline-dark">The Story</span>
              </h2>
            </Reveal>
            <Reveal delay={130} className="lg:col-span-7">
              <div className="space-y-5 text-[15px] leading-relaxed text-[#6E6C66] md:text-base">
                <p>
                  BrosonRoads started the way most good things do — two brothers,
                  a couple of motorcycles and a weekend that kept getting longer.
                  We rode because the mountains were there, and we filmed because
                  people back home kept asking what it was like.
                </p>
                <p>
                  Today every journey is documented end to end: the planning, the
                  packing list, the 4 AM starts, the passes that close without
                  warning and the roadside chai that fixes everything. What you
                  see on this site is exactly what happened — real roads, real
                  weather, real people.
                </p>
                <p>
                  We ride Uttarakhand hardest — Garhwal and Kumaon are home turf —
                  but the channel follows us anywhere the Himalayas call: Spiti,
                  Kinnaur, Ladakh and beyond. If it has a road, a view and a story,
                  it&apos;s on the map.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Films */}
      <YouTubeSection videos={videos.slice(0, 3)} s={s} />
    </>
  );
}
