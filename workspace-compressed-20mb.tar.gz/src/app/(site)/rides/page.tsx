import type { Metadata } from "next";
import { PageBanner } from "@/components/site/page-banner";
import { FeaturedRides } from "@/components/site/rides";
import { UpcomingRides } from "@/components/site/upcoming";
import {
  getRides,
  getSettings,
} from "@/lib/store";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Rides | BrosonRoads — Motorcycle Journeys in the Himalayas",
  description:
    "All BrosonRoads rides — completed journeys through Uttarakhand and Himachal plus upcoming expeditions you can join. Distances, routes and real stories from the saddle.",
  alternates: { canonical: "/rides" },
};

export default async function RidesPage() {
  const [s, featured, upcoming] = await Promise.all([
    getSettings(),
    getRides("featured"),
    getRides("upcoming"),
  ]);

  return (
    <>
      <PageBanner
        image={s.ridesBannerImg}
        eyebrow={s.ridesBannerEyebrow}
        title={s.ridesBannerTitle}
        subtitle={s.ridesBannerSub}
      />
      <FeaturedRides rides={featured} s={s} />
      <UpcomingRides rides={upcoming} s={s} />
    </>
  );
}
