import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowUpRight,
  Calendar,
  Clock,
  MapPin,
  Phone,
  Mail,
  Route,
  Mountain,
} from "lucide-react";
import { PageBanner } from "@/components/site/page-banner";
import { SafeImage } from "@/components/site/safe-image";
import { ContactCards } from "@/components/site/join";
import { getRideBySlug, getRides, getSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const ride = await getRideBySlug(slug);
  if (!ride) return { title: "Ride not found | BrosonRoads" };
  return {
    title: `${ride.title} | BrosonRoads Rides`,
    description: ride.excerpt || ride.description.slice(0, 150),
    alternates: { canonical: `/rides/${ride.slug}` },
    openGraph: {
      title: `${ride.title} | BrosonRoads`,
      description: ride.excerpt,
      images: ride.image ? [{ url: ride.image }] : undefined,
    },
  };
}

export default async function RideDetailPage({ params }: Props) {
  const { slug } = await params;
  const [ride, s, allRides] = await Promise.all([
    getRideBySlug(slug),
    getSettings(),
    getRides(),
  ]);

  if (!ride) notFound();

  const others = allRides.filter((r) => r.slug !== ride.slug).slice(0, 3);
  const isUpcoming = ride.category === "upcoming";

  return (
    <>
      <PageBanner
        image={ride.image}
        eyebrow={`${isUpcoming ? "Upcoming Ride" : "Featured Ride"} — ${ride.location}`}
        title={ride.title}
        subtitle={ride.excerpt}
        size="compact"
      />

      {/* Stats strip */}
      <section className="border-b border-white/10 bg-[#0B0B0B]">
        <div className="mx-auto grid max-w-[1600px] grid-cols-2 divide-x divide-white/10 px-5 sm:px-8 md:grid-cols-4 md:px-10">
          {[
            { icon: Calendar, label: ride.category === "upcoming" ? "Dates" : "Date", value: ride.date },
            { icon: Route, label: "Distance", value: ride.distance },
            { icon: Clock, label: "Duration", value: ride.days },
            { icon: Mountain, label: "Region", value: ride.location },
          ].map((stat) => (
            <div key={stat.label} className="flex flex-col items-center gap-1 px-3 py-7 text-center md:py-9">
              <stat.icon className="mb-1 h-4 w-4 text-[#D97F3E]" strokeWidth={1.5} />
              <p className="display-title text-lg font-bold text-white md:text-2xl">{stat.value}</p>
              <p className="text-[9px] uppercase tracking-[0.28em] text-[#929292] md:text-[10px]">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Story */}
      <section className="bg-[#0B0B0B] py-20 md:py-28">
        <div className="mx-auto grid max-w-[1600px] grid-cols-1 gap-14 px-5 sm:px-8 md:px-10 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-7">
            <p className="eyebrow mb-6">The Story</p>
            <p className="text-lg leading-relaxed text-[#D7D7D7] md:text-xl">
              {ride.description}
            </p>

            {ride.route.length > 0 ? (
              <div className="mt-12">
                <p className="eyebrow mb-5">Planned Route</p>
                <ol className="space-y-3">
                  {ride.route.map((step, i) => (
                    <li key={step} className="flex items-start gap-4 text-[15px] text-[#929292]">
                      <span className="display-title mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center border border-[#D97F3E]/50 text-[11px] text-[#D97F3E]">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>
            ) : null}

            {/* Image strip */}
            <div className="mt-12 overflow-hidden">
              <SafeImage
                src={ride.image}
                alt={ride.alt}
                className="aspect-[16/9] w-full object-cover"
                draggable={false}
              />
              <p className="mt-3 text-[11px] uppercase tracking-[0.25em] text-[#5a5a5a]">
                {ride.alt}
              </p>
            </div>
          </div>

          <aside className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <div className="border border-white/10 bg-[#111111] p-7 md:p-9">
                <p className="eyebrow mb-4">
                  {isUpcoming ? "Join this ride" : "Ride highlights"}
                </p>
                <ul className="space-y-4">
                  {ride.highlights.map((h) => (
                    <li key={h} className="flex items-start gap-3 text-sm leading-relaxed text-[#929292]">
                      <span className="mt-[7px] h-1 w-4 shrink-0 bg-[#D97F3E]" aria-hidden="true" />
                      {h}
                    </li>
                  ))}
                </ul>

                <div className="mt-8 border-t border-white/10 pt-7">
                  <p className="text-sm leading-relaxed text-[#D7D7D7]">
                    {isUpcoming
                      ? "Want a seat on this ride? Call, text or email us — we'll share dates, costs and everything you need to bring."
                      : "Inspired? The next expedition is being planned right now. Reach out and ride with us."}
                  </p>
                  <div className="mt-6 flex flex-col gap-2.5">
                    {s.contacts[0] ? (
                      <a
                        href={`tel:${s.contacts[0].dial}`}
                        className="flex items-center justify-center gap-2.5 bg-white px-5 py-3.5 text-[11px] font-semibold uppercase tracking-[0.2em] text-black transition-colors duration-300 hover:bg-[#D97F3E]"
                      >
                        <Phone className="h-4 w-4" strokeWidth={1.75} />
                        Call {s.contacts[0].name}
                      </a>
                    ) : null}
                    <a
                      href={`mailto:${s.contactEmail}?subject=${encodeURIComponent(`Ride inquiry — ${ride.title}`)}`}
                      className="flex items-center justify-center gap-2.5 border border-white/25 px-5 py-3.5 text-[11px] font-semibold uppercase tracking-[0.2em] text-white transition-all duration-300 hover:border-white hover:bg-white hover:text-black"
                    >
                      <Mail className="h-4 w-4" strokeWidth={1.75} />
                      Email us
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </section>

      {/* Contact band */}
      <section className="relative overflow-hidden bg-[#0B0B0B] pb-20 md:pb-28">
        <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
          <div className="mb-10 flex items-center gap-3">
            <MapPin className="h-4 w-4 text-[#D97F3E]" strokeWidth={1.5} />
            <p className="eyebrow">Reach the crew directly</p>
          </div>
          <ContactCards contacts={s.contacts} email={s.contactEmail} staggerStart={0} />
        </div>
      </section>

      {/* More rides */}
      {others.length > 0 ? (
        <section className="border-t border-white/10 bg-[#0B0B0B] py-20 md:py-28">
          <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
            <div className="mb-10 flex items-end justify-between">
              <div>
                <p className="eyebrow mb-3">Keep Reading</p>
                <h2 className="display-title text-3xl font-bold text-white sm:text-4xl md:text-5xl">
                  More Rides
                </h2>
              </div>
              <Link
                href="/rides"
                className="group hidden items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#929292] transition-colors hover:text-white sm:inline-flex"
              >
                <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" strokeWidth={1.5} />
                All rides
              </Link>
            </div>

            <div className="grid grid-cols-1 gap-5 md:grid-cols-3 md:gap-6">
              {others.map((other) => (
                <Link
                  key={other.id}
                  href={`/rides/${other.slug}`}
                  className="group relative block h-[300px] overflow-hidden bg-[#151515]"
                >
                  <SafeImage
                    src={other.image}
                    alt={other.alt}
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1100ms] ease-out group-hover:scale-[1.06]"
                    draggable={false}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-6">
                    <p className="eyebrow mb-2">{other.location}</p>
                    <h3 className="display-title text-xl font-bold text-white">{other.title}</h3>
                    <p className="mt-2 flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-[#929292]">
                      {other.date}&ensp;·&ensp;{other.distance}
                    </p>
                  </div>
                  <span className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center border border-white/30 bg-black/30 text-white opacity-0 backdrop-blur-sm transition-all duration-500 group-hover:opacity-100">
                    <ArrowUpRight className="h-4 w-4" strokeWidth={1.5} />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      ) : null}
    </>
  );
}
