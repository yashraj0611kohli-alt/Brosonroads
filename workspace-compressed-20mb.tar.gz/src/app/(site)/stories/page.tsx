import type { Metadata } from "next";
import { PageBanner } from "@/components/site/page-banner";
import { StoriesIndex } from "@/components/site/stories";
import { getSettings, getStories } from "@/lib/store";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Real Stories | BrosonRoads — Ride Journals & Articles",
  description:
    "Long-form stories from the BrosonRoads crew — ride journals, expedition field notes and articles from the mountain roads of Uttarakhand, Himachal and beyond.",
  alternates: { canonical: "/stories" },
};

export default async function StoriesPage() {
  const [s, stories] = await Promise.all([getSettings(), getStories()]);

  return (
    <>
      <PageBanner
        image={s.storiesBannerImg}
        eyebrow={s.storiesBannerEyebrow}
        title={s.storiesBannerTitle}
        subtitle={s.storiesBannerSub}
      />
      <StoriesIndex stories={stories} />
    </>
  );
}
