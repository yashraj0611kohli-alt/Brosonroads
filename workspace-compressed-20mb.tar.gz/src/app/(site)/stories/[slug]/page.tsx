import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, MapPin, CalendarDays, Clock3 } from "lucide-react";
import { StoryBody } from "@/components/site/story-body";
import { SafeImage } from "@/components/site/safe-image";
import { Reveal } from "@/components/site/reveal";
import { getSettings, getStories, getStoryBySlug } from "@/lib/store";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const story = await getStoryBySlug(slug);
  if (!story) return { title: "Story not found | BrosonRoads" };
  return {
    title: `${story.title} | BrosonRoads — Real Stories`,
    description: story.excerpt || story.dek,
    alternates: { canonical: `/stories/${story.slug}` },
    openGraph: {
      title: story.title,
      description: story.excerpt || story.dek,
      images: story.cover ? [{ url: story.cover }] : undefined,
      type: "article",
    },
  };
}

export default async function StoryPage({ params }: Props) {
  const { slug } = await params;
  const [story, s, all] = await Promise.all([
    getStoryBySlug(slug),
    getSettings(),
    getStories(),
  ]);

  if (!story) notFound();

  const idx = all.findIndex((x) => x.slug === story.slug);
  const prev = idx > 0 ? all[idx - 1] : null;
  const next = idx >= 0 && idx < all.length - 1 ? all[idx + 1] : null;
  const more = all.filter((x) => x.slug !== story.slug).slice(0, 2);

  return (
    <>
      {/* ---- Cinematic cover ---- */}
      <section
        className="grain relative flex min-h-[68vh] items-end overflow-hidden bg-[#0B0B0B] md:min-h-[76vh]"
        aria-label={`${story.title} — cover`}
      >
        <SafeImage
          src={story.cover}
          alt={story.coverAlt || story.title}
          priority
          className="absolute inset-0 h-full w-full animate-[hero-drift_20s_ease-in-out_infinite_alternate] object-cover"
          draggable={false}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B] via-[#0B0B0B]/40 to-[#0B0B0B]/55" aria-hidden="true" />

        <div className="relative z-10 mx-auto w-full max-w-[1200px] px-5 pb-16 pt-36 sm:px-8 md:px-10 md:pb-20">
          <p className="hero-rise eyebrow mb-5" style={{ animationDelay: "120ms" }}>
            <Link href="/stories" className="inline-flex items-center gap-2 transition-colors hover:text-white">
              <ArrowLeft className="h-3.5 w-3.5" strokeWidth={1.75} />
              Real Stories
            </Link>
            {story.tag ? <span className="mx-3 text-[#D97F3E]">/</span> : null}
            {story.tag}
          </p>
          <h1
            className="hero-rise display-title max-w-4xl text-4xl font-bold text-white sm:text-5xl md:text-6xl"
            style={{ animationDelay: "260ms" }}
          >
            {story.title}
          </h1>
          {story.dek ? (
            <p
              className="hero-rise mt-5 max-w-2xl text-base leading-relaxed text-[#D7D7D7] md:text-lg"
              style={{ animationDelay: "400ms" }}
            >
              {story.dek}
            </p>
          ) : null}
          <div
            className="hero-rise mt-7 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11px] uppercase tracking-[0.2em] text-[#929292]"
            style={{ animationDelay: "540ms" }}
          >
            {story.location ? (
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5 text-[#D97F3E]" strokeWidth={1.5} />
                {story.location}
              </span>
            ) : null}
            {story.date ? (
              <span className="inline-flex items-center gap-1.5">
                <CalendarDays className="h-3.5 w-3.5" strokeWidth={1.5} />
                {story.date}
              </span>
            ) : null}
            {story.readTime ? (
              <span className="inline-flex items-center gap-1.5">
                <Clock3 className="h-3.5 w-3.5" strokeWidth={1.5} />
                {story.readTime}
              </span>
            ) : null}
          </div>
        </div>
      </section>

      {/* ---- Article body — paper white, readable measure ---- */}
      <section className="bg-[#F5F4F0] py-16 md:py-24">
        <div className="mx-auto max-w-[760px] px-5 sm:px-8">
          <article>
            <StoryBody body={story.body} />
          </article>

          {/* Story footer — mark + back link */}
          <Reveal className="mt-16 flex flex-col items-start gap-6 border-t border-black/10 pt-8 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-[11px] uppercase tracking-[0.25em] text-[#8a877f]">
              Filed from the saddle — BrosonRoads
            </p>
            <Link
              href="/stories"
              className="group inline-flex items-center gap-2 border border-black/25 px-6 py-3 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#111111] transition-all duration-300 hover:border-[#111111] hover:bg-[#111111] hover:text-white"
            >
              <ArrowLeft className="h-4 w-4" strokeWidth={1.75} />
              All stories
            </Link>
          </Reveal>
        </div>
      </section>

      {/* ---- More stories ---- */}
      {more.length > 0 ? (
        <section className="bg-[#F5F4F0] pb-24 md:pb-32">
          <div className="mx-auto max-w-[1200px] px-5 sm:px-8 md:px-10">
            <div className="mb-8 flex items-center gap-5" aria-hidden="true">
              <span className="h-px flex-1 bg-black/10" />
              <span className="eyebrow eyebrow-dark">Keep reading</span>
              <span className="h-px flex-1 bg-black/10" />
            </div>
            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              {more.map((m) => (
                <Link
                  key={m.id}
                  href={`/stories/${m.slug}`}
                  className="group flex items-center gap-5 border border-black/10 bg-white p-4 transition-colors duration-300 hover:border-[#D97F3E]"
                >
                  <div className="relative h-20 w-28 shrink-0 overflow-hidden">
                    <SafeImage
                      src={m.cover}
                      alt={m.coverAlt || m.title}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      draggable={false}
                    />
                  </div>
                  <div className="min-w-0">
                    <p className="eyebrow eyebrow-dark mb-1.5">{m.tag}</p>
                    <p className="display-title truncate text-lg font-bold text-[#111111] transition-colors group-hover:text-[#B4632A]">
                      {m.title}
                    </p>
                    <p className="mt-1 text-xs text-[#8a877f]">{m.readTime}</p>
                  </div>
                  <ArrowRight className="ml-auto h-4 w-4 shrink-0 text-[#8a877f] transition-transform duration-300 group-hover:translate-x-1 group-hover:text-[#D97F3E]" strokeWidth={1.5} />
                </Link>
              ))}
            </div>
          </div>
        </section>
      ) : null}

      {/* ---- Prev / Next ---- */}
      {prev || next ? (
        <nav aria-label="Story navigation" className="border-t border-black/10 bg-[#F5F4F0]">
          <div className="mx-auto grid max-w-[1200px] grid-cols-1 divide-y divide-black/10 px-5 sm:px-8 md:grid-cols-2 md:divide-x md:divide-y-0 md:px-10">
            {prev ? (
              <Link href={`/stories/${prev.slug}`} className="group flex items-center gap-4 py-7 pr-6">
                <ArrowLeft className="h-4 w-4 shrink-0 text-[#8a877f] transition-transform duration-300 group-hover:-translate-x-1 group-hover:text-[#D97F3E]" strokeWidth={1.5} />
                <div className="min-w-0">
                  <p className="eyebrow eyebrow-dark mb-1">Previous</p>
                  <p className="display-title truncate text-base font-bold text-[#111111] transition-colors group-hover:text-[#B4632A]">
                    {prev.title}
                  </p>
                </div>
              </Link>
            ) : (
              <div className="hidden md:block" />
            )}
            {next ? (
              <Link href={`/stories/${next.slug}`} className="group flex items-center justify-end gap-4 py-7 md:pl-6">
                <div className="min-w-0 text-right">
                  <p className="eyebrow eyebrow-dark mb-1">Next</p>
                  <p className="display-title truncate text-base font-bold text-[#111111] transition-colors group-hover:text-[#B4632A]">
                    {next.title}
                  </p>
                </div>
                <ArrowRight className="h-4 w-4 shrink-0 text-[#8a877f] transition-transform duration-300 group-hover:translate-x-1 group-hover:text-[#D97F3E]" strokeWidth={1.5} />
              </Link>
            ) : null}
          </div>
        </nav>
      ) : null}
    </>
  );
}
