import type { Metadata } from "next";
import { PageBanner } from "@/components/site/page-banner";
import { GalleryGrid } from "@/components/site/gallery";
import { getGallery, getSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Gallery | BrosonRoads — Frames From The Road",
  description:
    "Photographs from BrosonRoads motorcycle journeys — Himalayan roads, mountain passes, monsoon waterfalls, campsites and the riders themselves.",
  alternates: { canonical: "/gallery" },
};

export default async function GalleryPage() {
  const [s, images] = await Promise.all([getSettings(), getGallery()]);

  return (
    <>
      <PageBanner
        image={s.galleryBannerImg}
        eyebrow={s.galleryBannerEyebrow}
        title={s.galleryBannerTitle}
        subtitle={s.galleryBannerSub}
      />
      <section className="bg-[#0B0B0B] py-20 md:py-28">
        <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
          <GalleryGrid images={images} />
        </div>
      </section>
    </>
  );
}
