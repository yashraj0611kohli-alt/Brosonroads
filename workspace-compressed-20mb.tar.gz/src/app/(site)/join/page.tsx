import type { Metadata } from "next";
import { PageBanner } from "@/components/site/page-banner";
import { JoinUs } from "@/components/site/join";
import { getSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Join Us | BrosonRoads — Ride With Us In The Himalayas",
  description:
    "Want to ride with BrosonRoads? Call, text or email the crew for details — dates, costs and everything you need for the next Himalayan ride.",
  alternates: { canonical: "/join" },
};

export default async function JoinPage() {
  const s = await getSettings();

  return (
    <>
      <PageBanner
        image={s.joinBannerImg}
        eyebrow={s.joinBannerEyebrow}
        title={s.joinBannerTitle}
        subtitle={s.joinBannerSub}
      />

      {/* Contact section — same as homepage, CMS-driven */}
      <JoinUs s={s} />
    </>
  );
}
