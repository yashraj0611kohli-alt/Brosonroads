import type { Metadata } from "next";
import { PageBanner } from "@/components/site/page-banner";
import { YouTubeSection } from "@/components/site/social";
import { getSettings, getVideos } from "@/lib/store";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Watch | BrosonRoads — Films From The Saddle",
  description:
    "Official BrosonRoads YouTube films — full ride vlogs, shorts and expedition documentaries from the Himalayas and across India.",
  alternates: { canonical: "/watch" },
};

export default async function WatchPage() {
  const [s, videos] = await Promise.all([getSettings(), getVideos()]);

  return (
    <>
      <PageBanner
        image={s.watchBannerImg}
        eyebrow={s.watchBannerEyebrow}
        title={s.watchBannerTitle}
        subtitle={s.watchBannerSub}
      />
      <YouTubeSection videos={videos} s={s} />
    </>
  );
}
