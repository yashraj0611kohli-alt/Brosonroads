import { Header } from "@/components/site/header";
import { Footer } from "@/components/site/footer";
import { getSettings } from "@/lib/store";

/**
 * Shared chrome for all public pages — sticky header, footer,
 * page-level background and overflow guards.
 */
export default async function SiteLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const s = await getSettings();
  return (
    <>
      <Header s={s} />
      <main className="flex-1">{children}</main>
      <Footer s={s} />
    </>
  );
}
