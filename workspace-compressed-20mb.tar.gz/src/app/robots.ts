import type { MetadataRoute } from "next";

import { BROSONROADS } from "@/lib/site";

/**
 * ============================================================
 *  BROSONROADS — ROBOTS.TXT  (/robots.txt)
 * ============================================================
 *  Welcomes all major crawlers to the public site, points them
 *  at the sitemap and keeps the private areas (admin panel,
 *  APIs) out of search results.
 * ============================================================
 */

export default function robots(): MetadataRoute.Robots {
  const base = BROSONROADS.siteUrl.replace(/\/+$/, "");

  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/admin", "/admin/", "/api/", "/api"],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
    host: base,
  };
}
