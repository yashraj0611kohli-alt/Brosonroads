import { currentAdminUsername, requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/store";
import { AdminApp } from "@/components/admin/admin-app";
import type { AdminSettings } from "@/components/admin/types";

export const dynamic = "force-dynamic";

/**
 * /admin/dashboard — server-guarded admin surface. Everything the
 * signed-in owner needs to run the site: content, rides, gallery,
 * videos, Instagram cards, inquiries and the account itself.
 */
export default async function AdminDashboard() {
  await requireAdmin();
  const settings = await getSettings();
  const username = await currentAdminUsername();

  return (
    <AdminApp
      settings={settings as unknown as AdminSettings}
      username={username}
    />
  );
}
