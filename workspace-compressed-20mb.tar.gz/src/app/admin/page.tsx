import { redirect } from "next/navigation";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * /admin — entry point. Signed-in admins land on the dashboard,
 * everyone else gets the login screen. No credentials are ever
 * shown, hinted or stored on the client.
 */
export default async function AdminEntry() {
  if (await isAdmin()) redirect("/admin/dashboard");
  redirect("/admin/login");
}
