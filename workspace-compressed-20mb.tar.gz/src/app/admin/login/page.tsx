"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Lock, ArrowRight, LoaderCircle } from "lucide-react";
import Link from "next/link";

/**
 * Admin sign-in. Two unlabeled-purpose fields, generic errors,
 * no hints about valid credentials anywhere in markup or copy.
 */
export default function AdminLoginPage() {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    setPending(true);
    setError("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: data.get("username"),
          password: data.get("password"),
        }),
      });
      if (res.ok) {
        router.replace("/admin/dashboard");
        router.refresh();
        return;
      }
      const j = (await res.json().catch(() => ({}))) as { error?: string };
      setError(j.error || "Sign-in failed. Please try again.");
    } catch {
      setError("Network error — please try again.");
    } finally {
      setPending(false);
    }
  }

  const inputClass =
    "w-full border border-white/15 bg-[#151515] px-4 py-3.5 text-sm text-white placeholder:text-[#5a5a5a] transition-colors duration-300 focus:border-[#D97F3E] focus:outline-none";

  return (
    <main className="grain relative flex min-h-screen items-center justify-center px-5">
      <div className="w-full max-w-md">
        <div className="mb-10 text-center">
          <Link href="/" className="display-title text-3xl font-bold tracking-tight text-white">
            BROS<span className="text-[#D97F3E]">ON</span>ROADS
          </Link>
          <p className="eyebrow mt-4">Restricted area</p>
        </div>

        <form
          onSubmit={onSubmit}
          className="border border-white/10 bg-[#111111] p-8 md:p-10"
        >
          <div className="mb-8 flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center border border-[#D97F3E]/50 bg-[#D97F3E]/10">
              <Lock className="h-4 w-4 text-[#D97F3E]" strokeWidth={1.75} />
            </span>
            <div>
              <h1 className="display-title text-lg font-bold text-white">Sign in</h1>
              <p className="text-[11px] uppercase tracking-[0.22em] text-[#7a7a7a]">
                Site management access
              </p>
            </div>
          </div>

          <label htmlFor="admin-user" className="eyebrow mb-2 block">
            Username
          </label>
          <input
            id="admin-user"
            name="username"
            autoComplete="username"
            required
            autoFocus
            className={inputClass}
            placeholder="Your username"
          />

          <label htmlFor="admin-pass" className="eyebrow mb-2 mt-5 block">
            Password
          </label>
          <input
            id="admin-pass"
            name="password"
            type="password"
            autoComplete="current-password"
            required
            className={inputClass}
            placeholder="Your password"
          />

          {error ? (
            <p
              role="alert"
              className="mt-5 border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300"
            >
              {error}
            </p>
          ) : null}

          <button
            type="submit"
            disabled={pending}
            className="group mt-8 inline-flex w-full items-center justify-center gap-3 bg-white px-8 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-black transition-colors duration-300 hover:bg-[#D97F3E] disabled:cursor-not-allowed disabled:opacity-60"
          >
            {pending ? (
              <LoaderCircle className="h-4 w-4 animate-spin" strokeWidth={1.75} />
            ) : (
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" strokeWidth={1.75} />
            )}
            {pending ? "Checking…" : "Sign in"}
          </button>
        </form>

        <p className="mt-8 text-center text-[11px] uppercase tracking-[0.25em] text-[#5a5a5a]">
          <Link href="/" className="transition-colors hover:text-[#929292]">
            ← Back to the site
          </Link>
        </p>
      </div>
    </main>
  );
}
