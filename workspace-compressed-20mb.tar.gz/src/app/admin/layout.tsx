import type { Metadata } from "next";

/**
 * Admin shell — intentionally outside the public (site) layout:
 * no header, no footer, no analytics. Search engines are excluded.
 */
export const metadata: Metadata = {
  title: "Admin | BrosonRoads",
  robots: { index: false, follow: false, nocache: true },
};

export default function AdminLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return <div className="min-h-screen bg-[#0B0B0B] text-white">{children}</div>;
}
