import type { MetadataRoute } from "next";

import { BROSONROADS } from "@/lib/site";
import { getRides, getStories } from "@/lib/store";

/**
 * ============================================================
 *  BROSONROADS — DYNAMIC SITEMAP  (/sitemap.xml)
 * ============================================================
 *  Generated per request so Google always sees the current
 *  site structure:
 *    · 7 static pages (home, rides, stories, gallery, …)
 *    · every PUBLISHED ride   → /rides/<slug>
 *    · every PUBLISHED story  → /stories/<slug>
 *
 *  Admin pages (/admin) and APIs (/api) are intentionally
 *  excluded — they are noindexed and blocked in robots.txt.
 *
 *  Data comes from the CMS layer, which falls back to the
 *  bundled defaults if the database is unreachable, so the
 *  sitemap always renders.
 * ============================================================
 */

export const revalidate = 3600; // refresh at most once per hour

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = BROSONROADS.siteUrl.replace(/\/+$/, "");
  const now = new Date();

  const staticRoutes: MetadataRoute.Sitemap = [
    {
      url: `${base}/`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 1,
    },
    {
      url: `${base}/rides`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.9,
    },
    {
      url: `${base}/stories`,
      lastModified: now,
      changeFrequency: "weekly",
      priority: 0.9,
    },
    {
      url: `${base}/gallery`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.8,
    },
    {
      url: `${base}/watch`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.7,
    },
    {
      url: `${base}/about`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.7,
    },
    {
      url: `${base}/join`,
      lastModified: now,
      changeFrequency: "yearly",
      priority: 0.6,
    },
  ];

  const [rides, stories] = await Promise.all([getRides(), getStories()]);

  const rideUrls: MetadataRoute.Sitemap = rides.map((ride) => ({
    url: `${base}/rides/${ride.slug}`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.8,
  }));

  const storyUrls: MetadataRoute.Sitemap = stories.map((story) => ({
    url: `${base}/stories/${story.slug}`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.7,
  }));

  return [...staticRoutes, ...rideUrls, ...storyUrls];
}
