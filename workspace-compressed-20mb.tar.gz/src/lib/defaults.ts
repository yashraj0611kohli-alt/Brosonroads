/**
 * ============================================================
 *  BROSONROADS — DEFAULT CONTENT (seed + fallback)
 * ============================================================
 *  This file is the DEFAULT content of the whole site. It is
 *  seeded into the database on first run and used as a safe
 *  fallback if the database is unreachable — the public site
 *  never breaks.
 *
 *  Everything here can be overridden from the admin panel
 *  (/admin) once the app is running.
 * ============================================================
 */

import { IMAGES } from "./images";

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */

export interface ContactData {
  name: string;
  role: string;
  phone: string; // display format
  dial: string; // dialable format (tel:/sms:)
  email?: string;
}

export interface RideData {
  id: string;
  slug: string;
  title: string;
  location: string;
  date: string;
  distance: string;
  days: string;
  image: string;
  alt: string;
  excerpt: string;
  description: string;
  highlights: string[];
  route: string[];
  category: "featured" | "upcoming";
  order: number;
}

export interface GalleryImageData {
  id: string;
  src: string;
  alt: string;
  caption: string;
  category: string;
  order: number;
}

export interface VideoData {
  id: string;
  videoId: string;
  title: string;
  location: string;
  description: string;
  order: number;
}

export interface InstagramData {
  id: string;
  src: string;
  alt: string;
  /** Caption shown in the IG-style post viewer (falls back to alt) */
  caption: string;
  /** Location line under the username, as on Instagram */
  location: string;
  /** Like count shown in the viewer + grid hover */
  likes: number;
  /** Human timestamp, e.g. "3 days ago" / "February 19" */
  dateLabel: string;
  permalink: string;
  order: number;
}

/** A Real Stories article (blog post) — body uses a simple block format:
 *  "## Heading", "> Quote", "- List item", "![alt](src)" image, plain paragraphs. */
export interface StoryData {
  id: string;
  slug: string;
  title: string;
  dek: string;
  location: string;
  date: string;
  readTime: string;
  tag: string;
  cover: string;
  coverAlt: string;
  excerpt: string;
  body: string;
  order: number;
}

/** The subset of SiteSettings the public UI consumes. */
export interface SettingsData {
  heroEyebrow: string;
  heroTitle: string;
  heroSubtitle: string;
  heroText: string;
  heroVideoUrl: string;
  heroPoster: string;
  heroLocation: string;
  heroMetaLabel: string;

  ridesEyebrow: string;
  ridesTitle1: string;
  ridesTitle2: string;
  ridesNote: string;

  upcomingEyebrow: string;
  upcomingTitle1: string;
  upcomingTitle2: string;
  upcomingNote: string;

  aboutEyebrow: string;
  aboutTitle1: string;
  aboutTitle2: string;
  aboutLead: string;
  aboutLines: string[];
  aboutQuote: string;
  aboutImage: string;
  aboutCaption: string;

  galleryEyebrow: string;
  galleryTitle1: string;
  galleryTitle2: string;
  galleryNote: string;

  watchEyebrow: string;
  watchTitle1: string;
  watchTitle2: string;
  watchNote: string;

  instagramEyebrow: string;
  instagramTitle1: string;
  instagramTitle2: string;

  storiesEyebrow: string;
  storiesTitle1: string;
  storiesTitle2: string;
  storiesNote: string;

  joinEyebrow: string;
  joinTitle1: string;
  joinTitle2: string;
  joinText: string;

  upcomingBg: string;
  joinBg: string;

  popupEnabled: boolean;
  popupDelaySec: number;
  popupTitle1: string;
  popupTitle2: string;
  popupText: string;
  popupImage: string;

  youtubeUrl: string;
  youtubeHandle: string;
  instagramUrl: string;
  instagramHandle: string;
  contactEmail: string;
  contacts: ContactData[];

  ridesBannerImg: string;
  ridesBannerEyebrow: string;
  ridesBannerTitle: string;
  ridesBannerSub: string;

  aboutBannerImg: string;
  aboutBannerEyebrow: string;
  aboutBannerTitle: string;
  aboutBannerSub: string;

  galleryBannerImg: string;
  galleryBannerEyebrow: string;
  galleryBannerTitle: string;
  galleryBannerSub: string;

  watchBannerImg: string;
  watchBannerEyebrow: string;
  watchBannerTitle: string;
  watchBannerSub: string;

  joinBannerImg: string;
  joinBannerEyebrow: string;
  joinBannerTitle: string;
  joinBannerSub: string;

  storiesBannerImg: string;
  storiesBannerEyebrow: string;
  storiesBannerTitle: string;
  storiesBannerSub: string;
}

/* ------------------------------------------------------------------ */
/*  DEFAULTS                                                           */
/* ------------------------------------------------------------------ */

export const DEFAULT_CONTACTS: ContactData[] = [
  {
    name: "Yashraj Kohli",
    role: "Ride Lead · Founder",
    phone: "+91 99115 61887",
    dial: "+919911561887",
    email: "yashraj0611kohli@gmail.com",
  },
  {
    name: "Akshay Rana",
    role: "Ride Captain",
    phone: "+91 84494 16642",
    dial: "+918449416642",
  },
];

export const DEFAULT_SETTINGS: SettingsData = {
  heroEyebrow: "Mountains / Roads / Real Stories",
  heroTitle: "BROSONROADS",
  heroSubtitle: "Two wheels. Endless roads. Real experiences.",
  heroText:
    "We ride beyond the usual routes, chasing mountain roads, hidden places, changing weather and the stories that only happen when you travel on two wheels.",
  heroVideoUrl: "/videos/hero.mp4",
  heroPoster: "/videos/hero-poster.jpg",
  heroLocation: "Uttarakhand",
  heroMetaLabel: "The Journey Film",

  ridesEyebrow: "01 — Featured Rides",
  ridesTitle1: "Some Journeys",
  ridesTitle2: "Never End",
  ridesNote: "Every road leaves a story.",

  upcomingEyebrow: "02 — Upcoming Rides",
  upcomingTitle1: "The Road",
  upcomingTitle2: "Ahead",
  upcomingNote: "Some roads are worth planning for.",

  aboutEyebrow: "03 — About",
  aboutTitle1: "More Than",
  aboutTitle2: "Just Rides",
  aboutLead: "BrosonRoads is about the places between the destinations.",
  aboutLines: [
    "The mountain roads.",
    "The early starts.",
    "The unexpected weather.",
    "The roadside conversations.",
    "The broken plans.",
    "The views you only find when you take the longer route.",
  ],
  aboutQuote:
    "We document motorcycle journeys through the Himalayas and beyond — sharing the roads, destinations, experiences and stories that make every ride worth remembering.",
  aboutImage: IMAGES.IMG_ABOUT,
  aboutCaption: "Somewhere in Garhwal — 6:12 AM",

  galleryEyebrow: "04 — Gallery",
  galleryTitle1: "Frames From",
  galleryTitle2: "The Road",
  galleryNote: "Shot on the move — no staged moments.",

  watchEyebrow: "05 — YouTube",
  watchTitle1: "Watch The",
  watchTitle2: "Journey",
  watchNote:
    "The roads look different when you experience them from behind the bars.",

  instagramEyebrow: "06 — Instagram",
  instagramTitle1: "Follow The",
  instagramTitle2: "Journey",

  storiesEyebrow: "07 — Real Stories",
  storiesTitle1: "Stories From",
  storiesTitle2: "The Saddle",
  storiesNote:
    "Articles and ride journals from the crew — the roads, the people and everything in between.",

  joinEyebrow: "08 — Join Us",
  joinTitle1: "Want To",
  joinTitle2: "Ride It.",
  joinText:
    "Call, text or email us for details — we'll share dates, costs and everything you need to know.",

  upcomingBg: IMAGES.IMG_UPCOMING_BG,
  joinBg: IMAGES.IMG_JOIN_BG,

  popupEnabled: true,
  popupDelaySec: 20,
  popupTitle1: "Want to",
  popupTitle2: "ride with us?",
  popupText: "To ride with us, call, text or email us for details.",
  popupImage: IMAGES.IMG_POPUP_RIDE,

  youtubeUrl: "https://youtube.com/@bros_on_roads?si=hl5cgYvfhLmsXoJa",
  youtubeHandle: "@bros_on_roads",
  instagramUrl: "https://www.instagram.com/bros_on_roads/",
  instagramHandle: "@bros_on_roads",
  contactEmail: "yashraj0611kohli@gmail.com",
  contacts: DEFAULT_CONTACTS,

  ridesBannerImg: IMAGES.IMG_BANNER_RIDES,
  ridesBannerEyebrow: "Rides",
  ridesBannerTitle: "Every Ride Has A Story",
  ridesBannerSub:
    "Completed journeys and upcoming expeditions — documented from the saddle.",

  aboutBannerImg: IMAGES.IMG_BANNER_ABOUT,
  aboutBannerEyebrow: "About",
  aboutBannerTitle: "Built On Two Wheels",
  aboutBannerSub:
    "Who we are, how we ride and why we document every kilometre.",

  galleryBannerImg: IMAGES.IMG_BANNER_GALLERY,
  galleryBannerEyebrow: "Gallery",
  galleryBannerTitle: "The Road, In Frames",
  galleryBannerSub:
    "Every photograph was shot on a ride — mountains, weather, people and machines.",

  watchBannerImg: IMAGES.IMG_BANNER_WATCH,
  watchBannerEyebrow: "YouTube",
  watchBannerTitle: "Films From The Saddle",
  watchBannerSub:
    "Official BrosonRoads films — ride vlogs, shorts and full journeys.",

  joinBannerImg: IMAGES.IMG_BANNER_JOIN,
  joinBannerEyebrow: "Join Us",
  joinBannerTitle: "Ride With Us",
  joinBannerSub:
    "Tell us where you want to ride — or just call, text or email us directly.",

  storiesBannerImg: IMAGES.IMG_BANNER_STORIES,
  storiesBannerEyebrow: "Real Stories",
  storiesBannerTitle: "The Road Is The Story",
  storiesBannerSub:
    "Ride journals, articles and field notes from the BrosonRoads crew — written between the hairpins.",
};

export const DEFAULT_STORIES: StoryData[] = [
  {
    id: "monsoon-waterfall-diaries",
    slug: "monsoon-waterfall-diaries",
    title: "Monsoon Waterfall Diaries",
    dek: "Three days of rain, mist and roadside waterfalls in the Kedarnath valley.",
    location: "Kedarnath Valley, Uttarakhand",
    date: "August 2024",
    readTime: "5 min read",
    tag: "Ride Journal",
    cover: IMAGES.IMG_G1,
    coverAlt: "Motorcyclist riding through morning light on a wet Himalayan road",
    excerpt:
      "August turns Uttarakhand into a waterfall country you can hear before you see. We rode the monsoon backroads to find the falls that never make the maps.",
    body: [
      "The forecast said eighty percent rain for all three days. We went anyway. Somewhere past Rudraprayag the tarmac gave way to wet gravel, the mist dropped to arm's length, and the valley started to sound like a river that had escaped its banks.",
      "## The road that audits your commitment",
      "Monsoon riding is not about speed. It is about reading the road — a darker patch of tarmac could be a film of water, a pile of rounded stones could be yesterday's landslide. Every bend is a small question and the mountain expects a humble answer.",
      "> You don't conquer a monsoon road. You negotiate with it, and you say thank you when it lets you through.",
      "By the second morning we had stopped counting waterfalls. Some were curtains you could ride behind, some were thin white threads a few hundred metres up the cliff, and one was simply the road itself — a shallow sheet of flowing water for a hundred metres, with the Mandakini roaring somewhere below.",
      "![A monsoon waterfall falling through green forest in the Himalayas](" + IMAGES.IMG_WATERFALL + ")",
      "## Chai, and the mathematics of wet socks",
      "The roadside dhabas become churches in monsoon. We learnt to measure distances in cups of chai: two cups to Agastyamuni, one more to the landslide detour, three at the top because the rain demanded it. The people who run these stalls know every driver, every pilgrim, every idiot on a motorcycle. They fed us, dried our gloves over the tandoor and told us which fall was running 'full' today.",
      "- Start early — mountain rain is an afternoon creature.",
      "- Rain gloves fail before boots; carry two pairs.",
      "- If a stream crosses the road, walk it first. Every time.",
      "We came home with wet everything and a camera full of green. Some rides give you summits. This one gave us water — and the strange, quiet happiness of having ridden straight into the season everyone else waits out.",
    ].join("\n\n"),
    order: 0,
  },
  {
    id: "spiti-notes-from-the-cold-desert",
    slug: "spiti-notes-from-the-cold-desert",
    title: "Spiti: Notes From The Cold Desert",
    dek: "1,200 kilometres, one high pass and the silence of the highest villages on earth.",
    location: "Spiti Valley, Himachal",
    date: "July 2024",
    readTime: "7 min read",
    tag: "Expedition",
    cover: IMAGES.IMG_SPITI,
    coverAlt: "Barren high-altitude mountain landscape of Spiti Valley, Himachal Pradesh",
    excerpt:
      "Spiti is not a ride, it is an expedition. Field notes from a week in cold desert country — Kunzum La, Key Gompa and the emptiest roads in India.",
    body: [
      "There is a moment on the climb to Kunzum La where the last green disappears. The mountains stop pretending to be soft. You are left with rock, sky and a gravel road that tilts towards a drop with no name. That is the exact moment Spiti introduces itself.",
      "## Altitude is a tax you pay hourly",
      "We planned the crossing like accountants: extra fuel, spare levers, symptoms memorised. Above 4,000 metres every task is slower — unstrapping a bungee cord becomes a five-minute project. The trick nobody tells you is to drink water like it is your job and to let the slowest rider set the pace. The mountain does not care about your itinerary.",
      "> At 4,551 metres the wind has opinions. You listen.",
      "## Key Gompa, hanging between earth and sky",
      "Key Monastery sits on a hill like something grown rather than built — a thousand years of stacked rooms and prayer flags. We reached in the late afternoon light, engines ticking as they cooled, and sat in silence while the monks' chanting drifted through open windows. No photograph of this place is ever going to be enough. We took one anyway.",
      "![High Himalayan pass road with prayer flags](" + IMAGES.IMG_G11 + ")",
      "## The villages at the end of the map",
      "Kibber, Komic, Hikkim — names that sound like folklore until you ride to them. At Hikkim we posted postcards to ourselves from the highest post office on earth. The postmaster stamped them without ceremony, as if the whole world did not find this extraordinary.",
      "- Carry cash — the next ATM is a rumour.",
      "- Layers: mornings bite, afternoons burn, evenings punish.",
      "- Book Chandratal camps ahead; 'walk-in' is optimistic up there.",
      "The ride home was quiet. Not the tired quiet of a long day — the kind of quiet that happens when seven people are processing the same landscape at the same time. Spiti does that. It edits you.",
    ].join("\n\n"),
    order: 1,
  },
  {
    id: "chopta-a-weekend-above-the-clouds",
    slug: "chopta-a-weekend-above-the-clouds",
    title: "Chopta: A Weekend Above The Clouds",
    dek: "The world's highest Shiva temple, a sunrise summit and the best 280 kilometres in Uttarakhand.",
    location: "Chopta – Tungnath, Uttarakhand",
    date: "May 2024",
    readTime: "4 min read",
    tag: "Weekend Ride",
    cover: IMAGES.IMG_G8,
    coverAlt: "Temple trail above Chopta with snow peaks behind, Uttarakhand",
    excerpt:
      "Short distance, massive reward — how Chopta, Tungnath and Chandrashila deliver the most complete motorcycle weekend in the Himalayas.",
    body: [
      "Some rides are measured in kilometres. This one is measured in vertical metres. You park the bikes at Chopta — 'Mini Switzerland', the signboards insist — and from there the mountain goes vertical: 3.5 kilometres of stone steps to Tungnath, the highest Shiva temple on the planet.",
      "## The 4 AM arithmetic",
      "The plan was simple and terrible: wake at 4, start at 4:30, summit before sunrise. What the plan did not account for was the moonlight on the meadows, which stopped all conversation for a full minute. Some of the best frames of the trip were shot before the sun ever showed up.",
      "> Chandrashila at sunrise is a 360° argument for taking the longer route in life.",
      "From the summit the panorama stacks up like a flex: Nanda Devi, Trishul, Chaukhamba and the whole Garhwal wall laid out in one unbroken line. We shared coffee from a single flask with a team from Bangalore who had trekked through the night. The mountain makes instant friends of everyone.",
      "![Winding mountain road cutting through a green Himalayan valley](" + IMAGES.IMG_G2 + ")",
      "## Why this is the perfect first ride",
      "- Under 300 km of riding from Rishikesh — no exhaustion, no rest day needed.",
      "- Roads are beginner-friendly; the trek is the real workout.",
      "- Meadows for camping, homestays if the tent loses the argument.",
      "- Tea stalls at exactly the altitudes where you will need them.",
      "If you have been waiting for a sign to do your first Himalayan ride, this is it. Three days, one summit sunrise, and a temple older than most countries — all within a long weekend's reach of the plains.",
    ].join("\n\n"),
    order: 2,
  },
];

export const DEFAULT_RIDES: RideData[] = [
  {
    id: "valley-of-flowers",
    slug: "valley-of-flowers",
    title: "Valley of Flowers Ride",
    location: "Uttarakhand",
    date: "Jun 2024",
    distance: "320 KM",
    days: "4 Days",
    image: IMAGES.IMG_VALLEY,
    alt: "Blossoming Himalayan meadow in Valley of Flowers National Park, Uttarakhand",
    excerpt: "A monsoon ride into UNESCO's blooming high-altitude valley.",
    description:
      "The Valley of Flowers is one of those rides where the road feels like a warm-up act. We pushed through winding Himalayan roads, monsoon-washed ghat sections and river valleys before the trail opened into meadows that don't look real — hundreds of species of wildflowers framed by snow-dusted peaks. This ride is a reminder that Uttarakhand saves its best colours for the people willing to ride further.",
    highlights: [
      "Rishikesh to Joshimath along the Alaknanda river",
      "UNESCO World Heritage valley trek",
      "Monsoon waterfalls around every bend",
      "High-altitude meadows above 3,600 m",
    ],
    route: [],
    category: "featured",
    order: 0,
  },
  {
    id: "chopta-tungnath",
    slug: "chopta-tungnath",
    title: "Chopta – Tungnath – Chandrashila",
    location: "Uttarakhand",
    date: "May 2024",
    distance: "280 KM",
    days: "3 Days",
    image: IMAGES.IMG_CHOPTA,
    alt: "Tungnath temple trail above Chopta with Himalayan peaks, Uttarakhand",
    excerpt: "The highest Shiva temple on earth, reached on two wheels.",
    description:
      "Chopta, the 'Mini Switzerland' of Uttarakhand, is where this ride drops you into pure mountain silence. From the roadhead we climbed to Tungnath — the highest Shiva temple in the world — and then on to Chandrashila summit for a 360° panorama of Nanda Devi, Trishul and Chaukhamba. Short distance, massive reward. One of the most complete weekends you can have on a motorcycle in the Himalayas.",
    highlights: [
      "Sunrise views from Chandrashila summit",
      "World's highest Shiva temple at 3,680 m",
      "Dense deodar forests of the Mandakini valley",
      "Meadow campsites under clear Himalayan skies",
    ],
    route: [],
    category: "featured",
    order: 1,
  },
  {
    id: "hidden-waterfalls",
    slug: "hidden-waterfalls",
    title: "Hidden Waterfalls Ride",
    location: "Uttarakhand",
    date: "Aug 2024",
    distance: "210 KM",
    days: "3 Days",
    image: IMAGES.IMG_WATERFALL,
    alt: "Monsoon waterfall falling through green forest in Uttarakhand, India",
    excerpt: "Chasing monsoon waterfalls through Kumaon's green tunnels.",
    description:
      "August in Uttarakhand means one thing — water. We rode the monsoon-soaked backroads of the Kedarnath valley and beyond, hunting falls that don't appear on any map: curtain falls beside iron bridges, roadside cascades you can hear before you see, and jungle streams crossing the tarmac itself. The shortest ride we've documented, and somehow one of the richest.",
    highlights: [
      "Backroad ghat sections through rainforest",
      "Roadside falls you can ride right up to",
      "Rain, mist and mountain light for days",
      "Village chai stops in the middle of nowhere",
    ],
    route: [],
    category: "featured",
    order: 2,
  },
  {
    id: "spiti-expedition",
    slug: "spiti-expedition",
    title: "Spiti Valley Expedition",
    location: "Himachal",
    date: "Jul 2024",
    distance: "1,200 KM",
    days: "7 Days",
    image: IMAGES.IMG_SPITI,
    alt: "Barren high-altitude mountain landscape of Spiti Valley, Himachal Pradesh",
    excerpt: "A week in cold desert country — the ultimate Himalayan ride.",
    description:
      "Spiti is not a ride, it's an expedition. Over 1,200 kilometres we crossed the Kunzum La, rode alongside the Spiti river, and slept in some of the highest inhabited villages on the planet. Moonlike landscapes, ancient monasteries hanging over cliffs, and roads that demand everything from you and the machine. The benchmark every future ride will be measured against.",
    highlights: [
      "Kunzum La pass at 4,551 m",
      "Key Monastery and Dhankar cliffs",
      "Camping beside Chandratal lake",
      "Some of the highest motorable villages on earth",
    ],
    route: [],
    category: "featured",
    order: 3,
  },
  {
    id: "kedarnath-valley",
    slug: "kedarnath-valley",
    title: "Kedarnath Valley Ride",
    location: "Uttarakhand",
    date: "Oct 12–16, 2025",
    distance: "450 KM",
    days: "4 Days",
    image: IMAGES.IMG_KEDARNATH,
    alt: "Kedarnath valley surrounded by snow-capped Himalayan peaks, Uttarakhand",
    excerpt:
      "Deep into the Mandakini valley — temple towns, river roads and autumn light across the Garhwal Himalaya.",
    description:
      "Our autumn expedition deep into the Mandakini valley. Temple towns, river roads and golden autumn light across the Garhwal Himalaya — with the kind of small-town hospitality that only exists off the highway. Four days, 450 kilometres, and some of the most peaceful riding Uttarakhand has to offer.",
    highlights: [
      "Rishikesh → Rudraprayag → Agastyamuni",
      "Mandakini river gorge roads",
      "Ukhimath & Chopta side-loop",
      "Autumn ridgeline views of Kedarnath range",
    ],
    route: [
      "Rishikesh → Rudraprayag → Agastyamuni",
      "Mandakini river gorge roads",
      "Ukhimath & Chopta side-loop",
      "Autumn ridgeline views of Kedarnath range",
    ],
    category: "upcoming",
    order: 0,
  },
  {
    id: "spiti-ultimate",
    slug: "spiti-ultimate",
    title: "Spiti Valley – The Ultimate Ride",
    location: "Himachal",
    date: "Nov 08–12, 2025",
    distance: "1,200 KM",
    days: "5 Days",
    image: IMAGES.IMG_SPITI_2,
    alt: "High altitude road winding through the cold desert of Spiti Valley, Himachal",
    excerpt:
      "The full cold-desert crossing — high passes, ancient monasteries and the emptiest, highest roads in India.",
    description:
      "The full cold-desert crossing. Five days through Kinnaur and Spiti — high passes, ancient monasteries, and the emptiest, highest roads in India. This is the ride for people who want to feel very small in a very big landscape. Weather permitting we cross the Kunzum La and descend into Lahaul for the return.",
    highlights: [
      "Shimla → Kinnaur → Nako climb",
      "Tabo & Dhankar monastery circuits",
      "Kaza → Key → Kibber high villages",
      "Kunzum La crossing (weather permitting)",
    ],
    route: [
      "Shimla → Kinnaur → Nako climb",
      "Tabo & Dhankar monastery circuits",
      "Kaza → Key → Kibber high villages",
      "Kunzum La crossing (weather permitting)",
    ],
    category: "upcoming",
    order: 1,
  },
  {
    id: "nainital-mukteshwar",
    slug: "nainital-mukteshwar",
    title: "Nainital – Mukteshwar Ride",
    location: "Uttarakhand",
    date: "Dec 05–09, 2025",
    distance: "350 KM",
    days: "4 Days",
    image: IMAGES.IMG_NAINITAL,
    alt: "Nainital lake nestled in Kumaon hills, Uttarakhand, India",
    excerpt:
      "A winter Kumaon classic — lakes, orchards and pine ridgelines with first-snow chances at the top.",
    description:
      "A winter Kumaon classic. We loop the lakes — Bhimtal, Sattal, Naukuchiatal — then climb through pine forest to Mukteshwar's orchard roads at 2,286 metres, with a real chance of first snow at the top. Cold mornings, warm chai, and winter sunrise over Nanda Devi if the skies play along.",
    highlights: [
      "Kathgodam climb to Nainital lake",
      "Bhimtal, Sattal & Naukuchiatal lake loop",
      "Mukteshwar orchard roads at 2,286 m",
      "Winter sunrise over Nanda Devi",
    ],
    route: [
      "Kathgodam climb to Nainital lake",
      "Bhimtal, Sattal & Naukuchiatal lake loop",
      "Mukteshwar orchard roads at 2,286 m",
      "Winter sunrise over Nanda Devi",
    ],
    category: "upcoming",
    order: 2,
  },
];

export const DEFAULT_GALLERY: GalleryImageData[] = [
  { id: "g1", src: IMAGES.IMG_G1, alt: "Motorcyclist riding a Himalayan mountain road in Uttarakhand", caption: "Morning light on the climb", category: "Uttarakhand", order: 0 },
  { id: "g2", src: IMAGES.IMG_G2, alt: "Winding mountain road cutting through a green Himalayan valley", caption: "The road knows the way", category: "Himalayan Roads", order: 1 },
  { id: "g3", src: IMAGES.IMG_G3, alt: "Barren high-altitude landscape of Spiti Valley, Himachal Pradesh", caption: "Cold desert country", category: "Spiti", order: 2 },
  { id: "g4", src: IMAGES.IMG_G4, alt: "Waterfall crashing through monsoon forest in the Himalayas", caption: "Monsoon overflow", category: "Waterfalls", order: 3 },
  { id: "g5", src: IMAGES.IMG_G5, alt: "Camping tents glowing at dusk in the Himalayan mountains", caption: "Home for the night", category: "Camps", order: 4 },
  { id: "g6", src: IMAGES.IMG_G6, alt: "Riders resting beside motorcycles high in the mountains", caption: "Brothers of the road", category: "Riders", order: 5 },
  { id: "g7", src: IMAGES.IMG_G7, alt: "Sunset over a mountain pass with a lone motorcycle", caption: "Golden hour on the pass", category: "Sunset Rides", order: 6 },
  { id: "g8", src: IMAGES.IMG_G8, alt: "Temple trail above Chopta with snow peaks behind, Uttarakhand", caption: "Steps to Tungnath", category: "Uttarakhand", order: 7 },
  { id: "g9", src: IMAGES.IMG_G9, alt: "Nainital lake surrounded by Kumaon hills after rain", caption: "Lake country", category: "Uttarakhand", order: 8 },
  { id: "g10", src: IMAGES.IMG_G10, alt: "Motorcycle parked on a mountain road with valley view", caption: "Somewhere past the map", category: "Riders", order: 9 },
  { id: "g11", src: IMAGES.IMG_G11, alt: "High Himalayan pass road with prayer flags", caption: "Above the treeline", category: "Mountain Passes", order: 10 },
  { id: "g12", src: IMAGES.IMG_G12, alt: "River running through a green valley in Himachal Pradesh", caption: "Glacier water roads", category: "Himachal", order: 11 },
];

export const DEFAULT_VIDEOS: VideoData[] = [
  {
    id: "v1",
    videoId: "bFYuyV7l8Uc",
    title: "Bike Travel Vlog India — 20,000 KM Journey",
    location: "Feature Film",
    description:
      "20,000 kilometres across India on two wheels — the full Bros On Roads journey, packed into one film.",
    order: 0,
  },
  {
    id: "v2",
    videoId: "aef_zNnnDw8",
    title: "Men On Their Way",
    location: "YouTube Short",
    description:
      "Raw monsoon trails, misty peaks and two brothers chasing the kind of peace that only exists up in the mountains.",
    order: 1,
  },
  {
    id: "v3",
    videoId: "4SzYD8Cptvg",
    title: "River Rafting Ka Sabse Crazy Experience",
    location: "Rishikesh",
    description:
      "Off the bikes and into the rapids — the whole crew takes on Rishikesh river rafting and it goes exactly as crazy as you'd expect.",
    order: 2,
  },
];

export const DEFAULT_INSTAGRAM: InstagramData[] = [
  {
    id: "ig1", src: "/instagram/ig-real-1.jpg",
    alt: "Mountains heals me — real Instagram post from @bros_on_roads",
    caption: "Mountains heals me 🏔️",
    location: "Himalayas, Uttarakhand",
    likes: 1847, dateLabel: "February 19",
    permalink: "https://www.instagram.com/reel/DU8mEvkgacI/", order: 0,
  },
  {
    id: "ig2", src: "/instagram/ig-yt-2.jpg",
    alt: "Bros on Roads — mountain ride short from the crew",
    caption: "Brothers, bikes and a road that never ends. That's all we need.",
    location: "Garhwal, Uttarakhand",
    likes: 1236, dateLabel: "1 week ago",
    permalink: "https://www.instagram.com/bros_on_roads/", order: 1,
  },
  {
    id: "ig3", src: "/instagram/ig-yt-3.jpg",
    alt: "Bros on Roads — Himalayan trail on two wheels",
    caption: "Where the trail gets narrow, the grin gets wider.",
    location: "Himalayan trail",
    likes: 982, dateLabel: "2 weeks ago",
    permalink: "https://www.instagram.com/bros_on_roads/", order: 2,
  },
  {
    id: "ig4", src: "/instagram/ig-yt-4.jpg",
    alt: "Bros on Roads — riding through the high passes",
    caption: "High passes, low gears, full hearts.",
    location: "Spiti Valley, Himachal",
    likes: 2104, dateLabel: "3 weeks ago",
    permalink: "https://www.instagram.com/bros_on_roads/", order: 3,
  },
  {
    id: "ig5", src: "/instagram/ig-yt-5.jpg",
    alt: "Bros on Roads — monsoon roads of Uttarakhand",
    caption: "Monsoon has its own way of saying welcome back.",
    location: "Uttarakhand",
    likes: 764, dateLabel: "1 month ago",
    permalink: "https://www.instagram.com/bros_on_roads/", order: 4,
  },
  {
    id: "ig6", src: "/instagram/ig-yt-6.jpg",
    alt: "Bros on Roads — brothers of the road",
    caption: "Not all brothers are born together. Some are built on the road.",
    location: "Somewhere on NH-7",
    likes: 1593, dateLabel: "1 month ago",
    permalink: "https://www.instagram.com/bros_on_roads/", order: 5,
  },
  {
    id: "ig7", src: "/instagram/ig-yt-7.jpg",
    alt: "Bros on Roads — campsite under Himalayan skies",
    caption: "No walls, no roof, a thousand stars. The best hotel there is.",
    location: "Chopta, Uttarakhand",
    likes: 1341, dateLabel: "1 month ago",
    permalink: "https://www.instagram.com/bros_on_roads/", order: 6,
  },
  {
    id: "ig8", src: "/instagram/ig-yt-8.jpg",
    alt: "Bros on Roads — the journey continues",
    caption: "Every ride ends the same way — planning the next one.",
    location: "The road home",
    likes: 1098, dateLabel: "2 months ago",
    permalink: "https://www.instagram.com/bros_on_roads/", order: 7,
  },
];
