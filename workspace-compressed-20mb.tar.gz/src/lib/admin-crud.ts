import "server-only";

import { NextRequest, NextResponse } from "next/server";
import { assertAdminApi } from "@/lib/auth";
import { Prisma, PrismaClient } from "@prisma/client";

/**
 * Generic admin CRUD routes for the simple ordered collections
 * (gallery / videos / instagram). Every handler is auth-guarded.
 */

type Delegate = {
  findMany: (args?: Prisma.FindManyArgs) => Promise<unknown[]>;
  create: (args: { data: Prisma.InputJsonValue }) => Promise<unknown>;
  update: (args: { where: { id: string }; data: Prisma.InputJsonValue }) => Promise<unknown>;
  delete: (args: { where: { id: string } }) => Promise<unknown>;
};

export interface CollectionConfig {
  /** Prisma delegate, e.g. db.galleryImage */
  delegate: (db: PrismaClient) => Delegate;
  /** Whitelist: body key → converter (throws on invalid input) */
  fields: Record<string, (v: unknown) => string | number>;
  /** Required fields for create */
  required: string[];
}

function client(): PrismaClient {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { db } = require("@/lib/db") as { db: PrismaClient };
  return db;
}

export function makeListCreate(cfg: CollectionConfig) {
  return async function GET(req: NextRequest) {
    void req;
    const unauthorized = await assertAdminApi();
    if (unauthorized) return unauthorized;
    const rows = await cfg.delegate(client()).findMany({ orderBy: { order: "asc" } });
    return NextResponse.json(rows);
  };
}

export function makeCreate(cfg: CollectionConfig) {
  return async function POST(req: NextRequest) {
    const unauthorized = await assertAdminApi();
    if (unauthorized) return unauthorized;

    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
    }

    for (const key of cfg.required) {
      if (!String(body[key] ?? "").trim()) {
        return NextResponse.json({ error: `${key} is required` }, { status: 400 });
      }
    }

    const data: Record<string, string | number> = {};
    for (const [key, convert] of Object.entries(cfg.fields)) {
      if (key in body && body[key] !== undefined && body[key] !== null) {
        try {
          data[key] = convert(body[key]);
        } catch {
          return NextResponse.json({ error: `Invalid value for ${key}` }, { status: 400 });
        }
      }
    }

    try {
      const created = await cfg.delegate(client()).create({ data: data as Prisma.InputJsonValue });
      return NextResponse.json(created, { status: 201 });
    } catch {
      return NextResponse.json({ error: "Could not create item" }, { status: 500 });
    }
  };
}

export function makeUpdate(cfg: CollectionConfig) {
  return async function PATCH(
    req: NextRequest,
    { params }: { params: Promise<{ id: string }> }
  ) {
    const unauthorized = await assertAdminApi();
    if (unauthorized) return unauthorized;

    const { id } = await params;
    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
    }

    const data: Record<string, string | number> = {};
    for (const [key, convert] of Object.entries(cfg.fields)) {
      if (key in body && body[key] !== undefined && body[key] !== null) {
        try {
          data[key] = convert(body[key]);
        } catch {
          return NextResponse.json({ error: `Invalid value for ${key}` }, { status: 400 });
        }
      }
    }

    try {
      const updated = await cfg.delegate(client()).update({
        where: { id },
        data: data as Prisma.InputJsonValue,
      });
      return NextResponse.json(updated);
    } catch {
      return NextResponse.json({ error: "Item not found" }, { status: 404 });
    }
  };
}

/** Bound delete for a specific delegate. */
export function makeDeleteFor(cfg: CollectionConfig) {
  return async function DELETE(
    _req: NextRequest,
    { params }: { params: Promise<{ id: string }> }
  ) {
    const unauthorized = await assertAdminApi();
    if (unauthorized) return unauthorized;

    const { id } = await params;
    try {
      await cfg.delegate(client()).delete({ where: { id } });
      return NextResponse.json({ ok: true });
    } catch {
      return NextResponse.json({ error: "Item not found" }, { status: 404 });
    }
  };
}
