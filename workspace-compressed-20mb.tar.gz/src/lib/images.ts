/**
 * BROSONROADS — image slot URLs.
 * Generated from verified, reachable sources (each URL HEAD-checked).
 * Replace any slot with your own BrosonRoads photography when ready.
 */

export const IMAGES: Record<string, string> = {
  IMG_HERO_POSTER: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/7794746754e1.jpg",
  IMG_UPCOMING_BG: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/6203db906f85.jpg",
  IMG_JOIN_BG: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/c513cb03ecea.jpeg",
  IMG_ABOUT: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/74f486e9aa31.jpg",
  IMG_VALLEY: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/455cf3ec3286.png",
  IMG_CHOPTA: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/6925b8222e3a.png",
  IMG_WATERFALL: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/54a6d5e72f41.jpg",
  IMG_SPITI: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/8baa1ee36e75.jpg",
  IMG_KEDARNATH: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/95756c3388c8.png",
  IMG_SPITI_2: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/727fcb72df37.jpg",
  IMG_NAINITAL: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/66ade6855362.jpg",
  IMG_G1: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/7695788e41c1.jpg",
  IMG_G2: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/9fd2acc9a314.png",
  IMG_G3: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/f94b26952c79.jpg",
  IMG_G4: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/fb1b6a647010.jpg",
  IMG_G5: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/9e98381e446b.jpg",
  IMG_G6: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/0af0b8327455.jpg",
  IMG_G7: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/7d6296f24135.jpg",
  IMG_G8: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/989ae2a93385.jpg",
  IMG_G9: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/c649a76f4273.jpg",
  IMG_G10: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/a0ce0b3a127b.jpg",
  IMG_G11: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/8d93d3e7100d.jpg",
  IMG_G12: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/62795868540a.jpg",
  IMG_IG1: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/92781f7b7b1a.jpg",
  IMG_IG2: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/a6161cdb79f5.jpg",
  IMG_IG3: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/a36bd9c1c021.jpg",
  IMG_IG4: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/6b6d4cf08991.jpg",
  IMG_IG5: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/ae80585efc4f.jpeg",
  IMG_IG6: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/47a31f2bf0c6.jpg",
  IMG_IG7: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/29f2664b9d46.jpg",
  IMG_IG8: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/f1e104fa05c4.jpg",
  /** 20-second ride popup — group of riders together in the mountains */
  IMG_POPUP_RIDE: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/bfa720afe723.jpg",
  /* ---------- INTERNAL PAGE BANNERS — bikers in the mountains ---------- */
  IMG_BANNER_RIDES: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/48dfa774aabf.jpg",
  IMG_BANNER_ABOUT: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/fb4f62ce2e79.jpg",
  IMG_BANNER_GALLERY: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/fa30409c6992.jpg",
  IMG_BANNER_WATCH: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/18c65cd5ce4b.jpg",
  IMG_BANNER_JOIN: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/3d5e8c3c5b52.jpg",
  IMG_BANNER_STORIES: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/8d93d3e7100d.jpg",
  IMG_BANNER_RIDE_FALLBACK: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/94522f139dca.jpg",
};
