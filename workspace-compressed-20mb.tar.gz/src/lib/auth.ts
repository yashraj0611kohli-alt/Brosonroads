import "server-only";

import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "./db";

/**
 * ============================================================
 *  BROSONROADS — ADMIN AUTHENTICATION
 * ============================================================
 *  Credentials are stored ONLY as a scrypt hash in the database
 *  (AdminUser). They are never rendered, logged or exposed by
 *  any page or API. Sessions are stateless: an HMAC-signed
 *  HttpOnly cookie that expires automatically.
 * ============================================================
 */

export const SESSION_COOKIE = "br_admin_session";
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

function secret(): string {
  return process.env.ADMIN_SECRET || "brosonroads-local-dev-secret-v1";
}

/* ---------------- password hashing (scrypt) ---------------- */

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (candidate.length !== expected.length) return false;
  return timingSafeEqual(candidate, expected);
}

/* ---------------- signed session cookie ---------------- */

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function createSessionToken(username: string): string {
  const payload = Buffer.from(
    JSON.stringify({ u: username, exp: Date.now() + SESSION_TTL_MS })
  ).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

/** Returns the signed-in username, or null for invalid/expired tokens. */
export function sessionUsername(token: string | undefined): string | null {
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expectedSig = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const { u, exp } = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (typeof u !== "string" || typeof exp !== "number" || Date.now() >= exp) {
      return null;
    }
    return u;
  } catch {
    return null;
  }
}

export const sessionCookieOptions = {
  httpOnly: true,
  sameSite: "lax" as const,
  secure: process.env.NODE_ENV === "production",
  path: "/",
  maxAge: SESSION_TTL_MS / 1000,
};

/* ---------------- guards ---------------- */

/** For server components — returns true when a valid session exists. */
export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  return sessionUsername(store.get(SESSION_COOKIE)?.value) !== null;
}

/** For admin pages — redirects to the login screen when not authed. */
export async function requireAdmin(): Promise<void> {
  if (!(await isAdmin())) redirect("/admin/login");
}

/** For API routes — returns a 401 Response when not authed, else null. */
export async function assertAdminApi(): Promise<Response | null> {
  const store = await cookies();
  if (sessionUsername(store.get(SESSION_COOKIE)?.value) !== null) return null;
  return new Response(JSON.stringify({ error: "Unauthorized" }), {
    status: 401,
    headers: { "Content-Type": "application/json" },
  });
}

/** Current signed-in admin's username (call after assertAdminApi). */
export async function currentAdminUsername(): Promise<string> {
  const store = await cookies();
  return sessionUsername(store.get(SESSION_COOKIE)?.value) ?? "";
}

/* ---------------- login + rate limiting ---------------- */

const attempts = new Map<string, { count: number; first: number }>();
const WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 6;

export function rateLimited(key: string): boolean {
  const now = Date.now();
  const rec = attempts.get(key);
  if (!rec || now - rec.first > WINDOW_MS) {
    attempts.set(key, { count: 1, first: now });
    return false;
  }
  rec.count += 1;
  return rec.count > MAX_ATTEMPTS;
}

export function clearRateLimit(key: string): void {
  attempts.delete(key);
}

/**
 * Verify a login attempt against the AdminUser table.
 * The admin user is seeded by scripts/seed.ts — this function
 * never reveals whether the username or the password was wrong.
 */
export async function checkCredentials(
  username: string,
  password: string
): Promise<boolean> {
  try {
    const user = await db.adminUser.findUnique({ where: { username } });
    if (!user) return false;
    return verifyPassword(password, user.passwordHash);
  } catch {
    return false;
  }
}
