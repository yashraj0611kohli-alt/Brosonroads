import "server-only";

import { db } from "./db";
import {
  DEFAULT_CONTACTS,
  DEFAULT_GALLERY,
  DEFAULT_INSTAGRAM,
  DEFAULT_RIDES,
  DEFAULT_SETTINGS,
  DEFAULT_STORIES,
  DEFAULT_VIDEOS,
  type GalleryImageData,
  type InstagramData,
  type RideData,
  type SettingsData,
  type StoryData,
  type VideoData,
} from "./defaults";

/**
 * Server-side data access layer.
 * Every getter reads from the database (editable via /admin) and
 * falls back to DEFAULT_* content if the DB is empty or errors —
 * the public site must never go down because of the CMS.
 */

function parseJsonArray(raw: string): string[] {
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v.map(String) : [];
  } catch {
    return [];
  }
}

export async function getSettings(): Promise<SettingsData> {
  try {
    const row = await db.siteSettings.findUnique({ where: { id: "main" } });
    if (!row) return DEFAULT_SETTINGS;
    let contacts = DEFAULT_CONTACTS;
    try {
      const parsed = JSON.parse(row.contactsJson);
      if (Array.isArray(parsed) && parsed.length > 0) contacts = parsed;
    } catch {
      /* keep default contacts */
    }
    const merged = {
      ...DEFAULT_SETTINGS,
      ...row,
      aboutLines: parseJsonArray(row.aboutLines),
      contacts,
    } as unknown as SettingsData;

    /* Empty image fields fall back to the bundled defaults — an admin
       clearing a field sees the built-in visual instead of a blank. */
    const imageKeys: Array<keyof SettingsData> = [
      "heroVideoUrl",
      "heroPoster",
      "aboutImage",
      "popupImage",
      "upcomingBg",
      "joinBg",
      "ridesBannerImg",
      "aboutBannerImg",
      "galleryBannerImg",
      "watchBannerImg",
      "joinBannerImg",
      "storiesBannerImg",
    ];
    for (const k of imageKeys) {
      if (!(merged[k] as string)) {
        (merged[k] as string) = DEFAULT_SETTINGS[k] as string;
      }
    }
    return merged;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function mapRide(r: {
  id: string;
  slug: string;
  title: string;
  location: string;
  date: string;
  distance: string;
  days: string;
  image: string;
  alt: string;
  excerpt: string;
  description: string;
  highlightsJson: string;
  routeJson: string;
  category: string;
  order: number;
}): RideData {
  return {
    ...r,
    category: r.category === "upcoming" ? "upcoming" : "featured",
    highlights: parseJsonArray(r.highlightsJson),
    route: parseJsonArray(r.routeJson),
  };
}

export async function getRides(category?: "featured" | "upcoming"): Promise<RideData[]> {
  try {
    const rows = await db.ride.findMany({
      where: {
        published: true,
        ...(category ? { category } : {}),
      },
      orderBy: [{ order: "asc" }, { createdAt: "desc" }],
    });
    if (rows.length === 0 && !category) return DEFAULT_RIDES;
    return rows.map(mapRide);
  } catch {
    return category
      ? DEFAULT_RIDES.filter((r) => r.category === category)
      : DEFAULT_RIDES;
  }
}

export async function getRideBySlug(slug: string): Promise<RideData | null> {
  try {
    const row = await db.ride.findUnique({ where: { slug } });
    if (row && row.published) return mapRide(row);
  } catch {
    /* fall through to defaults */
  }
  return DEFAULT_RIDES.find((r) => r.slug === slug) ?? null;
}

export async function getGallery(): Promise<GalleryImageData[]> {
  try {
    const rows = await db.galleryImage.findMany({ orderBy: { order: "asc" } });
    if (rows.length === 0) return DEFAULT_GALLERY;
    return rows.map((r) => ({ ...r }));
  } catch {
    return DEFAULT_GALLERY;
  }
}

export async function getVideos(): Promise<VideoData[]> {
  try {
    const rows = await db.videoItem.findMany({ orderBy: { order: "asc" } });
    if (rows.length === 0) return DEFAULT_VIDEOS;
    return rows.map((r) => ({ ...r }));
  } catch {
    return DEFAULT_VIDEOS;
  }
}

export async function getInstagram(): Promise<InstagramData[]> {
  try {
    const rows = await db.instagramPost.findMany({ orderBy: { order: "asc" } });
    if (rows.length === 0) return DEFAULT_INSTAGRAM;
    return rows.map((r) => ({ ...r }));
  } catch {
    return DEFAULT_INSTAGRAM;
  }
}

function mapStory(s: {
  id: string;
  slug: string;
  title: string;
  dek: string;
  location: string;
  date: string;
  readTime: string;
  tag: string;
  cover: string;
  coverAlt: string;
  excerpt: string;
  body: string;
  order: number;
}): StoryData {
  return { ...s };
}

export async function getStories(): Promise<StoryData[]> {
  try {
    const rows = await db.story.findMany({
      where: { published: true },
      orderBy: [{ order: "asc" }, { createdAt: "desc" }],
    });
    if (rows.length === 0) return DEFAULT_STORIES;
    return rows.map(mapStory);
  } catch {
    return DEFAULT_STORIES;
  }
}

export async function getStoryBySlug(slug: string): Promise<StoryData | null> {
  try {
    const row = await db.story.findUnique({ where: { slug } });
    if (row && row.published) return mapStory(row);
  } catch {
    /* fall through to defaults */
  }
  return DEFAULT_STORIES.find((s) => s.slug === slug) ?? null;
}
