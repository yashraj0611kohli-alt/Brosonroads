"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import { X, ArrowUpRight, MapPin } from "lucide-react";
import { SafeImage } from "./safe-image";
import { BROSONROADS } from "@/lib/site";

export interface RideDetailData {
  title: string;
  location: string;
  image: string;
  alt: string;
  description: string;
  bullets: { heading: string; items: string[] };
  stats: { label: string; value: string }[];
  /** When set, a "full story" link points at the ride's own page */
  slug?: string;
}

interface RideDetailModalProps {
  open: boolean;
  onClose: () => void;
  ride: RideDetailData | null;
}

/**
 * Ride detail view — opens as a full-screen editorial overlay.
 * ESC / backdrop / close button dismiss; body scroll locked.
 */
export function RideDetailModal({ open, onClose, ride }: RideDetailModalProps) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    closeRef.current?.focus();
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (!open || !ride) return null;

  return (
    <div
      className="modal-backdrop fixed inset-0 z-[90] overflow-y-auto bg-black/85 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label={`${ride.title} — details`}
      onClick={onClose}
    >
      <button
        ref={closeRef}
        onClick={onClose}
        aria-label="Close ride details"
        className="fixed right-4 top-4 z-20 flex h-11 w-11 items-center justify-center border border-white/25 bg-black/60 text-white transition-colors duration-300 hover:border-white hover:bg-white hover:text-black sm:right-6 sm:top-6"
      >
        <X className="h-5 w-5" strokeWidth={1.5} />
      </button>

      <div
        className="modal-panel relative mx-auto my-6 w-[calc(100%-2rem)] max-w-4xl border border-white/10 bg-[#0F0F0F] sm:my-10"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Hero image */}
        <div className="relative h-56 w-full overflow-hidden sm:h-72 md:h-96">
          <SafeImage src={ride.image} alt={ride.alt} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-black/40" />
          <div className="absolute bottom-0 left-0 p-6 sm:p-9">
            <p className="eyebrow mb-2 flex items-center gap-2">
              <MapPin className="h-3.5 w-3.5 text-[#D97F3E]" strokeWidth={1.5} />
              {ride.location}
            </p>
            <h3 className="display-title max-w-xl text-2xl font-bold text-white sm:text-4xl">
              {ride.title}
            </h3>
          </div>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-3 divide-x divide-white/10 border-y border-white/10">
          {ride.stats.map((s) => (
            <div key={s.label} className="px-4 py-5 text-center sm:px-6 sm:py-6">
              <p className="display-title text-lg font-bold text-white sm:text-2xl">{s.value}</p>
              <p className="eyebrow mt-1 !text-[9px] sm:!text-[10px]">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Body */}
        <div className="p-6 sm:p-9">
          <p className="text-[15px] leading-relaxed text-[#D7D7D7]">{ride.description}</p>

          <div className="mt-8">
            <p className="eyebrow mb-4">{ride.bullets.heading}</p>
            <ul className="space-y-3">
              {ride.bullets.items.map((item) => (
                <li key={item} className="flex items-start gap-3 text-sm text-[#929292]">
                  <span className="mt-[7px] h-1 w-4 shrink-0 bg-[#D97F3E]" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            {ride.slug ? (
              <Link
                href={`/rides/${ride.slug}`}
                className="inline-flex items-center gap-2 bg-white px-6 py-3.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-black transition-colors duration-300 hover:bg-[#D97F3E]"
              >
                Open full story
                <ArrowUpRight className="h-4 w-4" strokeWidth={1.5} />
              </Link>
            ) : null}
            <a
              href={BROSONROADS.social.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 border border-white/25 px-6 py-3.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition-all duration-300 hover:border-white hover:bg-white hover:text-black"
            >
              Watch the film on YouTube
              <ArrowUpRight className="h-4 w-4" strokeWidth={1.5} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
