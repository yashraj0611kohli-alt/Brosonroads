"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight, CalendarDays, Route, Clock } from "lucide-react";
import type { RideData, SettingsData } from "@/lib/defaults";
import { Reveal } from "./reveal";
import { SafeImage } from "./safe-image";
import { RideDetailModal, type RideDetailData } from "./ride-detail-modal";

function toDetail(ride: RideData): RideDetailData {
  return {
    title: ride.title,
    location: ride.location,
    image: ride.image,
    alt: ride.alt,
    description: ride.description || ride.excerpt,
    bullets: { heading: "Planned route", items: ride.route },
    stats: [
      { label: "Distance", value: ride.distance },
      { label: "Duration", value: ride.days },
      { label: "Dates", value: ride.date },
    ],
    slug: ride.slug,
  };
}

interface UpcomingRidesProps {
  rides: RideData[];
  s: SettingsData;
}

/**
 * "The Road Ahead" — dark cinematic section with a large mountain
 * backdrop, editorial ride rows linking to full ride pages.
 */
export function UpcomingRides({ rides, s }: UpcomingRidesProps) {
  const [detail, setDetail] = useState<RideDetailData | null>(null);

  return (
    <section id="upcoming" aria-labelledby="upcoming-heading" className="relative scroll-mt-20 overflow-hidden bg-[#0B0B0B]">
      {/* Backdrop mountain imagery */}
      <div className="absolute inset-0" aria-hidden="true">
        <SafeImage
          src={s.upcomingBg}
          alt=""
          className="h-full w-full object-cover"
          draggable={false}
        />
        <div className="absolute inset-0 bg-[#0B0B0B]/82" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B0B0B] via-transparent to-[#0B0B0B]" />
      </div>

      <div className="relative z-10 mx-auto max-w-[1600px] px-5 py-24 sm:px-8 md:px-10 md:py-36">
        {/* Header */}
        <div className="mb-14 flex flex-col gap-6 md:mb-16 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <p className="eyebrow mb-4">{s.upcomingEyebrow}</p>
            <h2 id="upcoming-heading" className="display-title text-4xl font-bold text-white sm:text-5xl md:text-6xl">
              {s.upcomingTitle1} <span className="text-outline">{s.upcomingTitle2}</span>
            </h2>
          </Reveal>
          <Reveal delay={120}>
            <p className="max-w-xs text-sm leading-relaxed text-[#929292] md:text-right">
              {s.upcomingNote}
            </p>
          </Reveal>
        </div>

        {/* Ride rows */}
        <div className="border-t border-white/10">
          {rides.map((ride, i) => (
            <Reveal key={ride.id} delay={i * 80}>
              <div className="group grid grid-cols-1 gap-5 border-b border-white/10 py-8 transition-colors duration-500 hover:bg-white/[0.03] md:grid-cols-12 md:items-center md:gap-6 md:py-10">
                {/* Index + title */}
                <div className="md:col-span-6 md:pr-6">
                  <div className="flex items-baseline gap-5">
                    <span className="hidden text-[11px] tracking-[0.3em] text-[#D97F3E] md:block">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <div>
                      <h3 className="display-title text-2xl font-bold text-white sm:text-3xl md:text-4xl">
                        {ride.title}
                      </h3>
                      <p className="mt-1.5 text-[11px] uppercase tracking-[0.25em] text-[#929292]">
                        {ride.location}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Meta */}
                <div className="flex flex-wrap gap-x-7 gap-y-2 md:col-span-4 md:flex-col md:gap-2.5">
                  <span className="flex items-center gap-2.5 text-[11px] uppercase tracking-[0.2em] text-[#D7D7D7]">
                    <CalendarDays className="h-3.5 w-3.5 text-[#D97F3E]" strokeWidth={1.5} />
                    {ride.date}
                  </span>
                  <div className="flex gap-7">
                    <span className="flex items-center gap-2.5 text-[11px] uppercase tracking-[0.2em] text-[#929292]">
                      <Route className="h-3.5 w-3.5" strokeWidth={1.5} />
                      {ride.distance}
                    </span>
                    <span className="flex items-center gap-2.5 text-[11px] uppercase tracking-[0.2em] text-[#929292]">
                      <Clock className="h-3.5 w-3.5" strokeWidth={1.5} />
                      {ride.days}
                    </span>
                  </div>
                </div>

                {/* CTA */}
                <div className="flex gap-3 md:col-span-2 md:flex-col md:items-end">
                  <button
                    onClick={() => setDetail(toDetail(ride))}
                    className="group/cta inline-flex items-center gap-3 border border-white/25 px-6 py-3.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition-all duration-300 hover:border-[#D97F3E] hover:bg-[#D97F3E] hover:text-black"
                    aria-label={`View details for ${ride.title}`}
                  >
                    View Ride
                    <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover/cta:translate-x-1" strokeWidth={1.5} />
                  </button>
                  <Link
                    href={`/rides/${ride.slug}`}
                    className="inline-flex items-center gap-2 px-1 py-3.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-[#929292] transition-colors duration-300 hover:text-white"
                    aria-label={`Open the full ${ride.title} page`}
                  >
                    Full page
                    <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.5} />
                  </Link>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      <RideDetailModal
        open={detail !== null}
        onClose={() => setDetail(null)}
        ride={detail}
      />
    </section>
  );
}
