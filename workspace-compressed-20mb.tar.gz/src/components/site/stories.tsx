import Link from "next/link";
import { ArrowUpRight, ArrowRight, MapPin, CalendarDays, Clock3 } from "lucide-react";
import type { SettingsData, StoryData } from "@/lib/defaults";
import { Reveal } from "./reveal";
import { SafeImage } from "./safe-image";

/**
 * Real Stories — editorial magazine layout for the crew's articles
 * and ride journals. Three presentations:
 *  - StoryCard          — shared card (feature / compact variants)
 *  - StoriesSection     — homepage teaser (dark cinematic block)
 *  - StoriesIndex       — the /stories index (paper-white magazine)
 */

function Meta({ story, dark }: { story: StoryData; dark?: boolean }) {
  const cls = `flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] uppercase tracking-[0.18em] ${
    dark ? "text-[#929292]" : "text-[#8a877f]"
  }`;
  return (
    <div className={cls}>
      {story.location ? (
        <span className="inline-flex items-center gap-1.5">
          <MapPin className="h-3.5 w-3.5 text-[#D97F3E]" strokeWidth={1.5} />
          {story.location}
        </span>
      ) : null}
      {story.date ? (
        <span className="inline-flex items-center gap-1.5">
          <CalendarDays className="h-3.5 w-3.5" strokeWidth={1.5} />
          {story.date}
        </span>
      ) : null}
      {story.readTime ? (
        <span className="inline-flex items-center gap-1.5">
          <Clock3 className="h-3.5 w-3.5" strokeWidth={1.5} />
          {story.readTime}
        </span>
      ) : null}
    </div>
  );
}

function Tag({ children, dark }: { children: React.ReactNode; dark?: boolean }) {
  return (
    <span
      className={`inline-block border px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.22em] ${
        dark ? "border-[#D97F3E]/60 text-[#D97F3E]" : "border-[#D97F3E] text-[#B4632A]"
      }`}
    >
      {children}
    </span>
  );
}

function StoryImage({ story, className }: { story: StoryData; className: string }) {
  return (
    <SafeImage
      src={story.cover}
      alt={story.coverAlt || story.title}
      className={`${className} h-full w-full object-cover transition-transform duration-[1100ms] ease-out group-hover:scale-[1.06]`}
      draggable={false}
    />
  );
}

/* ------------------------------------------------------------------ */
/*  CARDS                                                              */
/* ------------------------------------------------------------------ */

function FeatureCard({ story, dark }: { story: StoryData; dark?: boolean }) {
  return (
    <Link
      href={`/stories/${story.slug}`}
      className={`group grid overflow-hidden border transition-colors duration-500 md:grid-cols-2 ${
        dark
          ? "border-white/10 bg-[#151515] hover:border-[#D97F3E]/50"
          : "border-black/10 bg-white hover:border-[#D97F3E]"
      }`}
    >
      <div className="relative aspect-[16/10] overflow-hidden md:aspect-auto md:min-h-[340px]">
        <StoryImage story={story} className="" />
      </div>
      <div className="flex flex-col justify-center gap-4 p-7 md:p-10">
        <Tag dark={dark}>{story.tag}</Tag>
        <h3
          className={`display-title text-2xl font-bold leading-[1.02] sm:text-3xl md:text-4xl ${
            dark ? "text-white" : "text-[#111111]"
          }`}
        >
          {story.title}
        </h3>
        {story.dek ? (
          <p className={`text-[15px] font-medium leading-relaxed md:text-base ${dark ? "text-[#D7D7D7]" : "text-[#3D3B36]"}`}>
            {story.dek}
          </p>
        ) : null}
        <p className={`text-sm leading-relaxed ${dark ? "text-[#929292]" : "text-[#6E6C66]"}`}>
          {story.excerpt}
        </p>
        <Meta story={story} dark={dark} />
        <span
          className={`mt-1 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] ${
            dark ? "text-white group-hover:text-[#D97F3E]" : "text-[#111111] group-hover:text-[#B4632A]"
          } transition-colors`}
        >
          Read the story
          <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" strokeWidth={1.75} />
        </span>
      </div>
    </Link>
  );
}

function CompactCard({ story, dark }: { story: StoryData; dark?: boolean }) {
  return (
    <Link
      href={`/stories/${story.slug}`}
      className={`group flex h-full flex-col overflow-hidden border transition-colors duration-500 ${
        dark
          ? "border-white/10 bg-[#151515] hover:border-[#D97F3E]/50"
          : "border-black/10 bg-white hover:border-[#D97F3E]"
      }`}
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <StoryImage story={story} className="" />
      </div>
      <div className="flex flex-1 flex-col gap-3.5 p-6 md:p-7">
        <Tag dark={dark}>{story.tag}</Tag>
        <h3
          className={`display-title text-xl font-bold leading-tight sm:text-2xl ${
            dark ? "text-white" : "text-[#111111]"
          }`}
        >
          {story.title}
        </h3>
        <p className={`line-clamp-3 text-sm leading-relaxed ${dark ? "text-[#929292]" : "text-[#6E6C66]"}`}>
          {story.dek || story.excerpt}
        </p>
        <div className="mt-auto pt-2">
          <Meta story={story} dark={dark} />
        </div>
      </div>
    </Link>
  );
}

/* ------------------------------------------------------------------ */
/*  HOMEPAGE SECTION — dark cinematic teaser                           */
/* ------------------------------------------------------------------ */

export function StoriesSection({ stories, s }: { stories: StoryData[]; s: SettingsData }) {
  if (stories.length === 0) return null;
  const [feature, ...rest] = stories;

  return (
    <section id="stories" aria-labelledby="stories-heading" className="scroll-mt-20 bg-[#0B0B0B] py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
        <div className="mb-14 flex flex-col gap-6 md:mb-16 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <p className="eyebrow mb-4">{s.storiesEyebrow}</p>
            <h2 id="stories-heading" className="display-title text-4xl font-bold text-white sm:text-5xl md:text-6xl">
              {s.storiesTitle1}
              <br />
              <span className="text-outline">{s.storiesTitle2}</span>
            </h2>
          </Reveal>
          <Reveal delay={120}>
            <p className="max-w-sm text-sm leading-relaxed text-[#929292] md:text-right">
              {s.storiesNote}
            </p>
          </Reveal>
        </div>

        <Reveal variant="fade-up">
          <FeatureCard story={feature} dark />
        </Reveal>

        {rest.length > 0 ? (
          <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
            {rest.slice(0, 2).map((story, i) => (
              <Reveal key={story.id} delay={i * 110}>
                <CompactCard story={story} dark />
              </Reveal>
            ))}
          </div>
        ) : null}

        <Reveal delay={140} className="mt-12 flex justify-center">
          <Link
            href="/stories"
            className="group inline-flex items-center gap-3 border border-white/25 px-8 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition-all duration-300 hover:border-white hover:bg-white hover:text-black"
          >
            Read all stories
            <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" strokeWidth={1.5} />
          </Link>
        </Reveal>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  /STORIES INDEX — paper-white magazine                              */
/* ------------------------------------------------------------------ */

export function StoriesIndex({ stories }: { stories: StoryData[] }) {
  if (stories.length === 0) {
    return (
      <section className="bg-[#F5F4F0] py-24 md:py-32">
        <div className="mx-auto max-w-2xl px-5 text-center sm:px-8">
          <p className="eyebrow eyebrow-dark mb-4">Real Stories</p>
          <h2 className="display-title text-3xl font-bold text-[#111111] sm:text-4xl">
            The first story is still on the road.
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-[#6E6C66]">
            We are writing it right now — check back soon.
          </p>
        </div>
      </section>
    );
  }

  const [feature, ...rest] = stories;

  return (
    <section className="bg-[#F5F4F0] py-20 md:py-28">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
        <Reveal>
          <FeatureCard story={feature} />
        </Reveal>

        {rest.length > 0 ? (
          <>
            <div className="my-14 flex items-center gap-5" aria-hidden="true">
              <span className="h-px flex-1 bg-black/10" />
              <span className="eyebrow eyebrow-dark">More stories</span>
              <span className="h-px flex-1 bg-black/10" />
            </div>
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {rest.map((story, i) => (
                <Reveal key={story.id} delay={(i % 3) * 90}>
                  <CompactCard story={story} />
                </Reveal>
              ))}
            </div>
          </>
        ) : null}
      </div>
    </section>
  );
}
