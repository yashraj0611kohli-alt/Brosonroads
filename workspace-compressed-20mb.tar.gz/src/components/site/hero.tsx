"use client";

import { useRef, useState, useSyncExternalStore } from "react";
import { Play } from "lucide-react";
import type { SettingsData } from "@/lib/defaults";
import { VideoModal } from "./video-modal";
import { SafeImage } from "./safe-image";

/**
 * Full-screen cinematic hero.
 * - Self-hosted BrosonRoads film (public/videos/hero.mp4) plays as a
 *   muted, looped background: poster paints instantly, the video fades
 *   in once playback starts; if the file can't load, the poster stays.
 * - prefers-reduced-motion: the background film does not autoplay —
 *   the still poster is shown instead.
 * - Bottom meta bar carries a live clip readout + progress line driven
 *   by the video's real currentTime (not a fake CSS loop).
 * - Circular play button + WATCH OUR JOURNEY open the video modal,
 *   which plays the same film with sound and controls.
 */

const fmtTime = (s: number) => {
  if (!Number.isFinite(s) || s < 0) s = 0;
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${String(sec).padStart(2, "0")}`;
};

/**
 * Brand lockup for the hero headline — renders the BROSONROADS
 * wordmark as a balanced two-line editorial composition:
 *   BROS          (solid white)
 *   ON ROADS      ("ON" in brand orange, "ROADS" outlined)
 * Any other admin-entered title renders verbatim on one line.
 */
function BrandTitle({ title }: { title: string }) {
  if (/^brosonroads$/i.test(title.replace(/\s+/g, ""))) {
    return (
      <>
        <span className="block">BROS</span>
        <span className="block">
          <span className="text-[#D97F3E]">ON</span>
          <span className="text-outline">ROADS</span>
        </span>
      </>
    );
  }
  return <>{title}</>;
}

export function Hero({ s }: { s: SettingsData }) {
  const [videoModalOpen, setVideoModalOpen] = useState(false);
  const [bgActive, setBgActive] = useState(false);
  const [bgFailed, setBgFailed] = useState(false);
  const [clip, setClip] = useState({ t: 0, d: 12.7 });
  const videoRef = useRef<HTMLVideoElement | null>(null);

  /* Respect reduced-motion: no autoplaying background film.
     Subscribes reactively so toggling the OS preference live-switches. */
  const motionOK = useSyncExternalStore(
    (onStoreChange) => {
      const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
      mq.addEventListener("change", onStoreChange);
      return () => mq.removeEventListener("change", onStoreChange);
    },
    () => !window.matchMedia("(prefers-reduced-motion: reduce)").matches,
    () => true /* SSR snapshot — motion assumed OK until hydrated */
  );

  const heroVideo = s.heroVideoUrl;
  const heroPoster = s.heroPoster;

  return (
    <section
      id="home"
      aria-label="BrosonRoads — motorcycle journeys through the Himalayas"
      className="grain relative flex min-h-[100svh] flex-col justify-end overflow-hidden bg-[#0B0B0B]"
    >
      {/* Poster frame (instant paint, always-present fallback) */}
      <div className="absolute inset-0" aria-hidden={bgActive}>
        <SafeImage
          src={heroPoster}
          alt="BrosonRoads riders on a Himalayan mountain road — still frame from the journey film"
          priority
          className={`h-full w-full object-cover ${bgActive ? "" : "animate-[hero-drift_18s_ease-in-out_infinite_alternate]"}`}
          draggable={false}
        />
      </div>

      {/* Muted, looped, autoplaying background film (self-hosted) */}
      {motionOK && !bgFailed && (
        <video
          ref={videoRef}
          src={heroVideo}
          muted
          loop
          autoPlay
          playsInline
          preload="auto"
          disablePictureInPicture
          tabIndex={-1}
          aria-hidden="true"
          onPlaying={() => setBgActive(true)}
          onLoadedMetadata={(e) => {
            const d = e.currentTarget.duration;
            if (Number.isFinite(d)) setClip((c) => ({ ...c, d }));
          }}
          onTimeUpdate={(e) => {
            /* capture synchronously — e.currentTarget is nulled once
               the event handler returns, before the updater runs */
            const t = e.currentTarget.currentTime;
            setClip((c) => ({ ...c, t }));
          }}
          onError={() => setBgFailed(true)}
          className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-[2000ms] ease-out ${
            bgActive ? "opacity-100" : "pointer-events-none opacity-0"
          }`}
        />
      )}

      {/* Cinematic overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B] via-[#0B0B0B]/45 to-[#0B0B0B]/55" aria-hidden="true" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0B0B0B]/70 via-transparent to-transparent" aria-hidden="true" />

      {/* Content */}
      <div className="relative z-10 mx-auto w-full max-w-[1600px] px-5 pb-36 pt-32 sm:px-8 md:px-10 md:pb-40 lg:pb-44">
        <p className="hero-rise eyebrow mb-5 md:mb-7" style={{ animationDelay: "150ms" }}>
          {s.heroEyebrow.split("/").length > 1
            ? s.heroEyebrow
                .split("/")
                .map((part, i, arr) => (
                  <span key={i}>
                    {part.trim()}
                    {i < arr.length - 1 ? <>&ensp;/&ensp;</> : null}
                  </span>
                ))
            : s.heroEyebrow}
        </p>

        <h1 className="hero-rise hero-mega text-white" style={{ animationDelay: "300ms" }}>
          <BrandTitle title={s.heroTitle} />
        </h1>

        <div className="mt-5 flex flex-col gap-8 md:mt-7 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-xl">
            <p
              className="hero-rise display-title text-xl font-bold text-[#D7D7D7] sm:text-2xl md:text-[1.7rem]"
              style={{ animationDelay: "450ms" }}
            >
              {s.heroSubtitle}
            </p>
            <p
              className="hero-rise mt-4 max-w-lg text-[15px] leading-relaxed text-[#929292] md:text-base"
              style={{ animationDelay: "580ms" }}
            >
              {s.heroText}
            </p>

            {/* CTAs */}
            <div className="hero-rise mt-8 flex flex-wrap items-center gap-4 md:gap-5" style={{ animationDelay: "720ms" }}>
              <button
                onClick={() => setVideoModalOpen(true)}
                className="group flex items-center gap-3 bg-white px-7 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-black transition-colors duration-300 hover:bg-[#D97F3E]"
              >
                <Play className="h-3.5 w-3.5 fill-current" strokeWidth={0} />
                Watch Our Journey
              </button>
              <a
                href="#rides"
                className="border border-white/30 px-7 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition-all duration-300 hover:border-white hover:bg-white/10"
              >
                Explore Rides
              </a>
            </div>
          </div>

          {/* Circular play button */}
          <button
            onClick={() => setVideoModalOpen(true)}
            aria-label="Play the BrosonRoads journey film"
            className="hero-rise group relative hidden h-28 w-28 shrink-0 items-center justify-center md:flex lg:h-32 lg:w-32"
            style={{ animationDelay: "860ms" }}
          >
            <span
              className="absolute inset-0 rounded-full border border-white/30 transition-colors duration-500 group-hover:border-[#D97F3E]"
              aria-hidden="true"
            />
            <span
              className="absolute inset-0 rounded-full border border-white/10 transition-transform duration-700 group-hover:scale-110"
              aria-hidden="true"
            />
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-white/10 backdrop-blur-sm transition-colors duration-500 group-hover:bg-[#D97F3E]">
              <Play className="ml-0.5 h-5 w-5 fill-white text-white" strokeWidth={0} />
            </span>
            <span className="sr-only">Play video</span>
          </button>
        </div>
      </div>

      {/* Bottom meta bar */}
      <div className="hero-rise absolute inset-x-0 bottom-0 z-10" style={{ animationDelay: "1000ms" }}>
        <div className="mx-auto flex max-w-[1600px] items-center justify-between px-5 pb-5 sm:px-8 md:px-10 md:pb-6">
          <div className="flex items-center gap-3 md:gap-5">
            <span className="h-1.5 w-1.5 rounded-full bg-[#D97F3E]" aria-hidden="true" />
            <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-[#D7D7D7] md:text-[11px]">
              {s.heroLocation}
            </span>
            <span className="hidden text-[10px] uppercase tracking-[0.25em] text-[#929292] sm:inline md:text-[11px]">
              {s.heroMetaLabel}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[10px] tracking-[0.2em] text-[#929292] md:text-[11px]">
              {fmtTime(clip.t)}&ensp;/&ensp;{fmtTime(clip.d)}
            </span>
            <span
              className="hidden items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-[#929292] md:flex"
              aria-hidden="true"
            >
              Scroll
              <span className="block h-px w-10 bg-gradient-to-r from-[#929292] to-transparent" />
            </span>
          </div>
        </div>
        {/* live clip progress — driven by the video's currentTime */}
        <div className="h-[2px] w-full bg-white/10" aria-hidden="true">
          <div
            className="h-full w-full origin-left bg-[#D97F3E] transition-transform duration-200 ease-linear"
            style={{ transform: `scaleX(${clip.d > 0 ? Math.min(clip.t / clip.d, 1) : 0})` }}
          />
        </div>
      </div>

      {/* Cinematic video modal — the journey film with sound */}
      <VideoModal
        open={videoModalOpen}
        onClose={() => setVideoModalOpen(false)}
        videoId=""
        videoSrc={heroVideo}
        title="The BrosonRoads Journey"
        caption="Filmed on the road — follow the full journey on the BrosonRoads YouTube channel."
      />
    </section>
  );
}
