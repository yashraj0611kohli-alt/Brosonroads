import { SafeImage } from "./safe-image";

interface PageBannerProps {
  image: string;
  eyebrow: string;
  title: string;
  subtitle?: string;
  /** Compact banner for detail pages */
  size?: "regular" | "compact";
}

/**
 * Cinematic banner used across all internal pages — full-bleed
 * biker imagery, editorial typography, entrance animations.
 * Server-safe (no hooks); animations are pure CSS classes.
 */
export function PageBanner({ image, eyebrow, title, subtitle, size = "regular" }: PageBannerProps) {
  const heightClass =
    size === "compact"
      ? "min-h-[300px] h-[38vh] md:h-[44vh]"
      : "min-h-[380px] h-[52vh] md:h-[62vh]";

  return (
    <section className={`grain relative flex ${heightClass} items-end overflow-hidden bg-[#0B0B0B]`} aria-label={`${eyebrow} banner`}>
      <SafeImage
        src={image}
        alt={`${eyebrow} — bikers in the mountains`}
        priority
        className="absolute inset-0 h-full w-full animate-[hero-drift_20s_ease-in-out_infinite_alternate] object-cover"
        draggable={false}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B] via-[#0B0B0B]/40 to-[#0B0B0B]/50" aria-hidden="true" />

      <div className="relative z-10 mx-auto w-full max-w-[1600px] px-5 pb-14 pt-32 sm:px-8 md:px-10 md:pb-20">
        <p className="hero-rise eyebrow mb-4" style={{ animationDelay: "120ms" }}>
          {eyebrow}
        </p>
        <h1 className="hero-rise display-title max-w-4xl text-4xl font-bold text-white sm:text-6xl md:text-7xl" style={{ animationDelay: "260ms" }}>
          {title}
        </h1>
        {subtitle ? (
          <p className="hero-rise mt-5 max-w-xl text-[15px] leading-relaxed text-[#B9B9B9] md:text-base" style={{ animationDelay: "400ms" }}>
            {subtitle}
          </p>
        ) : null}
      </div>
    </section>
  );
}
