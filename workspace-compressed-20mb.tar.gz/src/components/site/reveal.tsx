"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";

interface RevealProps {
  children: ReactNode;
  className?: string;
  /** Delay in ms before the reveal triggers once visible */
  delay?: number;
  /** "fade-up" for text blocks, "image" for cinematic image reveals */
  variant?: "fade-up" | "image";
  as?: "div" | "section" | "figure" | "article" | "li" | "span" | "a";
}

/**
 * Scroll-triggered reveal. Uses IntersectionObserver (no library),
 * fires once, and respects prefers-reduced-motion via CSS overrides.
 *
 * NOTE: the "image" variant must NOT clip the observed element itself —
 * a fully clipped element reports zero intersection and would deadlock.
 * The clip is therefore applied to an inner wrapper while the outer
 * element (with layout classes) stays unclipped for observation.
 */
export function Reveal({
  children,
  className = "",
  delay = 0,
  variant = "fade-up",
  as: Tag = "div",
}: RevealProps) {
  const ref = useRef<HTMLElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    if (typeof IntersectionObserver === "undefined") {
      // Fallback: reveal without observer, deferred out of the effect body
      const raf = requestAnimationFrame(() => setVisible(true));
      return () => cancelAnimationFrame(raf);
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -6% 0px" }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const delayStyle = delay ? { transitionDelay: `${delay}ms` } : undefined;

  if (variant === "image") {
    return (
      <Tag ref={ref as React.Ref<HTMLDivElement>} className={className}>
        <div
          className={`reveal-img h-full w-full ${visible ? "is-visible" : ""}`}
          style={delayStyle}
        >
          {children}
        </div>
      </Tag>
    );
  }

  return (
    <Tag
      ref={ref as React.Ref<HTMLDivElement>}
      className={`reveal ${visible ? "is-visible" : ""} ${className}`}
      style={delayStyle}
    >
      {children}
    </Tag>
  );
}
