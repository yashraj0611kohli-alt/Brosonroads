"use client";

import Link from "next/link";
import { Youtube, Instagram, ArrowUp, Lock } from "lucide-react";
import { NAV_LINKS } from "@/lib/site";
import type { SettingsData } from "@/lib/defaults";

/**
 * Dark premium footer — wordmark, tagline, navigation, socials,
 * copyright, back-to-top and a discreet admin entry point.
 * The admin link goes to the login screen only; no credentials
 * are shown or hinted anywhere on the public site.
 */
export function Footer({ s }: { s: SettingsData }) {

  return (
    <footer className="border-t border-white/10 bg-[#0B0B0B]">
      <div className="mx-auto max-w-[1600px] px-5 pb-10 pt-16 sm:px-8 md:px-10 md:pt-20">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-12">
          {/* Brand */}
          <div className="md:col-span-6">
            <Link href="/" className="display-title text-2xl font-bold text-white md:text-3xl">
              BROS<span className="text-[#D97F3E]">ON</span>ROADS
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-[#929292]">
              Two wheels.
              <br />
              Endless roads.
              <br />
              Real experiences.
            </p>
            <p className="mt-6 text-[10px] uppercase tracking-[0.3em] text-[#929292]">
              The road is the story.
            </p>
          </div>

          {/* Navigation */}
          <nav className="md:col-span-3" aria-label="Footer">
            <p className="eyebrow mb-5">Navigate</p>
            <ul className="space-y-3">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-[#929292] transition-colors duration-300 hover:text-white"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Social */}
          <div className="md:col-span-3">
            <p className="eyebrow mb-5">Follow</p>
            <ul className="space-y-3">
              <li>
                <a
                  href={s.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-3 text-sm text-[#929292] transition-colors duration-300 hover:text-white"
                >
                  <Youtube className="h-4 w-4" strokeWidth={1.5} />
                  YouTube
                  <span className="text-xs text-[#5a5a5a]">{s.youtubeHandle}</span>
                </a>
              </li>
              <li>
                <a
                  href={s.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-3 text-sm text-[#929292] transition-colors duration-300 hover:text-white"
                >
                  <Instagram className="h-4 w-4" strokeWidth={1.5} />
                  Instagram
                  <span className="text-xs text-[#5a5a5a]">{s.instagramHandle}</span>
                </a>
              </li>
            </ul>

            <a
              href="#home"
              className="mt-8 inline-flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-[#929292] transition-colors duration-300 hover:text-white"
            >
              <ArrowUp className="h-3.5 w-3.5" strokeWidth={1.5} />
              Back to top
            </a>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 sm:flex-row">
          <p className="text-[10px] uppercase tracking-[0.25em] text-[#5a5a5a]">
            © BROSONROADS. ALL RIGHTS RESERVED.
          </p>
          <div className="flex items-center gap-5">
            <p className="text-[10px] uppercase tracking-[0.25em] text-[#5a5a5a]">
              Ridden &amp; documented in the Himalayas
            </p>
            {/* Discreet admin entry — login required, credentials never shown */}
            <Link
              href="/admin"
              aria-label="Admin login"
              className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.25em] text-[#3a3a3a] transition-colors duration-300 hover:text-[#929292]"
            >
              <Lock className="h-3 w-3" strokeWidth={1.5} />
              Admin
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
