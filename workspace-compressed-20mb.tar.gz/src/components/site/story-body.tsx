import { SafeImage } from "./safe-image";

/**
 * Lightweight, safe block renderer for Real Stories article bodies.
 * The body is a plain-text block format (edited in the admin panel):
 *
 *   ## Heading two          → section heading
 *   ### Heading three       → sub heading
 *   > Pull quote            → orange-bar pull quote
 *   - List item             → grouped into a list
 *   ![alt](src)             → full-measure figure
 *   anything else           → paragraph
 *
 * Everything renders as React elements — no HTML injection.
 */

interface Block {
  kind: "h2" | "h3" | "quote" | "ul" | "img" | "p";
  text?: string;
  alt?: string;
  src?: string;
  items?: string[];
}

function parseBlocks(body: string): Block[] {
  const raw = body.replace(/\r\n/g, "\n").split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
  const blocks: Block[] = [];

  for (const b of raw) {
    if (b.startsWith("## ")) {
      blocks.push({ kind: "h2", text: b.slice(3).trim() });
    } else if (b.startsWith("### ")) {
      blocks.push({ kind: "h3", text: b.slice(4).trim() });
    } else if (b.startsWith("> ")) {
      blocks.push({ kind: "quote", text: b.slice(2).trim() });
    } else if (b.startsWith("- ")) {
      const items = b.split("\n").map((l) => l.replace(/^-\s*/, "").trim()).filter(Boolean);
      blocks.push({ kind: "ul", items });
    } else {
      const img = b.match(/^!\[([^\]]*)\]\(([^)\s]+)\)$/);
      if (img) {
        blocks.push({ kind: "img", alt: img[1], src: img[2] });
      } else {
        blocks.push({ kind: "p", text: b });
      }
    }
  }
  return blocks;
}

export function StoryBody({ body }: { body: string }) {
  const blocks = parseBlocks(body);

  return (
    <div className="story-body">
      {blocks.map((block, i) => {
        switch (block.kind) {
          case "h2":
            return (
              <h2 key={i} className="display-title mt-12 mb-5 text-2xl font-bold text-[#111111] sm:text-3xl">
                {block.text}
              </h2>
            );
          case "h3":
            return (
              <h3 key={i} className="display-title mt-9 mb-4 text-xl font-bold text-[#111111]">
                {block.text}
              </h3>
            );
          case "quote":
            return (
              <blockquote key={i} className="my-10 border-l-2 border-[#D97F3E] py-1 pl-6 md:pl-8">
                <p className="display-title text-xl font-bold leading-snug text-[#111111] sm:text-2xl">
                  {block.text}
                </p>
              </blockquote>
            );
          case "ul":
            return (
              <ul key={i} className="my-7 space-y-3">
                {(block.items ?? []).map((item, j) => (
                  <li key={j} className="flex gap-3 text-[15px] leading-relaxed text-[#3D3B36] md:text-base">
                    <span className="mt-[0.55em] h-1.5 w-1.5 shrink-0 rounded-full bg-[#D97F3E]" aria-hidden="true" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            );
          case "img":
            return (
              <figure key={i} className="my-10">
                <SafeImage
                  src={block.src ?? ""}
                  alt={block.alt ?? ""}
                  className="aspect-[16/10] w-full object-cover"
                  draggable={false}
                />
                {block.alt ? (
                  <figcaption className="mt-3 text-xs uppercase tracking-[0.18em] text-[#8a877f]">
                    {block.alt}
                  </figcaption>
                ) : null}
              </figure>
            );
          default:
            return (
              <p key={i} className="my-6 text-[15px] leading-[1.85] text-[#3D3B36] md:text-[17px]">
                {block.text}
              </p>
            );
        }
      })}
    </div>
  );
}
