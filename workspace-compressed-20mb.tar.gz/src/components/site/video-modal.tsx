"use client";

import { useEffect, useCallback, useRef } from "react";
import { X } from "lucide-react";

interface VideoModalProps {
  open: boolean;
  onClose: () => void;
  /** 11-character YouTube video id (channel embeds) */
  videoId: string;
  /** Direct video file URL (e.g. the self-hosted hero film) —
   *  takes precedence over videoId when provided. */
  videoSrc?: string;
  title: string;
  /** Short supporting line shown under the title */
  caption?: string;
}

/**
 * Cinematic video modal.
 * - videoSrc → plays the given file with a native <video> (sound +
 *   controls), e.g. the self-hosted hero film.
 * - videoId  → official YouTube embed (no re-hosting).
 * Either way the element is fully unmounted on close, which
 * guarantees playback stops. ESC, backdrop and close button all
 * dismiss.
 */
export function VideoModal({ open, onClose, videoId, videoSrc, title, caption }: VideoModalProps) {
  const closeRef = useRef<HTMLButtonElement>(null);

  const handleKey = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    },
    [onClose]
  );

  useEffect(() => {
    if (!open) return;
    document.addEventListener("keydown", handleKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, handleKey]);

  if (!open) return null;

  return (
    <div
      className="modal-backdrop fixed inset-0 z-[90] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 sm:p-8"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onClick={onClose}
    >
      {/* Close button */}
      <button
        ref={closeRef}
        onClick={onClose}
        aria-label="Close video"
        className="absolute top-4 right-4 sm:top-6 sm:right-6 z-10 flex h-11 w-11 items-center justify-center border border-white/25 bg-black/50 text-white transition-colors duration-300 hover:border-white hover:bg-white hover:text-black"
      >
        <X className="h-5 w-5" strokeWidth={1.5} />
      </button>

      <div
        className="modal-panel w-full max-w-5xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-end justify-between gap-4 pr-14">
          <div>
            <p className="eyebrow mb-1.5">Now Playing</p>
            <h3 className="display-title text-lg sm:text-2xl font-bold text-white">
              {title}
            </h3>
          </div>
        </div>
        {caption ? (
          <p className="mb-4 max-w-2xl text-sm text-[#929292]">{caption}</p>
        ) : null}

        <div className="relative aspect-video w-full overflow-hidden border border-white/15 bg-black">
          {videoSrc ? (
            <video
              src={videoSrc}
              controls
              autoPlay
              playsInline
              className="absolute inset-0 h-full w-full bg-black"
            />
          ) : (
            <iframe
              src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1&playsinline=1`}
              title={title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              className="absolute inset-0 h-full w-full"
            />
          )}
        </div>
      </div>
    </div>
  );
}
