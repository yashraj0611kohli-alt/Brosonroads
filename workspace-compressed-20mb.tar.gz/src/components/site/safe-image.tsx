"use client";

import { useState } from "react";

interface SafeImageProps {
  src: string;
  alt: string;
  className?: string;
  /** When true, image loads eagerly (hero / above the fold) */
  priority?: boolean;
  sizes?: string;
  draggable?: boolean;
}

/**
 * Plain <img> with built-in graceful failure: if a remote image
 * fails to load, a cinematic dark gradient stands in so the layout
 * never shows a broken-asset icon.
 */
export function SafeImage({
  src,
  alt,
  className = "",
  priority = false,
  draggable = false,
}: SafeImageProps) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`bg-gradient-to-br from-[#1c1c1c] via-[#26221c] to-[#0b0b0b] ${className}`}
      />
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      draggable={draggable}
      loading={priority ? "eager" : "lazy"}
      decoding={priority ? "sync" : "async"}
      fetchPriority={priority ? "high" : "auto"}
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
