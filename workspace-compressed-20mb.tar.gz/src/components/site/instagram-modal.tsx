"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  X,
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  MapPin,
  ExternalLink,
} from "lucide-react";
import type { InstagramData, SettingsData } from "@/lib/defaults";
import { SafeImage } from "./safe-image";

interface InstagramModalProps {
  posts: InstagramData[];
  /** Index of the open post; null = closed */
  index: number | null;
  onClose: () => void;
  onNavigate: (index: number) => void;
  /** Post ids the guest has liked this session (kept by the parent so the grid hover count stays in sync) */
  liked: Record<string, boolean>;
  onToggleLike: (id: string) => void;
  s: SettingsData;
}

/** Instagram-style compact number: 941 → "941", 12,400 → "12.4K", 3,400,000 → "3.4M" */
function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`;
  if (n >= 10_000) return `${(n / 1_000).toFixed(1).replace(/\.0$/, "")}K`;
  return n.toLocaleString("en-US");
}

/**
 * Instagram-style post viewer — mimics instagram.com's post dialog:
 * desktop = letterboxed photo on the left + white profile/actions/caption
 * sidebar on the right; mobile = the familiar stacked app layout.
 * Heart toggles likes (double-tap on the photo bursts the big heart),
 * bookmark saves, share uses the Web Share API, ← / → / ESC work, and
 * "View on Instagram" opens the real post.
 */
export function InstagramModal({
  posts,
  index,
  onClose,
  onNavigate,
  liked,
  onToggleLike,
  s,
}: InstagramModalProps) {
  const open = index !== null && index >= 0 && index < posts.length;
  const post = open ? posts[index] : null;

  const closeRef = useRef<HTMLButtonElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const captionRef = useRef<HTMLParagraphElement>(null);
  const touchX = useRef<number | null>(null);
  const [saved, setSaved] = useState<Record<string, boolean>>({});
  const [burst, setBurst] = useState(false);
  const burstTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const username = s.instagramHandle.replace(/^@/, "");
  const postUrl = post?.permalink || s.instagramUrl;

  const goPrev = useCallback(() => {
    if (index === null) return;
    setBurst(false);
    onNavigate((index - 1 + posts.length) % posts.length);
  }, [index, posts.length, onNavigate]);

  const goNext = useCallback(() => {
    if (index === null) return;
    setBurst(false);
    onNavigate((index + 1) % posts.length);
  }, [index, posts.length, onNavigate]);

  const handleKey = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") goPrev();
      if (e.key === "ArrowRight") goNext();
    },
    [onClose, goPrev, goNext]
  );

  useEffect(() => {
    if (!open) return;
    document.addEventListener("keydown", handleKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, handleKey]);

  // Scroll back to the top when switching posts (burst is cleared in goPrev/goNext)
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
  }, [index]);

  useEffect(() => () => {
    if (burstTimer.current) clearTimeout(burstTimer.current);
  }, []);

  if (!open || !post) return null;

  const isLiked = !!liked[post.id];
  const likeCount = post.likes + (isLiked ? 1 : 0);
  const isSaved = !!saved[post.id];
  const caption = post.caption || post.alt;
  const many = posts.length > 1;

  /** Double-tap the photo → like it + big heart burst (the Instagram signature) */
  const doubleTapLike = () => {
    if (!isLiked) onToggleLike(post.id);
    setBurst(false);
    if (burstTimer.current) clearTimeout(burstTimer.current);
    // restart the animation even on consecutive double-taps
    requestAnimationFrame(() => setBurst(true));
    burstTimer.current = setTimeout(() => setBurst(false), 950);
  };

  const share = async () => {
    if (typeof navigator !== "undefined" && "share" in navigator) {
      try {
        await navigator.share({ title: `${username} on Instagram`, text: caption, url: postUrl });
        return;
      } catch {
        /* user dismissed — fall through to opening the post */
      }
    }
    window.open(postUrl, "_blank", "noopener,noreferrer");
  };

  const focusCaption = () => {
    captionRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  return (
    <div
      className="modal-backdrop fixed inset-0 z-[90] flex items-center justify-center bg-black/92 p-0 backdrop-blur-sm sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={`Instagram post by ${username}`}
      onClick={onClose}
    >
      {/* Close */}
      <button
        ref={closeRef}
        onClick={onClose}
        aria-label="Close post"
        className="absolute top-3 right-3 z-20 flex h-11 w-11 items-center justify-center text-white/85 transition-colors hover:text-white sm:top-5 sm:right-5"
      >
        <X className="h-7 w-7" strokeWidth={1.5} />
      </button>

      {/* Desktop prev / next arrows (Instagram-style floating circles) */}
      {many ? (
        <>
          <button
            onClick={(e) => { e.stopPropagation(); goPrev(); }}
            aria-label="Previous post"
            className="absolute left-4 top-1/2 z-20 hidden h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-white/95 text-[#262626] shadow-lg transition hover:bg-white md:flex"
          >
            <ChevronLeft className="h-5 w-5" strokeWidth={2} />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); goNext(); }}
            aria-label="Next post"
            className="absolute right-4 top-1/2 z-20 hidden h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-white/95 text-[#262626] shadow-lg transition hover:bg-white md:flex"
          >
            <ChevronRight className="h-5 w-5" strokeWidth={2} />
          </button>
        </>
      ) : null}

      <div
        className="modal-panel relative flex max-h-[100dvh] w-full max-w-full flex-col overflow-y-auto bg-white sm:max-h-[94dvh] md:h-[min(85vh,780px)] md:w-fit md:max-w-[94vw] md:flex-row md:overflow-visible md:rounded-[14px] md:shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ---------- Mobile-only header (IG app layout) ---------- */}
        <header className="flex h-[54px] shrink-0 items-center gap-3 border-b border-[#DBDBDB] px-4 md:hidden">
          <SafeImage
            src="/instagram/avatar.jpg"
            alt={`${username} avatar`}
            className="h-8 w-8 rounded-full object-cover"
            draggable={false}
          />
          <div className="min-w-0 leading-tight">
            <p className="truncate text-[14px] font-semibold text-[#262626]">{username}</p>
            {post.location ? (
              <p className="flex items-center gap-1 truncate text-[11px] text-[#8E8E8E]">
                <MapPin className="h-3 w-3" strokeWidth={1.5} /> {post.location}
              </p>
            ) : null}
          </div>
          <button
            className="ml-auto p-1 text-[#262626]"
            aria-label="More options"
            onClick={share}
          >
            <MoreHorizontal className="h-5 w-5" strokeWidth={1.5} />
          </button>
        </header>

        {/* ---------- Photo (letterboxed on black, desktop) ---------- */}
        <div
          className="relative flex shrink-0 items-center justify-center bg-black md:order-1 md:h-full md:min-w-0 md:flex-1"
          onDoubleClick={doubleTapLike}
          onTouchStart={(e) => { touchX.current = e.touches[0]?.clientX ?? null; }}
          onTouchEnd={(e) => {
            if (touchX.current === null) return;
            const dx = (e.changedTouches[0]?.clientX ?? 0) - touchX.current;
            touchX.current = null;
            if (Math.abs(dx) > 48) {
              if (dx < 0) goNext();
              else goPrev();
            }
          }}
        >
          <SafeImage
            key={post.id}
            src={post.src}
            alt={post.alt}
            priority
            className="aspect-square w-full object-cover select-none md:aspect-auto md:h-full md:w-auto md:max-w-full md:object-contain"
            draggable={false}
          />

          {/* Big heart burst on double-tap */}
          {burst ? (
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center" aria-hidden="true">
              <Heart className="ig-burst h-24 w-24 fill-white text-white drop-shadow-[0_2px_12px_rgba(0,0,0,0.4)]" strokeWidth={0} />
            </div>
          ) : null}

          {/* Mobile prev/next tap zones (swipe also works) */}
          {many ? (
            <div className="absolute inset-x-0 bottom-3 flex justify-center gap-1.5 md:hidden" aria-hidden="true">
              {posts.map((_, i) => (
                <span
                  key={i}
                  className={`h-1.5 w-1.5 rounded-full transition-colors ${i === index ? "bg-white" : "bg-white/40"}`}
                />
              ))}
            </div>
          ) : null}
        </div>

        {/* ---------- Sidebar (right column on desktop, below photo on mobile) ---------- */}
        <aside className="flex shrink-0 flex-col bg-white md:order-2 md:w-[405px]">
          {/* Desktop header (IG web layout) */}
          <header className="hidden h-[60px] shrink-0 items-center gap-3 px-4 py-3 md:flex">
            <SafeImage
              src="/instagram/avatar.jpg"
              alt={`${username} avatar`}
              className="h-8 w-8 rounded-full object-cover"
              draggable={false}
            />
            <div className="min-w-0 leading-tight">
              <p className="truncate text-[14px] font-semibold text-[#262626]">{username}</p>
              {post.location ? (
                <p className="flex items-center gap-1 truncate text-[11px] text-[#8E8E8E]">
                  <MapPin className="h-3 w-3" strokeWidth={1.5} /> {post.location}
                </p>
              ) : null}
            </div>
            <a
              href={s.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="ml-3 rounded-[4px] bg-[#0095F6] px-3 py-1.5 text-[12px] font-semibold text-white transition-colors hover:bg-[#1877F2]"
            >
              Follow
            </a>
            <button
              className="ml-auto p-1 text-[#262626]"
              aria-label="More options"
              onClick={share}
            >
              <MoreHorizontal className="h-5 w-5" strokeWidth={1.5} />
            </button>
          </header>

          {/* Actions row */}
          <div className="flex h-[46px] shrink-0 items-center gap-4 border-t border-[#DBDBDB] px-4 md:border-t-0">
            <button
              onClick={() => onToggleLike(post.id)}
              aria-label={isLiked ? "Unlike" : "Like"}
              aria-pressed={isLiked}
              className="transition-transform active:scale-75"
            >
              <Heart
                className={`h-6 w-6 transition-all duration-200 ${isLiked ? "scale-110 fill-[#FF3040] text-[#FF3040]" : "text-[#262626]"}`}
                strokeWidth={1.75}
              />
            </button>
            <button onClick={focusCaption} aria-label="Comment" className="text-[#262626] transition-transform active:scale-75">
              <MessageCircle className="h-6 w-6 -scale-x-100" strokeWidth={1.75} />
            </button>
            <button onClick={share} aria-label="Share post" className="text-[#262626] transition-transform active:scale-75">
              <Send className="h-6 w-6" strokeWidth={1.75} />
            </button>
            <button
              onClick={() => setSaved((m) => ({ ...m, [post.id]: !m[post.id] }))}
              aria-label={isSaved ? "Remove from saved" : "Save post"}
              aria-pressed={isSaved}
              className="ml-auto text-[#262626] transition-transform active:scale-75"
            >
              <Bookmark
                className={`h-6 w-6 ${isSaved ? "fill-[#262626]" : ""}`}
                strokeWidth={1.75}
              />
            </button>
          </div>

          {/* Likes + caption + date */}
          <div
            ref={scrollRef}
            className="min-h-0 flex-1 overflow-y-auto px-4 py-3 md:min-h-[120px]"
          >
            {likeCount > 0 ? (
              <p className="mb-2 text-[14px] font-semibold text-[#262626]">
                {formatCount(likeCount)} {likeCount === 1 ? "like" : "likes"}
              </p>
            ) : null}
            <p ref={captionRef} className="text-[14px] leading-relaxed text-[#262626]">
              <span className="mr-1.5 font-semibold">{username}</span>
              {caption}
            </p>
            {post.dateLabel ? (
              <p className="mt-2.5 text-[11px] uppercase tracking-wide text-[#8E8E8E]">
                {post.dateLabel}
              </p>
            ) : null}
          </div>

          {/* View on Instagram */}
          <a
            href={postUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex h-[44px] shrink-0 items-center justify-center gap-2 border-t border-[#DBDBDB] text-[12px] font-semibold text-[#262626] transition-colors hover:text-[#0095F6]"
          >
            View on Instagram
            <ExternalLink className="h-3.5 w-3.5" strokeWidth={1.75} />
          </a>
        </aside>
      </div>
    </div>
  );
}
