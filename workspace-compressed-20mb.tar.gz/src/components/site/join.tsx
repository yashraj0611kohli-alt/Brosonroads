"use client";

import {
  Phone,
  MessageSquare,
  Mail,
  Youtube,
  Instagram,
  ArrowUpRight,
} from "lucide-react";
import type { ContactData, SettingsData } from "@/lib/defaults";
import { Reveal } from "./reveal";
import { SafeImage } from "./safe-image";

/**
 * Shared contact action cards — call / text / email per crew member
 * plus the shared inbox. Used by the homepage Join section and the
 * /join page. All links are real tel:/sms:/mailto: actions.
 */

export function ContactAction({
  href,
  icon,
  label,
  variant = "ghost",
}: {
  href: string;
  icon: React.ReactNode;
  label: string;
  variant?: "solid" | "ghost";
}) {
  return (
    <a
      href={href}
      className={`inline-flex flex-1 min-w-[120px] items-center justify-center gap-2 px-4 py-3 text-[10px] font-semibold uppercase tracking-[0.2em] transition-all duration-300 ${
        variant === "solid"
          ? "bg-white text-black hover:bg-[#D97F3E]"
          : "border border-white/25 text-white hover:border-white hover:bg-white/10"
      }`}
    >
      {icon}
      {label}
    </a>
  );
}

export function ContactCards({
  contacts,
  email,
  staggerStart = 200,
}: {
  contacts: ContactData[];
  email: string;
  staggerStart?: number;
}) {
  return (
    <div className="mx-auto grid max-w-5xl grid-cols-1 gap-5 text-left md:grid-cols-3">
      {contacts.map((contact, i) => (
        <Reveal key={contact.dial} delay={staggerStart + i * 90}>
          <article className="flex h-full flex-col border border-white/10 bg-[#151515]/90 p-7 backdrop-blur-sm transition-colors duration-500 hover:border-[#D97F3E]/50">
            <p className="eyebrow mb-4">{contact.role}</p>
            <h3 className="display-title text-2xl font-bold text-white">
              {contact.name}
            </h3>
            <a
              href={`tel:${contact.dial}`}
              className="mt-4 inline-block font-mono text-lg tracking-wide text-[#D7D7D7] transition-colors duration-300 hover:text-[#D97F3E]"
            >
              {contact.phone}
            </a>
            <p className="mt-2 text-[13px] leading-relaxed text-[#929292]">
              Call or text for ride details, dates and meeting points.
            </p>
            <div className="mt-6 flex flex-wrap gap-2.5 pt-2">
              <ContactAction
                href={`tel:${contact.dial}`}
                icon={<Phone className="h-3.5 w-3.5" strokeWidth={1.75} />}
                label="Call"
                variant="solid"
              />
              <ContactAction
                href={`sms:${contact.dial}`}
                icon={<MessageSquare className="h-3.5 w-3.5" strokeWidth={1.75} />}
                label="Text"
              />
              {contact.email ? (
                <ContactAction
                  href={`mailto:${contact.email}`}
                  icon={<Mail className="h-3.5 w-3.5" strokeWidth={1.75} />}
                  label="Email"
                />
              ) : null}
            </div>
          </article>
        </Reveal>
      ))}

      {/* Shared inbox */}
      <Reveal delay={staggerStart + 180}>
        <article className="flex h-full flex-col border border-[#D97F3E]/40 bg-[#151515]/90 p-7 backdrop-blur-sm transition-colors duration-500 hover:border-[#D97F3E]">
          <p className="eyebrow mb-4">Queries &amp; Notifications</p>
          <h3 className="display-title text-2xl font-bold text-white">
            Email Us
          </h3>
          <a
            href={`mailto:${email}`}
            className="mt-4 inline-block break-all font-mono text-[15px] tracking-wide text-[#D7D7D7] transition-colors duration-300 hover:text-[#D97F3E]"
          >
            {email}
          </a>
          <p className="mt-2 text-[13px] leading-relaxed text-[#929292]">
            Ride sign-ups, group bookings and everything else in writing.
          </p>
          <div className="mt-6 flex flex-wrap gap-2.5 pt-2">
            <ContactAction
              href={`mailto:${email}`}
              icon={<Mail className="h-3.5 w-3.5" strokeWidth={1.75} />}
              label="Write to us"
              variant="solid"
            />
          </div>
        </article>
      </Reveal>
    </div>
  );
}

export function JoinUs({ s }: { s: SettingsData }) {
  return (
    <section id="join" aria-labelledby="join-heading" className="relative scroll-mt-20 overflow-hidden bg-[#0B0B0B]">
      {/* Backdrop */}
      <div className="absolute inset-0" aria-hidden="true">
        <SafeImage
          src={s.joinBg}
          alt=""
          className="h-full w-full object-cover"
          draggable={false}
        />
        <div className="absolute inset-0 bg-[#0B0B0B]/88" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B0B0B] via-transparent to-[#0B0B0B]" />
      </div>

      <div className="grain relative z-10 mx-auto max-w-[1600px] px-5 py-28 text-center sm:px-8 md:px-10 md:py-40">
        <Reveal>
          <p className="eyebrow mb-6">{s.joinEyebrow}</p>
          <h2
            id="join-heading"
            className="display-title mx-auto max-w-5xl text-[2.6rem] font-bold text-white sm:text-6xl md:text-7xl lg:text-[5.2rem]"
          >
            {s.joinTitle1}
            <br />
            <span className="text-[#D97F3E]">{s.joinTitle2}</span>
          </h2>
        </Reveal>

        <Reveal delay={140}>
          <p className="mx-auto mt-7 max-w-2xl text-[15px] leading-relaxed text-[#929292] md:text-base">
            {s.joinText}
          </p>
        </Reveal>

        {/* Contact cards — call / text / email */}
        <div className="mt-14">
          <ContactCards contacts={s.contacts} email={s.contactEmail} />
        </div>

        {/* Socials */}
        <Reveal delay={420}>
          <div className="mt-12 flex flex-col items-center justify-center gap-4 sm:flex-row sm:gap-5">
            <a
              href={s.youtubeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex w-full items-center justify-center gap-3 border border-white/30 px-8 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition-all duration-300 hover:border-white hover:bg-white/10 sm:w-auto"
            >
              <Youtube className="h-4 w-4" strokeWidth={1.75} />
              Subscribe on YouTube
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" strokeWidth={1.5} />
            </a>
            <a
              href={s.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex w-full items-center justify-center gap-3 border border-white/30 px-8 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition-all duration-300 hover:border-white hover:bg-white/10 sm:w-auto"
            >
              <Instagram className="h-4 w-4" strokeWidth={1.75} />
              Follow on Instagram
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" strokeWidth={1.5} />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
