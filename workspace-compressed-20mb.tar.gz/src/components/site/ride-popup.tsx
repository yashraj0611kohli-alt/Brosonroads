"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { X, Phone, MessageSquare, Mail } from "lucide-react";
import type { SettingsData } from "@/lib/defaults";
import { SafeImage } from "./safe-image";

/**
 * RIDE POPUP — appears N seconds after the page loads with an image
 * of the crew and one message: want to ride with us? Call, text or
 * email us for details. Fully admin-configurable (enable, delay,
 * copy, image, contacts).
 *
 * - Shows once per browser session (sessionStorage guard).
 * - Dismiss via X, ESC or backdrop click; body scroll locked while open.
 * - All actions are real: tel:, sms: and mailto: links.
 */

const SEEN_KEY = "bor_ride_popup_seen";

export function RidePopup({ s }: { s: SettingsData }) {
  const [open, setOpen] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);

  /* Show once, after the configured delay, unless already seen */
  useEffect(() => {
    if (!s.popupEnabled) return;
    let seen = false;
    try {
      seen = window.sessionStorage.getItem(SEEN_KEY) === "1";
    } catch {
      /* storage unavailable (private mode) — still show once */
    }
    if (seen) return;

    const delayMs = Math.max(3, s.popupDelaySec) * 1000;
    const timer = setTimeout(() => setOpen(true), delayMs);
    return () => clearTimeout(timer);
  }, [s.popupEnabled, s.popupDelaySec]);

  const close = useCallback(() => {
    setOpen(false);
    try {
      window.sessionStorage.setItem(SEEN_KEY, "1");
    } catch {
      /* ignore */
    }
  }, []);

  /* ESC to dismiss + scroll lock + initial focus */
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, close]);

  if (!open) return null;

  return (
    <div
      className="modal-backdrop fixed inset-0 z-[80] flex items-end justify-center bg-black/80 backdrop-blur-sm p-0 sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="ride-popup-heading"
      onClick={close}
    >
      <div
        className="modal-panel relative w-full max-w-md overflow-hidden border border-white/15 bg-[#0B0B0B] shadow-[0_40px_120px_rgba(0,0,0,0.8)]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Crew image */}
        <div className="relative aspect-[16/9] w-full overflow-hidden sm:aspect-[2/1]">
          <SafeImage
            src={s.popupImage}
            alt="The Bros On Roads crew standing together with their motorcycles in front of snowy Himalayan peaks"
            priority
            className="h-full w-full object-cover"
            draggable={false}
          />
          <div
            className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B] via-transparent to-black/20"
            aria-hidden="true"
          />
          <button
            ref={closeRef}
            onClick={close}
            aria-label="Close ride popup"
            className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center border border-white/25 bg-black/60 text-white backdrop-blur-sm transition-colors duration-300 hover:border-white hover:bg-white hover:text-black"
          >
            <X className="h-5 w-5" strokeWidth={1.5} />
          </button>
          <p className="eyebrow absolute bottom-3 left-5 text-[#D7D7D7]">
            The crew, somewhere in the Himalayas
          </p>
        </div>

        {/* Message + actions */}
        <div className="px-5 pb-7 pt-6 sm:px-7">
          <h3
            id="ride-popup-heading"
            className="display-title text-2xl font-bold text-white sm:text-[1.7rem]"
          >
            {s.popupTitle1} <span className="text-[#D97F3E]">{s.popupTitle2}</span>
          </h3>
          <p className="mt-2.5 text-sm leading-relaxed text-[#929292]">
            {s.popupText}
          </p>

          {/* Contacts */}
          <div className="mt-5 space-y-2.5">
            {s.contacts.map((c) => (
              <div
                key={c.dial}
                className="flex items-center justify-between gap-3 border border-white/10 bg-[#151515] px-4 py-3"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-white">
                    {c.name}
                  </p>
                  <p className="font-mono text-xs text-[#929292]">{c.phone}</p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <a
                    href={`tel:${c.dial}`}
                    aria-label={`Call ${c.name}`}
                    className="flex h-9 w-9 items-center justify-center bg-white text-black transition-colors duration-300 hover:bg-[#D97F3E]"
                  >
                    <Phone className="h-4 w-4" strokeWidth={1.75} />
                  </a>
                  <a
                    href={`sms:${c.dial}`}
                    aria-label={`Text ${c.name}`}
                    className="flex h-9 w-9 items-center justify-center border border-white/25 text-white transition-colors duration-300 hover:border-white hover:bg-white/10"
                  >
                    <MessageSquare className="h-4 w-4" strokeWidth={1.75} />
                  </a>
                </div>
              </div>
            ))}
          </div>

          {/* Email CTA */}
          <a
            href={`mailto:${s.contactEmail}?subject=${encodeURIComponent(
              "Ride inquiry — Bros On Roads"
            )}`}
            className="mt-3 flex w-full items-center justify-center gap-2.5 bg-white px-5 py-3.5 text-[11px] font-semibold uppercase tracking-[0.2em] text-black transition-colors duration-300 hover:bg-[#D97F3E]"
          >
            <Mail className="h-4 w-4" strokeWidth={1.75} />
            Email for ride details
          </a>

          <button
            onClick={close}
            className="mx-auto mt-4 block text-[10px] uppercase tracking-[0.25em] text-[#929292] transition-colors duration-300 hover:text-white"
          >
            Maybe next time
          </button>
        </div>
      </div>
    </div>
  );
}
