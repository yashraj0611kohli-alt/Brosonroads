"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ChevronDown,
  ChevronUp,
  LoaderCircle,
  Plus,
  Trash2,
  ExternalLink,
} from "lucide-react";
import {
  Grid2,
  ImageField,
  NumberField,
  Panel,
  StringListField,
  TextAreaField,
  TextField,
  ToggleField,
} from "./field";
import { api, parseJsonArray, type AdminRide } from "./types";

/**
 * Rides manager — create, edit, reorder, publish and delete rides.
 * Featured rides and upcoming expeditions both live here; category
 * decides where a ride appears (homepage + /rides + its own page).
 */

interface RideForm {
  title: string;
  slug: string;
  category: "featured" | "upcoming";
  location: string;
  date: string;
  distance: string;
  days: string;
  image: string;
  alt: string;
  excerpt: string;
  description: string;
  highlights: string[];
  route: string[];
  order: number;
  published: boolean;
}

function toForm(r: AdminRide): RideForm {
  return {
    title: r.title,
    slug: r.slug,
    category: r.category === "upcoming" ? "upcoming" : "featured",
    location: r.location,
    date: r.date,
    distance: r.distance,
    days: r.days,
    image: r.image,
    alt: r.alt,
    excerpt: r.excerpt,
    description: r.description,
    highlights: parseJsonArray(r.highlightsJson),
    route: parseJsonArray(r.routeJson),
    order: r.order,
    published: r.published,
  };
}

const EMPTY: RideForm = {
  title: "",
  slug: "",
  category: "featured",
  location: "",
  date: "",
  distance: "",
  days: "",
  image: "",
  alt: "",
  excerpt: "",
  description: "",
  highlights: [""],
  route: [],
  order: 0,
  published: true,
};

export function RidesEditor() {
  const router = useRouter();
  const [rides, setRides] = useState<AdminRide[] | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState<RideForm>(EMPTY);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    try {
      const rows = await api<AdminRide[]>("/api/admin/rides");
      setRides(rows);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load rides");
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const sorted = useMemo(() => {
    if (!rides) return [];
    return [...rides].sort((a, b) =>
      a.category === b.category
        ? a.order - b.order
        : a.category === "featured"
          ? -1
          : 1
    );
  }, [rides]);

  async function create() {
    setBusy(true);
    setError("");
    try {
      await api("/api/admin/rides", {
        method: "POST",
        body: JSON.stringify({
          ...draft,
          slug: draft.slug || draft.title,
          highlights: draft.highlights.filter((h) => h.trim()),
          route: draft.route.filter((r) => r.trim()),
        }),
      });
      setDraft(EMPTY);
      setCreating(false);
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not create ride");
    } finally {
      setBusy(false);
    }
  }

  async function saveRide(id: string, form: RideForm) {
    setBusy(true);
    setError("");
    try {
      await api(`/api/admin/rides/${id}`, {
        method: "PATCH",
        body: JSON.stringify({
          ...form,
          slug: form.slug || form.title,
          highlights: form.highlights.filter((h) => h.trim()),
          route: form.route.filter((r) => r.trim()),
        }),
      });
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save ride");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string, title: string) {
    if (!window.confirm(`Delete “${title}” permanently?`)) return;
    setBusy(true);
    setError("");
    try {
      await api(`/api/admin/rides/${id}`, { method: "DELETE" });
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not delete ride");
    } finally {
      setBusy(false);
    }
  }

  if (!rides && !error) {
    return (
      <div className="flex items-center gap-3 p-10 text-sm text-[#8a8a8a]">
        <LoaderCircle className="h-4 w-4 animate-spin" strokeWidth={2} /> Loading rides…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error ? (
        <p className="border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>
      ) : null}

      <Panel
        title="Add a ride"
        description="New rides appear on the homepage, the Rides page and get their own detail page."
      >
        {creating ? (
          <RideFields
            form={draft}
            onChange={setDraft}
            actions={
              <div className="flex gap-3">
                <button
                  onClick={create}
                  disabled={busy || !draft.title.trim()}
                  className="inline-flex items-center gap-2 bg-white px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors hover:bg-[#D97F3E] disabled:opacity-50"
                >
                  {busy ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} /> : <Plus className="h-3.5 w-3.5" strokeWidth={2} />}
                  Create ride
                </button>
                <button
                  onClick={() => { setCreating(false); setDraft(EMPTY); }}
                  className="border border-white/25 px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:border-white"
                >
                  Cancel
                </button>
              </div>
            }
          />
        ) : (
          <button
            onClick={() => setCreating(true)}
            className="inline-flex items-center gap-2 border border-dashed border-white/25 px-5 py-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9a9a9a] transition-colors hover:border-[#D97F3E] hover:text-[#D97F3E]"
          >
            <Plus className="h-4 w-4" strokeWidth={1.75} /> New ride
          </button>
        )}
      </Panel>

      <div className="space-y-4">
        {sorted.map((ride) => (
          <RideCard
            key={ride.id}
            ride={ride}
            open={openId === ride.id}
            onToggle={() => setOpenId(openId === ride.id ? null : ride.id)}
            onSave={(form) => saveRide(ride.id, form)}
            onDelete={() => remove(ride.id, ride.title)}
            busy={busy}
          />
        ))}
      </div>
    </div>
  );
}

function RideCard({
  ride, open, onToggle, onSave, onDelete, busy,
}: {
  ride: AdminRide;
  open: boolean;
  onToggle: () => void;
  onSave: (form: RideForm) => void;
  onDelete: () => void;
  busy: boolean;
}) {
  const [form, setForm] = useState<RideForm>(() => toForm(ride));

  useEffect(() => {
    setForm(toForm(ride));
  }, [ride]);

  return (
    <div className="border border-white/10 bg-[#111111]">
      <div className="flex items-center gap-4 px-5 py-4">
        {ride.image ? (
           
          <img src={ride.image} alt="" className="h-12 w-16 shrink-0 border border-white/10 object-cover" />
        ) : (
          <div className="h-12 w-16 shrink-0 border border-white/10 bg-[#1a1a1a]" />
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-white">{ride.title}</p>
          <p className="mt-0.5 text-[10px] uppercase tracking-[0.18em] text-[#7a7a7a]">
            {ride.category} · order {ride.order} · {ride.published ? "published" : "hidden"}
          </p>
        </div>
        <a
          href={`/rides/${ride.slug}`}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Open ride page"
          className="hidden text-[#7a7a7a] transition-colors hover:text-white sm:block"
        >
          <ExternalLink className="h-4 w-4" strokeWidth={1.5} />
        </a>
        <button
          onClick={onToggle}
          aria-expanded={open}
          aria-label={open ? "Collapse" : "Edit"}
          className="flex h-8 w-8 items-center justify-center border border-white/15 text-[#9a9a9a] transition-colors hover:border-white/40 hover:text-white"
        >
          {open ? <ChevronUp className="h-4 w-4" strokeWidth={1.5} /> : <ChevronDown className="h-4 w-4" strokeWidth={1.5} />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-white/10 p-5">
          <RideFields form={form} onChange={setForm} hideHeader />
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSave(form)}
              disabled={busy || !form.title.trim()}
              className="inline-flex items-center gap-2 bg-white px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors hover:bg-[#D97F3E] disabled:opacity-50"
            >
              {busy ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} /> : null}
              Save ride
            </button>
            <button
              onClick={onDelete}
              disabled={busy}
              className="inline-flex items-center gap-2 border border-red-500/40 px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-red-400 transition-colors hover:bg-red-500/10 disabled:opacity-50"
            >
              <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} /> Delete
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function RideFields({
  form, onChange, actions, hideHeader,
}: {
  form: RideForm;
  onChange: (f: RideForm) => void;
  actions?: React.ReactNode;
  hideHeader?: boolean;
}) {
  function set<K extends keyof RideForm>(key: K, value: RideForm[K]) {
    onChange({ ...form, [key]: value });
  }

  return (
    <div className="space-y-4">
      {hideHeader ? null : (
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">Ride details</p>
      )}
      <Grid2>
        <TextField label="Title *" value={form.title} onChange={(v) => set("title", v)} placeholder="e.g. Spiti Valley Expedition" />
        <TextField label="URL slug" mono value={form.slug} onChange={(v) => set("slug", v)} placeholder="auto from title" />
      </Grid2>
      <Grid2>
        <div>
          <span className="mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.2em] text-[#8a8a8a]">Category</span>
          <div className="flex">
            {(["featured", "upcoming"] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => set("category", c)}
                className={`flex-1 border px-3 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] transition-colors ${
                  form.category === c
                    ? "border-[#D97F3E] bg-[#D97F3E]/15 text-[#D97F3E]"
                    : "border-white/15 bg-[#151515] text-[#8a8a8a] hover:text-white"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
        <ToggleField label="Published" checked={form.published} onChange={(v) => set("published", v)} hint="Visible on the public site" />
      </Grid2>
      <Grid2>
        <TextField label="Location" value={form.location} onChange={(v) => set("location", v)} placeholder="Uttarakhand" />
        <TextField label="Date(s)" value={form.date} onChange={(v) => set("date", v)} placeholder="Oct 12–16, 2025" />
        <TextField label="Distance" value={form.distance} onChange={(v) => set("distance", v)} placeholder="450 KM" />
        <TextField label="Duration" value={form.days} onChange={(v) => set("days", v)} placeholder="4 Days" />
      </Grid2>
      <ImageField label="Cover image" value={form.image} onChange={(v) => set("image", v)} />
      <TextField label="Image alt text" value={form.alt} onChange={(v) => set("alt", v)} />
      <TextAreaField label="Excerpt (cards & banner subtitle)" rows={2} value={form.excerpt} onChange={(v) => set("excerpt", v)} />
      <TextAreaField label="Full story (detail page)" rows={6} value={form.description} onChange={(v) => set("description", v)} />
      <StringListField label="Highlights" items={form.highlights} onChange={(v) => set("highlights", v)} addLabel="Add highlight" />
      <StringListField label="Route / itinerary (upcoming rides)" items={form.route} onChange={(v) => set("route", v)} addLabel="Add route step" />
      <NumberField label="Display order" value={form.order} onChange={(v) => set("order", v)} min={0} max={99} />
      {actions ? <div className="pt-1">{actions}</div> : null}
    </div>
  );
}
