"use client";

import { useId, useRef, useState } from "react";
import { LoaderCircle, ImagePlus, Check, X } from "lucide-react";

/* ---------------------------------------------------------------- */
/*  Shared input primitives for the admin panel                      */
/* ---------------------------------------------------------------- */

export const adminInput =
  "w-full border border-white/15 bg-[#151515] px-3.5 py-2.5 text-sm text-white placeholder:text-[#5a5a5a] transition-colors duration-200 focus:border-[#D97F3E] focus:outline-none";

export function FieldLabel({ children, htmlFor }: { children: React.ReactNode; htmlFor?: string }) {
  return (
    <label htmlFor={htmlFor} className="mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.2em] text-[#8a8a8a]">
      {children}
    </label>
  );
}

export function TextField({
  label, value, onChange, placeholder, maxLength, mono,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  maxLength?: number;
  mono?: boolean;
}) {
  const id = `f-${useId()}`;
  return (
    <div>
      <FieldLabel htmlFor={id}>{label}</FieldLabel>
      <input
        id={id}
        value={value}
        placeholder={placeholder}
        maxLength={maxLength ?? 300}
        onChange={(e) => onChange(e.target.value)}
        className={`${adminInput}${mono ? " font-mono text-xs" : ""}`}
      />
    </div>
  );
}

export function TextAreaField({
  label, value, onChange, rows = 3, placeholder, maxLength,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  rows?: number;
  placeholder?: string;
  maxLength?: number;
}) {
  const id = `f-${useId()}`;
  return (
    <div>
      <FieldLabel htmlFor={id}>{label}</FieldLabel>
      <textarea
        id={id}
        value={value}
        rows={rows}
        placeholder={placeholder}
        maxLength={maxLength ?? 4000}
        onChange={(e) => onChange(e.target.value)}
        className={`${adminInput} resize-y`}
      />
    </div>
  );
}

export function NumberField({
  label, value, onChange, min = 0, max = 9999,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
}) {
  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <input
        type="number"
        value={value}
        min={min}
        max={max}
        onChange={(e) => {
          const n = Number(e.target.value);
          if (Number.isFinite(n)) onChange(Math.min(max, Math.max(min, Math.round(n))));
        }}
        className={adminInput}
      />
    </div>
  );
}

export function ToggleField({
  label, checked, onChange, hint,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  hint?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between border border-white/15 bg-[#151515] px-3.5 py-2.5 text-left transition-colors hover:border-white/30"
    >
      <span>
        <span className="block text-[10px] font-semibold uppercase tracking-[0.2em] text-[#8a8a8a]">{label}</span>
        {hint ? <span className="mt-0.5 block text-xs text-[#6a6a6a]">{hint}</span> : null}
      </span>
      <span
        className={`relative h-5 w-9 shrink-0 transition-colors duration-200 ${checked ? "bg-[#D97F3E]" : "bg-white/20"}`}
      >
        <span
          className={`absolute top-0.5 h-4 w-4 bg-white transition-all duration-200 ${checked ? "left-[18px]" : "left-0.5"}`}
        />
      </span>
    </button>
  );
}

/* ---------------------------------------------------------------- */
/*  Image field — paste a URL or upload a file from the computer     */
/* ---------------------------------------------------------------- */

export function ImageField({
  label, value, onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  async function upload(file: File) {
    setUploading(true);
    setError("");
    setDone(false);
    try {
      const body = new FormData();
      body.append("file", file);
      body.append("name", file.name);
      const res = await fetch("/api/admin/upload", { method: "POST", body });
      const j = (await res.json().catch(() => ({}))) as { url?: string; error?: string };
      if (!res.ok || !j.url) throw new Error(j.error || "Upload failed");
      onChange(j.url);
      setDone(true);
      setTimeout(() => setDone(false), 2500);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <div className="flex gap-2">
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="https://… or upload a file"
          className={`${adminInput} font-mono text-xs`}
        />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          className="inline-flex shrink-0 items-center gap-1.5 border border-white/25 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-white transition-colors hover:border-[#D97F3E] hover:text-[#D97F3E] disabled:opacity-50"
        >
          {uploading ? (
            <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={1.75} />
          ) : done ? (
            <Check className="h-3.5 w-3.5 text-[#D97F3E]" strokeWidth={2} />
          ) : (
            <ImagePlus className="h-3.5 w-3.5" strokeWidth={1.75} />
          )}
          Upload
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/avif,image/gif"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void upload(f);
            e.target.value = "";
          }}
        />
      </div>
      {error ? <p className="mt-1.5 text-xs text-red-400">{error}</p> : null}
      {value ? (
        <div className="relative mt-2 h-28 w-full max-w-xs overflow-hidden border border-white/10 bg-[#151515]">
          { }
          <img src={value} alt={`${label} preview`} className="h-full w-full object-cover" />
          <button
            type="button"
            onClick={() => onChange("")}
            aria-label="Clear image"
            className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center bg-black/70 text-white/80 transition-colors hover:text-white"
          >
            <X className="h-3.5 w-3.5" strokeWidth={1.75} />
          </button>
        </div>
      ) : null}
    </div>
  );
}

/* ---------------------------------------------------------------- */
/*  String list editor (about lines, highlights, route steps)        */
/* ---------------------------------------------------------------- */

export function StringListField({
  label, items, onChange, placeholder, addLabel = "Add item",
}: {
  label: string;
  items: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
  addLabel?: string;
}) {
  function update(i: number, v: string) {
    const next = [...items];
    next[i] = v;
    onChange(next);
  }
  function remove(i: number) {
    onChange(items.filter((_, idx) => idx !== i));
  }
  function add() {
    onChange([...items, ""]);
  }

  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <div className="space-y-2">
        {items.map((item, i) => (
          <div key={i} className="flex gap-2">
            <input
              value={item}
              placeholder={placeholder}
              onChange={(e) => update(i, e.target.value)}
              className={adminInput}
            />
            <button
              type="button"
              onClick={() => remove(i)}
              aria-label={`Remove item ${i + 1}`}
              className="inline-flex h-9 w-9 shrink-0 items-center justify-center border border-white/15 text-[#8a8a8a] transition-colors hover:border-red-500/60 hover:text-red-400"
            >
              <X className="h-3.5 w-3.5" strokeWidth={1.75} />
            </button>
          </div>
        ))}
        <button
          type="button"
          onClick={add}
          className="border border-dashed border-white/25 px-3.5 py-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#8a8a8a] transition-colors hover:border-[#D97F3E] hover:text-[#D97F3E]"
        >
          + {addLabel}
        </button>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- */
/*  Panel shells                                                     */
/* ---------------------------------------------------------------- */

export function Panel({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <section className="border border-white/10 bg-[#111111]">
      <header className="border-b border-white/10 px-5 py-4 md:px-6">
        <h2 className="display-title text-sm font-bold uppercase tracking-[0.14em] text-white">{title}</h2>
        {description ? <p className="mt-1 text-xs text-[#7a7a7a]">{description}</p> : null}
      </header>
      <div className="space-y-4 p-5 md:p-6">{children}</div>
    </section>
  );
}

export function Grid2({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-1 gap-4 md:grid-cols-2">{children}</div>;
}
