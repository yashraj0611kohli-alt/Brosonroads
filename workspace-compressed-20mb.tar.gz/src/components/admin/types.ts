"use client";

import type { ContactData, SettingsData } from "@/lib/defaults";

/** Editable settings = effective settings + bookkeeping columns. */
export type AdminSettings = SettingsData & { id: string; updatedAt: string };
export type AdminContact = ContactData;

/** Raw ride row as returned by GET /api/admin/rides. */
export interface AdminRide {
  id: string;
  slug: string;
  title: string;
  location: string;
  date: string;
  distance: string;
  days: string;
  image: string;
  alt: string;
  excerpt: string;
  description: string;
  highlightsJson: string;
  routeJson: string;
  category: string;
  order: number;
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AdminGalleryItem {
  id: string;
  src: string;
  alt: string;
  caption: string;
  category: string;
  order: number;
}

export interface AdminVideoItem {
  id: string;
  videoId: string;
  title: string;
  location: string;
  description: string;
  order: number;
}

export interface AdminInstagramItem {
  id: string;
  src: string;
  alt: string;
  caption: string;
  location: string;
  likes: number;
  dateLabel: string;
  permalink: string;
  order: number;
}

/** Raw story row as returned by GET /api/admin/stories. */
export interface AdminStory {
  id: string;
  slug: string;
  title: string;
  dek: string;
  location: string;
  date: string;
  readTime: string;
  tag: string;
  cover: string;
  coverAlt: string;
  excerpt: string;
  body: string;
  order: number;
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

/* ---------------------------------------------------------------- */

/** Small JSON fetch helper with uniform error handling. */
export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const headers: Record<string, string> = {};
  if (init?.body && !(init.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }
  const res = await fetch(url, { ...init, headers });
  const isJson = res.headers.get("content-type")?.includes("application/json");
  const data = isJson ? ((await res.json()) as unknown) : {};
  if (!res.ok) {
    const msg =
      (data as { error?: string }).error ||
      `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data as T;
}

export function parseJsonArray(raw: string): string[] {
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v.map(String) : [];
  } catch {
    return [];
  }
}
