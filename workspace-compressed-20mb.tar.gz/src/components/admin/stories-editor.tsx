"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ChevronDown,
  ChevronUp,
  LoaderCircle,
  Plus,
  Trash2,
  ExternalLink,
} from "lucide-react";
import {
  Grid2,
  ImageField,
  NumberField,
  Panel,
  TextAreaField,
  TextField,
  ToggleField,
} from "./field";
import { api, type AdminStory } from "./types";

/**
 * Real Stories manager — create, edit, publish and delete articles.
 * Each story gets its own page at /stories/[slug] with the magazine
 * layout. Body uses the block format explained below the field.
 */

interface StoryForm {
  title: string;
  slug: string;
  dek: string;
  location: string;
  date: string;
  readTime: string;
  tag: string;
  cover: string;
  coverAlt: string;
  excerpt: string;
  body: string;
  order: number;
  published: boolean;
}

function toForm(s: AdminStory): StoryForm {
  return {
    title: s.title,
    slug: s.slug,
    dek: s.dek,
    location: s.location,
    date: s.date,
    readTime: s.readTime,
    tag: s.tag,
    cover: s.cover,
    coverAlt: s.coverAlt,
    excerpt: s.excerpt,
    body: s.body,
    order: s.order,
    published: s.published,
  };
}

const EMPTY: StoryForm = {
  title: "",
  slug: "",
  dek: "",
  location: "",
  date: "",
  readTime: "",
  tag: "Ride Journal",
  cover: "",
  coverAlt: "",
  excerpt: "",
  body: "",
  order: 0,
  published: true,
};

export function StoriesEditor() {
  const router = useRouter();
  const [stories, setStories] = useState<AdminStory[] | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState<StoryForm>(EMPTY);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    try {
      const rows = await api<AdminStory[]>("/api/admin/stories");
      setStories(rows);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load stories");
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const sorted = useMemo(() => {
    if (!stories) return [];
    return [...stories].sort((a, b) => a.order - b.order);
  }, [stories]);

  async function create() {
    setBusy(true);
    setError("");
    try {
      await api("/api/admin/stories", {
        method: "POST",
        body: JSON.stringify({ ...draft, slug: draft.slug || draft.title }),
      });
      setDraft(EMPTY);
      setCreating(false);
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not create story");
    } finally {
      setBusy(false);
    }
  }

  async function saveStory(id: string, form: StoryForm) {
    setBusy(true);
    setError("");
    try {
      await api(`/api/admin/stories/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ ...form, slug: form.slug || form.title }),
      });
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save story");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string, title: string) {
    if (!window.confirm(`Delete “${title}” permanently?`)) return;
    setBusy(true);
    setError("");
    try {
      await api(`/api/admin/stories/${id}`, { method: "DELETE" });
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not delete story");
    } finally {
      setBusy(false);
    }
  }

  if (!stories && !error) {
    return (
      <div className="flex items-center gap-3 p-10 text-sm text-[#8a8a8a]">
        <LoaderCircle className="h-4 w-4 animate-spin" strokeWidth={2} /> Loading stories…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error ? (
        <p className="border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>
      ) : null}

      <Panel
        title="Write a story"
        description="New stories appear on the homepage teaser and the Real Stories page, each with its own article page."
      >
        {creating ? (
          <StoryFields
            form={draft}
            onChange={setDraft}
            actions={
              <div className="flex gap-3">
                <button
                  onClick={create}
                  disabled={busy || !draft.title.trim()}
                  className="inline-flex items-center gap-2 bg-white px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors hover:bg-[#D97F3E] disabled:opacity-50"
                >
                  {busy ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} /> : <Plus className="h-3.5 w-3.5" strokeWidth={2} />}
                  Publish story
                </button>
                <button
                  onClick={() => { setCreating(false); setDraft(EMPTY); }}
                  className="border border-white/25 px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:border-white"
                >
                  Cancel
                </button>
              </div>
            }
          />
        ) : (
          <button
            onClick={() => setCreating(true)}
            className="inline-flex items-center gap-2 border border-dashed border-white/25 px-5 py-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9a9a9a] transition-colors hover:border-[#D97F3E] hover:text-[#D97F3E]"
          >
            <Plus className="h-4 w-4" strokeWidth={1.75} /> New story
          </button>
        )}
      </Panel>

      <div className="space-y-4">
        {sorted.map((story) => (
          <StoryCard
            key={story.id}
            story={story}
            open={openId === story.id}
            onToggle={() => setOpenId(openId === story.id ? null : story.id)}
            onSave={(form) => saveStory(story.id, form)}
            onDelete={() => remove(story.id, story.title)}
            busy={busy}
          />
        ))}
        {sorted.length === 0 && stories ? (
          <p className="border border-white/10 px-5 py-6 text-sm text-[#7a7a7a]">
            No stories yet — write the first one above.
          </p>
        ) : null}
      </div>
    </div>
  );
}

function StoryCard({
  story, open, onToggle, onSave, onDelete, busy,
}: {
  story: AdminStory;
  open: boolean;
  onToggle: () => void;
  onSave: (form: StoryForm) => void;
  onDelete: () => void;
  busy: boolean;
}) {
  const [form, setForm] = useState<StoryForm>(() => toForm(story));

  useEffect(() => {
    setForm(toForm(story));
  }, [story]);

  return (
    <div className="border border-white/10 bg-[#111111]">
      <div className="flex items-center gap-4 px-5 py-4">
        {story.cover ? (
          <img src={story.cover} alt="" className="h-12 w-16 shrink-0 border border-white/10 object-cover" />
        ) : (
          <div className="h-12 w-16 shrink-0 border border-white/10 bg-[#1a1a1a]" />
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-white">{story.title}</p>
          <p className="mt-0.5 text-[10px] uppercase tracking-[0.18em] text-[#7a7a7a]">
            {story.tag} · order {story.order} · {story.published ? "published" : "draft"}
          </p>
        </div>
        <a
          href={`/stories/${story.slug}`}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Open story page"
          className="hidden text-[#7a7a7a] transition-colors hover:text-white sm:block"
        >
          <ExternalLink className="h-4 w-4" strokeWidth={1.5} />
        </a>
        <button
          onClick={onToggle}
          aria-expanded={open}
          aria-label={open ? "Collapse" : "Edit"}
          className="flex h-8 w-8 items-center justify-center border border-white/15 text-[#9a9a9a] transition-colors hover:border-white/40 hover:text-white"
        >
          {open ? <ChevronUp className="h-4 w-4" strokeWidth={1.5} /> : <ChevronDown className="h-4 w-4" strokeWidth={1.5} />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-white/10 p-5">
          <StoryFields form={form} onChange={setForm} hideHeader />
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSave(form)}
              disabled={busy || !form.title.trim()}
              className="inline-flex items-center gap-2 bg-white px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors hover:bg-[#D97F3E] disabled:opacity-50"
            >
              {busy ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} /> : null}
              Save story
            </button>
            <button
              onClick={onDelete}
              disabled={busy}
              className="inline-flex items-center gap-2 border border-red-500/40 px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-red-400 transition-colors hover:bg-red-500/10 disabled:opacity-50"
            >
              <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} /> Delete
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function StoryFields({
  form, onChange, actions, hideHeader,
}: {
  form: StoryForm;
  onChange: (f: StoryForm) => void;
  actions?: React.ReactNode;
  hideHeader?: boolean;
}) {
  function set<K extends keyof StoryForm>(key: K, value: StoryForm[K]) {
    onChange({ ...form, [key]: value });
  }

  return (
    <div className="space-y-4">
      {hideHeader ? null : (
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">Story details</p>
      )}
      <Grid2>
        <TextField label="Title *" value={form.title} onChange={(v) => set("title", v)} placeholder="e.g. Monsoon Waterfall Diaries" />
        <TextField label="URL slug" mono value={form.slug} onChange={(v) => set("slug", v)} placeholder="auto from title" />
      </Grid2>
      <TextAreaField label="Standfirst — one bold sentence under the title" rows={2} value={form.dek} onChange={(v) => set("dek", v)} />
      <Grid2>
        <TextField label="Tag" value={form.tag} onChange={(v) => set("tag", v)} placeholder="Ride Journal" />
        <TextField label="Location" value={form.location} onChange={(v) => set("location", v)} placeholder="Spiti Valley, Himachal" />
        <TextField label="Date" value={form.date} onChange={(v) => set("date", v)} placeholder="August 2024" />
        <TextField label="Read time" value={form.readTime} onChange={(v) => set("readTime", v)} placeholder="5 min read" />
      </Grid2>
      <ImageField label="Cover image" value={form.cover} onChange={(v) => set("cover", v)} />
      <TextField label="Cover alt text" value={form.coverAlt} onChange={(v) => set("coverAlt", v)} />
      <TextAreaField label="Excerpt (card text)" rows={2} value={form.excerpt} onChange={(v) => set("excerpt", v)} />
      <TextAreaField
        label="Article body"
        rows={12}
        value={form.body}
        onChange={(v) => set("body", v)}
      />
      <div className="border border-white/10 bg-[#0d0d0d] px-4 py-3 text-xs leading-relaxed text-[#8a8a8a]">
        <p className="mb-1.5 font-semibold uppercase tracking-[0.18em] text-[#D97F3E]">Body formatting</p>
        <p>Separate blocks with a blank line. Use these prefixes:</p>
        <p className="mt-1.5 font-mono text-[11px] text-[#b8b8b8]">
          ## Section heading &nbsp;·&nbsp; ### Sub heading &nbsp;·&nbsp; &gt; Pull quote<br />
          - List item &nbsp;·&nbsp; ![image caption](image URL) &nbsp;·&nbsp; plain paragraphs
        </p>
      </div>
      <Grid2>
        <NumberField label="Display order" value={form.order} onChange={(v) => set("order", v)} min={0} max={99} />
        <ToggleField label="Published" checked={form.published} onChange={(v) => set("published", v)} hint="Visible on the public site" />
      </Grid2>
      {actions ? <div className="pt-1">{actions}</div> : null}
    </div>
  );
}
