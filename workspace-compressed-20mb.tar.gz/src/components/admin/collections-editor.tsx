"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ChevronDown, ChevronUp, LoaderCircle, Plus, Trash2 } from "lucide-react";
import {
  ImageField,
  NumberField,
  Panel,
  TextAreaField,
  TextField,
} from "./field";
import { api, type AdminGalleryItem, type AdminInstagramItem, type AdminVideoItem } from "./types";

/**
 * Ordered-collection managers for Gallery, YouTube videos and
 * Instagram posts. One generic implementation, three configurations.
 */

type Item = AdminGalleryItem | AdminVideoItem | AdminInstagramItem;

interface FieldDef<T extends Item> {
  key: keyof T & string;
  label: string;
  kind: "text" | "image" | "textarea" | "number";
  placeholder?: string;
  mono?: boolean;
}

interface CollectionConfig<T extends Item> {
  endpoint: string;
  title: string;
  description: string;
  fields: FieldDef<T>[];
  required: (keyof T & string)[];
  emptyItem: () => T;
  itemTitle: (item: T) => string;
  itemImage?: (item: T) => string;
  newIsAllowed?: boolean;
}

function CollectionEditor<T extends Item & { id: string; order: number }>({
  cfg,
}: {
  cfg: CollectionConfig<T>;
}) {
  const router = useRouter();
  const [items, setItems] = useState<T[] | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState<T | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    try {
      setItems(await api<T[]>(cfg.endpoint));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load items");
    }
  }

  useEffect(() => {
    void load();
     
  }, []);

  async function create() {
    if (!draft) return;
    setBusy(true);
    setError("");
    try {
      await api(cfg.endpoint, { method: "POST", body: JSON.stringify(draft) });
      setDraft(null);
      setCreating(false);
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not create item");
    } finally {
      setBusy(false);
    }
  }

  async function save(item: T) {
    setBusy(true);
    setError("");
    try {
      await api(`${cfg.endpoint}/${item.id}`, {
        method: "PATCH",
        body: JSON.stringify(item),
      });
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save item");
    } finally {
      setBusy(false);
    }
  }

  async function remove(item: T) {
    if (!window.confirm(`Delete “${cfg.itemTitle(item)}” permanently?`)) return;
    setBusy(true);
    setError("");
    try {
      await api(`${cfg.endpoint}/${item.id}`, { method: "DELETE" });
      await load();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not delete item");
    } finally {
      setBusy(false);
    }
  }

  function renderFields(item: T, onChange: (item: T) => void) {
    return cfg.fields.map((f) => {
      const value = item[f.key];
      const set = (v: unknown) => onChange({ ...item, [f.key]: v } as T);
      if (f.kind === "image") {
        return (
          <ImageField key={f.key} label={f.label} value={String(value ?? "")} onChange={set} />
        );
      }
      if (f.kind === "textarea") {
        return (
          <TextAreaField key={f.key} label={f.label} value={String(value ?? "")} onChange={set} rows={3} />
        );
      }
      if (f.kind === "number") {
        return (
          <NumberField key={f.key} label={f.label} value={Number(value ?? 0)} onChange={set} min={0} max={999} />
        );
      }
      return (
        <TextField key={f.key} label={f.label} value={String(value ?? "")} onChange={set} placeholder={f.placeholder} mono={f.mono} />
      );
    });
  }

  const sorted = [...(items ?? [])].sort((a, b) => a.order - b.order);

  return (
    <div className="space-y-6">
      {error ? (
        <p className="border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</p>
      ) : null}

      <Panel title={cfg.title} description={cfg.description}>
        {creating && draft ? (
          <div className="space-y-4">
            {renderFields(draft, setDraft)}
            <div className="flex gap-3">
              <button
                onClick={create}
                disabled={busy || cfg.required.some((k) => !String(draft[k] ?? "").trim())}
                className="inline-flex items-center gap-2 bg-white px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors hover:bg-[#D97F3E] disabled:opacity-50"
              >
                {busy ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} /> : <Plus className="h-3.5 w-3.5" strokeWidth={2} />}
                Add
              </button>
              <button
                onClick={() => { setCreating(false); setDraft(null); }}
                className="border border-white/25 px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:border-white"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => { setDraft(cfg.emptyItem()); setCreating(true); }}
            className="inline-flex items-center gap-2 border border-dashed border-white/25 px-5 py-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9a9a9a] transition-colors hover:border-[#D97F3E] hover:text-[#D97F3E]"
          >
            <Plus className="h-4 w-4" strokeWidth={1.75} /> Add new
          </button>
        )}
      </Panel>

      {!items ? (
        <div className="flex items-center gap-3 p-6 text-sm text-[#8a8a8a]">
          <LoaderCircle className="h-4 w-4 animate-spin" strokeWidth={2} /> Loading…
        </div>
      ) : (
        <div className="space-y-3">
          {sorted.map((item) => (
            <ItemCard
              key={item.id}
              item={item}
              open={openId === item.id}
              onToggle={() => setOpenId(openId === item.id ? null : item.id)}
              onSave={(draft) => save(draft)}
              onDelete={() => remove(item)}
              busy={busy}
              cfg={cfg}
              renderFields={renderFields}
            />
          ))}
          {sorted.length === 0 ? (
            <p className="border border-white/10 px-5 py-6 text-sm text-[#7a7a7a]">
              Nothing here yet — add the first item above.
            </p>
          ) : null}
        </div>
      )}
    </div>
  );
}

function ItemCard<T extends Item & { id: string; order: number }>({
  item, open, onToggle, onSave, onDelete, busy, cfg, renderFields,
}: {
  item: T;
  open: boolean;
  onToggle: () => void;
  /** Receives the edited draft so typed changes are actually persisted */
  onSave: (draft: T) => void;
  onDelete: () => void;
  busy: boolean;
  cfg: CollectionConfig<T>;
  renderFields: (item: T, onChange: (item: T) => void) => React.ReactNode;
}) {
  const [draft, setDraft] = useState<T>(item);

  useEffect(() => {
    setDraft(item);
  }, [item]);

  const img = cfg.itemImage?.(item);

  return (
    <div className="border border-white/10 bg-[#111111]">
      <div className="flex items-center gap-4 px-5 py-3.5">
        {img ? (
           
          <img src={img} alt="" className="h-11 w-14 shrink-0 border border-white/10 object-cover" />
        ) : (
          <div className="h-11 w-14 shrink-0 border border-white/10 bg-[#1a1a1a]" />
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-white">{cfg.itemTitle(item)}</p>
          <p className="mt-0.5 text-[10px] uppercase tracking-[0.18em] text-[#7a7a7a]">order {item.order}</p>
        </div>
        <button
          onClick={onToggle}
          aria-expanded={open}
          aria-label={open ? "Collapse" : "Edit"}
          className="flex h-8 w-8 items-center justify-center border border-white/15 text-[#9a9a9a] transition-colors hover:border-white/40 hover:text-white"
        >
          {open ? <ChevronUp className="h-4 w-4" strokeWidth={1.5} /> : <ChevronDown className="h-4 w-4" strokeWidth={1.5} />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-white/10 p-5">
          <div className="space-y-4">{renderFields(draft, setDraft)}</div>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onSave(draft)}
              disabled={busy}
              className="inline-flex items-center gap-2 bg-white px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors hover:bg-[#D97F3E] disabled:opacity-50"
            >
              {busy ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} /> : null}
              Save
            </button>
            <button
              onClick={onDelete}
              disabled={busy}
              className="inline-flex items-center gap-2 border border-red-500/40 px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-red-400 transition-colors hover:bg-red-500/10 disabled:opacity-50"
            >
              <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} /> Delete
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* ---------------- exported configurations ---------------- */

export function GalleryManager() {
  return (
    <CollectionEditor<AdminGalleryItem>
      cfg={{
        endpoint: "/api/admin/gallery",
        title: "Gallery photos",
        description: "Images shown in the homepage gallery grid and the Gallery page (masonry + lightbox).",
        fields: [
          { key: "src", label: "Image", kind: "image" },
          { key: "alt", label: "Alt text", kind: "text" },
          { key: "caption", label: "Caption", kind: "text" },
          { key: "category", label: "Category", kind: "text", placeholder: "Riders" },
          { key: "order", label: "Order", kind: "number" },
        ],
        required: ["src"],
        emptyItem: () => ({ id: "", src: "", alt: "", caption: "", category: "Riders", order: 0 }),
        itemTitle: (g) => g.caption || g.alt || g.src,
        itemImage: (g) => g.src,
      }}
    />
  );
}

export function VideosManager() {
  return (
    <CollectionEditor<AdminVideoItem>
      cfg={{
        endpoint: "/api/admin/videos",
        title: "YouTube videos",
        description: "Official films embedded on the homepage and Watch page. Paste the 11-character YouTube video ID.",
        fields: [
          { key: "videoId", label: "YouTube video ID", kind: "text", mono: true, placeholder: "bFYuyV7l8Uc" },
          { key: "title", label: "Title", kind: "text" },
          { key: "location", label: "Label / location", kind: "text" },
          { key: "description", label: "Description", kind: "textarea" },
          { key: "order", label: "Order", kind: "number" },
        ],
        required: ["videoId", "title"],
        emptyItem: () => ({ id: "", videoId: "", title: "", location: "", description: "", order: 0 }),
        itemTitle: (v) => v.title || v.videoId,
      }}
    />
  );
}

export function InstagramManager() {
  return (
    <CollectionEditor<AdminInstagramItem>
      cfg={{
        endpoint: "/api/admin/instagram",
        title: "Instagram posts",
        description:
          "Grid cards and the Instagram-style post viewer — caption, likes, location and date show when a visitor opens a post.",
        fields: [
          { key: "src", label: "Image", kind: "image" },
          { key: "caption", label: "Caption", kind: "textarea", placeholder: "Mountains heals me …" },
          { key: "location", label: "Location line", kind: "text", placeholder: "Himalayas, Uttarakhand" },
          { key: "likes", label: "Likes", kind: "number" },
          { key: "dateLabel", label: "Date label", kind: "text", placeholder: "3 days ago / February 19" },
          { key: "alt", label: "Alt text", kind: "text" },
          { key: "permalink", label: "Post URL", kind: "text", mono: true, placeholder: "https://www.instagram.com/p/…" },
          { key: "order", label: "Order", kind: "number" },
        ],
        required: ["src"],
        emptyItem: () => ({ id: "", src: "", alt: "", caption: "", location: "", likes: 0, dateLabel: "", permalink: "", order: 0 }),
        itemTitle: (i) => i.caption || i.alt || i.permalink || i.src,
        itemImage: (i) => i.src,
      }}
    />
  );
}
