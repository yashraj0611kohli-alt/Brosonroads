"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  BookOpen,
  Camera,
  Images,
  LogOut,
  Menu,
  Mountain,
  Newspaper,
  Palette,
  UserRound,
  X,
  Youtube,
} from "lucide-react";
import { SettingsEditor } from "./settings-editor";
import { RidesEditor } from "./rides-editor";
import { GalleryManager, InstagramManager, VideosManager } from "./collections-editor";
import { StoriesEditor } from "./stories-editor";
import { AccountPanel } from "./account-panel";
import { api, type AdminSettings } from "./types";

/**
 * Admin application shell — sidebar navigation (desktop) / tab bar
 * (mobile) around the editors.
 */

type TabId = "content" | "rides" | "stories" | "gallery" | "videos" | "instagram" | "account";

const TABS: { id: TabId; label: string; icon: typeof Mountain }[] = [
  { id: "content", label: "Site Content", icon: Newspaper },
  { id: "rides", label: "Rides", icon: Mountain },
  { id: "stories", label: "Real Stories", icon: BookOpen },
  { id: "gallery", label: "Gallery", icon: Images },
  { id: "videos", label: "YouTube", icon: Youtube },
  { id: "instagram", label: "Instagram", icon: Camera },
  { id: "account", label: "Account", icon: UserRound },
];

export function AdminApp({
  settings,
  username,
}: {
  settings: AdminSettings;
  username: string;
}) {
  const router = useRouter();
  const [tab, setTab] = useState<TabId>("content");
  const [menuOpen, setMenuOpen] = useState(false);

  function go(next: TabId) {
    setTab(next);
    setMenuOpen(false);
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" }).catch(() => undefined);
    router.replace("/admin/login");
    router.refresh();
  }

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      {/* Sidebar — desktop */}
      <aside className="hidden w-60 shrink-0 border-r border-white/10 bg-[#0E0E0E] md:flex md:flex-col">
        <div className="border-b border-white/10 px-6 py-6">
          <p className="display-title text-lg font-bold tracking-tight text-white">
            BROS<span className="text-[#D97F3E]">ON</span>ROADS
          </p>
          <p className="mt-1 text-[9px] uppercase tracking-[0.3em] text-[#6a6a6a]">Admin panel</p>
        </div>
        <nav className="flex-1 space-y-1 px-3 py-4" aria-label="Admin sections">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => go(t.id)}
              aria-current={tab === t.id ? "page" : undefined}
              className={`flex w-full items-center gap-3 px-3 py-2.5 text-left text-sm transition-colors ${
                tab === t.id
                  ? "bg-[#D97F3E]/15 font-semibold text-[#D97F3E]"
                  : "text-[#9a9a9a] hover:bg-white/5 hover:text-white"
              }`}
            >
              <t.icon className="h-4 w-4 shrink-0" strokeWidth={1.5} />
              {t.label}
            </button>
          ))}
        </nav>
        <div className="space-y-1 border-t border-white/10 px-3 py-4">
          <Link
            href="/"
            className="flex items-center gap-3 px-3 py-2.5 text-sm text-[#9a9a9a] transition-colors hover:bg-white/5 hover:text-white"
          >
            <Palette className="h-4 w-4" strokeWidth={1.5} /> View site
          </Link>
          <button
            onClick={logout}
            className="flex w-full items-center gap-3 px-3 py-2.5 text-left text-sm text-[#9a9a9a] transition-colors hover:bg-white/5 hover:text-white"
          >
            <LogOut className="h-4 w-4" strokeWidth={1.5} /> Sign out
          </button>
        </div>
      </aside>

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top bar — brand + mobile menu */}
        <header className="sticky top-0 z-30 border-b border-white/10 bg-[#0B0B0B]/95 backdrop-blur">
          <div className="flex items-center justify-between px-4 py-3.5 md:px-6">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setMenuOpen((v) => !v)}
                aria-expanded={menuOpen}
                aria-label="Toggle navigation"
                className="flex h-9 w-9 items-center justify-center border border-white/15 text-white md:hidden"
              >
                {menuOpen ? <X className="h-4 w-4" strokeWidth={1.5} /> : <Menu className="h-4 w-4" strokeWidth={1.5} />}
              </button>
              <p className="display-title text-sm font-bold tracking-tight text-white md:hidden">
                BROS<span className="text-[#D97F3E]">ON</span>ROADS
              </p>
              <p className="hidden text-[10px] uppercase tracking-[0.3em] text-[#6a6a6a] md:block">
                {TABS.find((t) => t.id === tab)?.label} — manage everything visitors see
              </p>
            </div>
            <Link
              href="/"
              className="hidden border border-white/25 px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:border-[#D97F3E] hover:text-[#D97F3E] md:inline-flex"
            >
              View site
            </Link>
          </div>

          {/* Mobile nav drawer */}
          {menuOpen ? (
            <nav className="border-t border-white/10 px-3 pb-3 pt-2 md:hidden" aria-label="Admin sections">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => go(t.id)}
                  className={`flex w-full items-center gap-3 px-3 py-2.5 text-left text-sm transition-colors ${
                    tab === t.id
                      ? "font-semibold text-[#D97F3E]"
                      : "text-[#9a9a9a]"
                  }`}
                >
                  <t.icon className="h-4 w-4" strokeWidth={1.5} />
                  {t.label}
                </button>
              ))}
              <Link href="/" className="flex items-center gap-3 px-3 py-2.5 text-sm text-[#9a9a9a]">
                <Palette className="h-4 w-4" strokeWidth={1.5} /> View site
              </Link>
              <button
                onClick={logout}
                className="flex w-full items-center gap-3 px-3 py-2.5 text-left text-sm text-[#9a9a9a]"
              >
                <LogOut className="h-4 w-4" strokeWidth={1.5} /> Sign out
              </button>
            </nav>
          ) : null}
        </header>

        <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-6 md:px-6 md:py-8">
          {tab === "content" ? <SettingsEditor initial={settings} /> : null}
          {tab === "rides" ? <RidesEditor /> : null}
          {tab === "stories" ? <StoriesEditor /> : null}
          {tab === "gallery" ? <GalleryManager /> : null}
          {tab === "videos" ? <VideosManager /> : null}
          {tab === "instagram" ? <InstagramManager /> : null}
          {tab === "account" ? <AccountPanel username={username} /> : null}
        </main>
      </div>
    </div>
  );
}
