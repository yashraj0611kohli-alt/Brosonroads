"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { KeyRound, LoaderCircle, LogOut, Check } from "lucide-react";
import { Panel, adminInput, FieldLabel } from "./field";
import { api } from "./types";

/** Account management — change the admin password, sign out. */
export function AccountPanel({ username }: { username: string }) {
  const router = useRouter();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setDone(false);
    if (next.length < 8) {
      setError("New password must be at least 8 characters.");
      return;
    }
    if (next !== confirm) {
      setError("New passwords do not match.");
      return;
    }
    setBusy(true);
    try {
      await api("/api/admin/password", {
        method: "POST",
        body: JSON.stringify({ current, next }),
      });
      setCurrent("");
      setNext("");
      setConfirm("");
      setDone(true);
      setTimeout(() => setDone(false), 3500);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not change password");
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" }).catch(() => undefined);
    router.replace("/admin/login");
    router.refresh();
  }

  return (
    <div className="max-w-xl space-y-6">
      <Panel title="Signed in as" description="This is the only account with access to site management.">
        <p className="font-mono text-sm text-white">{username}</p>
        <button
          onClick={logout}
          className="mt-4 inline-flex items-center gap-2 border border-white/25 px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-white transition-colors hover:border-red-500/60 hover:text-red-400"
        >
          <LogOut className="h-3.5 w-3.5" strokeWidth={1.75} /> Sign out
        </button>
      </Panel>

      <Panel title="Change password" description="Pick something at least 8 characters long.">
        <form onSubmit={changePassword} className="space-y-4">
          <div>
            <FieldLabel htmlFor="pw-current">Current password</FieldLabel>
            <input
              id="pw-current"
              type="password"
              autoComplete="current-password"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              required
              className={adminInput}
            />
          </div>
          <div>
            <FieldLabel htmlFor="pw-next">New password</FieldLabel>
            <input
              id="pw-next"
              type="password"
              autoComplete="new-password"
              value={next}
              onChange={(e) => setNext(e.target.value)}
              required
              minLength={8}
              className={adminInput}
            />
          </div>
          <div>
            <FieldLabel htmlFor="pw-confirm">Repeat new password</FieldLabel>
            <input
              id="pw-confirm"
              type="password"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              required
              minLength={8}
              className={adminInput}
            />
          </div>
          {error ? <p className="text-xs text-red-400">{error}</p> : null}
          {done ? (
            <p className="flex items-center gap-1.5 text-xs text-[#7fbf7f]">
              <Check className="h-3.5 w-3.5" strokeWidth={2} /> Password updated.
            </p>
          ) : null}
          <button
            type="submit"
            disabled={busy}
            className="inline-flex items-center gap-2 bg-white px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors hover:bg-[#D97F3E] disabled:opacity-60"
          >
            {busy ? (
              <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} />
            ) : (
              <KeyRound className="h-3.5 w-3.5" strokeWidth={1.75} />
            )}
            Update password
          </button>
        </form>
      </Panel>
    </div>
  );
}
