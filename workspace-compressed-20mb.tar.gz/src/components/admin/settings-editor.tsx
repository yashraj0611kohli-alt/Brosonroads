"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Save, LoaderCircle, Check } from "lucide-react";
import {
  FieldLabel,
  Grid2,
  ImageField,
  NumberField,
  Panel,
  StringListField,
  TextAreaField,
  TextField,
  ToggleField,
  adminInput,
} from "./field";
import { api, type AdminContact, type AdminSettings } from "./types";

/**
 * Full site content editor — every heading, text, image and link of
 * the public site (homepage sections + internal page banners) in one
 * place. Saving writes through /api/admin/settings; the site picks
 * changes up on the next request (all pages are dynamic).
 */

const BANNERS = [
  { prefix: "rides", label: "Rides page banner" },
  { prefix: "about", label: "About page banner" },
  { prefix: "gallery", label: "Gallery page banner" },
  { prefix: "watch", label: "Watch page banner" },
  { prefix: "stories", label: "Real Stories page banner" },
  { prefix: "join", label: "Join Us page banner" },
] as const;

export function SettingsEditor({ initial }: { initial: AdminSettings }) {
  const router = useRouter();
  const [s, setS] = useState<AdminSettings>(initial);
  const [baseline, setBaseline] = useState<AdminSettings>(initial);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  function set<K extends keyof AdminSettings>(key: K, value: AdminSettings[K]) {
    setS((prev) => ({ ...prev, [key]: value }));
    setSaved(false);
  }

  function setContact(i: number, patch: Partial<AdminContact>) {
    const next = s.contacts.map((c, idx) => (idx === i ? { ...c, ...patch } : c));
    set("contacts", next);
  }

  async function save() {
    setSaving(true);
    setError("");
    try {
      const updated = await api<AdminSettings>("/api/admin/settings", {
        method: "PUT",
        body: JSON.stringify(s),
      });
      const merged = { ...s, ...updated };
      setS(merged);
      setBaseline(merged);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save");
    } finally {
      setSaving(false);
    }
  }

  const dirty = JSON.stringify(s) !== JSON.stringify(baseline);

  return (
    <div className="space-y-6">
      {/* sticky save bar */}
      <div className="sticky top-0 z-20 -mx-4 border-b border-white/10 bg-[#0B0B0B]/95 px-4 py-3 backdrop-blur md:-mx-6 md:px-6">
        <div className="flex items-center justify-between gap-4">
          <p className="text-xs text-[#8a8a8a]">
            {dirty ? "You have unsaved changes." : "All changes published to the live site."}
          </p>
          <div className="flex items-center gap-3">
            {saved ? (
              <span className="flex items-center gap-1.5 text-xs text-[#7fbf7f]">
                <Check className="h-3.5 w-3.5" strokeWidth={2} /> Saved
              </span>
            ) : null}
            <button
              onClick={save}
              disabled={saving}
              className="inline-flex items-center gap-2 bg-white px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors duration-300 hover:bg-[#D97F3E] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {saving ? (
                <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} />
              ) : (
                <Save className="h-3.5 w-3.5" strokeWidth={1.75} />
              )}
              Save changes
            </button>
          </div>
        </div>
        {error ? <p className="mt-2 text-xs text-red-400">{error}</p> : null}
      </div>

      {/* Hero */}
      <Panel title="Hero" description="The first screen of the homepage — film, headline and intro copy.">
        <Grid2>
          <TextField label="Eyebrow" value={s.heroEyebrow} onChange={(v) => set("heroEyebrow", v)} />
          <TextField label="Title" value={s.heroTitle} onChange={(v) => set("heroTitle", v)} />
        </Grid2>
        <TextField label="Subtitle" value={s.heroSubtitle} onChange={(v) => set("heroSubtitle", v)} />
        <TextAreaField label="Intro text" value={s.heroText} onChange={(v) => set("heroText", v)} rows={3} />
        <Grid2>
          <TextField label="Hero video URL" mono value={s.heroVideoUrl} onChange={(v) => set("heroVideoUrl", v)} placeholder="/videos/hero.mp4" />
          <TextField label="Hero poster image" mono value={s.heroPoster} onChange={(v) => set("heroPoster", v)} />
        </Grid2>
        <Grid2>
          <TextField label="Location label" value={s.heroLocation} onChange={(v) => set("heroLocation", v)} />
          <TextField label="Video meta label" value={s.heroMetaLabel} onChange={(v) => set("heroMetaLabel", v)} />
        </Grid2>
        <p className="text-xs text-[#6a6a6a]">
          Tip: the BROSONROADS title is styled as the brand two-line lockup (BROS / ON ROADS) automatically. Any other title text shows on a single line. To replace the hero film itself, upload a new MP4 and point “Hero video URL” at it — the poster image shows while it loads.
        </p>
      </Panel>

      {/* Homepage section headings */}
      <Panel title="Homepage sections" description="Headings and notes for each homepage block, top to bottom.">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <div className="space-y-4 border border-white/10 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">01 — Featured Rides</p>
            <TextField label="Eyebrow" value={s.ridesEyebrow} onChange={(v) => set("ridesEyebrow", v)} />
            <Grid2>
              <TextField label="Title line 1" value={s.ridesTitle1} onChange={(v) => set("ridesTitle1", v)} />
              <TextField label="Title line 2" value={s.ridesTitle2} onChange={(v) => set("ridesTitle2", v)} />
            </Grid2>
            <TextField label="Note" value={s.ridesNote} onChange={(v) => set("ridesNote", v)} />
          </div>

          <div className="space-y-4 border border-white/10 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">02 — Upcoming Rides</p>
            <TextField label="Eyebrow" value={s.upcomingEyebrow} onChange={(v) => set("upcomingEyebrow", v)} />
            <Grid2>
              <TextField label="Title line 1" value={s.upcomingTitle1} onChange={(v) => set("upcomingTitle1", v)} />
              <TextField label="Title line 2" value={s.upcomingTitle2} onChange={(v) => set("upcomingTitle2", v)} />
            </Grid2>
            <TextField label="Note" value={s.upcomingNote} onChange={(v) => set("upcomingNote", v)} />
            <ImageField label="Background image" value={s.upcomingBg} onChange={(v) => set("upcomingBg", v)} />
          </div>

          <div className="space-y-4 border border-white/10 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">03 — About</p>
            <TextField label="Eyebrow" value={s.aboutEyebrow} onChange={(v) => set("aboutEyebrow", v)} />
            <Grid2>
              <TextField label="Title line 1" value={s.aboutTitle1} onChange={(v) => set("aboutTitle1", v)} />
              <TextField label="Title line 2" value={s.aboutTitle2} onChange={(v) => set("aboutTitle2", v)} />
            </Grid2>
            <TextField label="Lead line" value={s.aboutLead} onChange={(v) => set("aboutLead", v)} />
            <StringListField label="Rhythm lines" items={s.aboutLines} onChange={(v) => set("aboutLines", v)} addLabel="Add line" />
            <TextAreaField label="Quote paragraph" value={s.aboutQuote} onChange={(v) => set("aboutQuote", v)} rows={4} />
            <ImageField label="About image" value={s.aboutImage} onChange={(v) => set("aboutImage", v)} />
            <TextField label="Image caption" value={s.aboutCaption} onChange={(v) => set("aboutCaption", v)} />
          </div>

          <div className="space-y-4 border border-white/10 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">04 — Gallery</p>
            <TextField label="Eyebrow" value={s.galleryEyebrow} onChange={(v) => set("galleryEyebrow", v)} />
            <Grid2>
              <TextField label="Title line 1" value={s.galleryTitle1} onChange={(v) => set("galleryTitle1", v)} />
              <TextField label="Title line 2" value={s.galleryTitle2} onChange={(v) => set("galleryTitle2", v)} />
            </Grid2>
            <TextField label="Note" value={s.galleryNote} onChange={(v) => set("galleryNote", v)} />
          </div>

          <div className="space-y-4 border border-white/10 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">05 — YouTube</p>
            <TextField label="Eyebrow" value={s.watchEyebrow} onChange={(v) => set("watchEyebrow", v)} />
            <Grid2>
              <TextField label="Title line 1" value={s.watchTitle1} onChange={(v) => set("watchTitle1", v)} />
              <TextField label="Title line 2" value={s.watchTitle2} onChange={(v) => set("watchTitle2", v)} />
            </Grid2>
            <TextAreaField label="Note" value={s.watchNote} onChange={(v) => set("watchNote", v)} rows={2} />
          </div>

          <div className="space-y-4 border border-white/10 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">06 — Instagram</p>
            <TextField label="Eyebrow" value={s.instagramEyebrow} onChange={(v) => set("instagramEyebrow", v)} />
            <Grid2>
              <TextField label="Title line 1" value={s.instagramTitle1} onChange={(v) => set("instagramTitle1", v)} />
              <TextField label="Title line 2" value={s.instagramTitle2} onChange={(v) => set("instagramTitle2", v)} />
            </Grid2>
          </div>

          <div className="space-y-4 border border-white/10 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">07 — Real Stories</p>
            <TextField label="Eyebrow" value={s.storiesEyebrow} onChange={(v) => set("storiesEyebrow", v)} />
            <Grid2>
              <TextField label="Title line 1" value={s.storiesTitle1} onChange={(v) => set("storiesTitle1", v)} />
              <TextField label="Title line 2" value={s.storiesTitle2} onChange={(v) => set("storiesTitle2", v)} />
            </Grid2>
            <TextAreaField label="Note" value={s.storiesNote} onChange={(v) => set("storiesNote", v)} rows={2} />
            <p className="text-xs text-[#6a6a6a]">
              The stories themselves are managed in the “Real Stories” tab.
            </p>
          </div>

          <div className="space-y-4 border border-white/10 p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">08 — Join Us</p>
            <TextField label="Eyebrow" value={s.joinEyebrow} onChange={(v) => set("joinEyebrow", v)} />
            <Grid2>
              <TextField label="Title line 1" value={s.joinTitle1} onChange={(v) => set("joinTitle1", v)} />
              <TextField label="Title line 2" value={s.joinTitle2} onChange={(v) => set("joinTitle2", v)} />
            </Grid2>
            <TextAreaField label="Text" value={s.joinText} onChange={(v) => set("joinText", v)} rows={3} />
            <ImageField label="Background image" value={s.joinBg} onChange={(v) => set("joinBg", v)} />
          </div>
        </div>
      </Panel>

      {/* Popup */}
      <Panel title="Ride popup" description="The timed “want to ride with us?” popup shown to visitors on the homepage.">
        <Grid2>
          <ToggleField label="Popup enabled" checked={s.popupEnabled} onChange={(v) => set("popupEnabled", v)} hint="Show the popup automatically" />
          <NumberField label="Delay (seconds)" value={s.popupDelaySec} onChange={(v) => set("popupDelaySec", v)} min={3} max={600} />
        </Grid2>
        <Grid2>
          <TextField label="Title line 1" value={s.popupTitle1} onChange={(v) => set("popupTitle1", v)} />
          <TextField label="Title line 2" value={s.popupTitle2} onChange={(v) => set("popupTitle2", v)} />
        </Grid2>
        <TextField label="Text" value={s.popupText} onChange={(v) => set("popupText", v)} />
        <ImageField label="Popup image" value={s.popupImage} onChange={(v) => set("popupImage", v)} />
      </Panel>

      {/* Internal page banners */}
      <Panel title="Internal page banners" description="Full-width image banners on the Rides, About, Gallery, Watch and Join pages.">
        <div className="space-y-5">
          {BANNERS.map(({ prefix, label }) => (
            <div key={prefix} className="border border-white/10 p-4">
              <p className="mb-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#D97F3E]">{label}</p>
              <div className="space-y-3">
                <ImageField label="Banner image" value={s[`${prefix}BannerImg` as keyof AdminSettings] as string} onChange={(v) => set(`${prefix}BannerImg` as keyof AdminSettings, v as never)} />
                <Grid2>
                  <TextField label="Eyebrow" value={s[`${prefix}BannerEyebrow` as keyof AdminSettings] as string} onChange={(v) => set(`${prefix}BannerEyebrow` as keyof AdminSettings, v as never)} />
                  <TextField label="Title" value={s[`${prefix}BannerTitle` as keyof AdminSettings] as string} onChange={(v) => set(`${prefix}BannerTitle` as keyof AdminSettings, v as never)} />
                </Grid2>
                <TextAreaField label="Subtitle" rows={2} value={s[`${prefix}BannerSub` as keyof AdminSettings] as string} onChange={(v) => set(`${prefix}BannerSub` as keyof AdminSettings, v as never)} />
              </div>
            </div>
          ))}
        </div>
      </Panel>

      {/* Social & contacts */}
      <Panel title="Social & contact" description="Links used across the site, the shared inbox and the people visitors can call or text.">
        <Grid2>
          <TextField label="YouTube channel URL" mono value={s.youtubeUrl} onChange={(v) => set("youtubeUrl", v)} />
          <TextField label="YouTube handle" value={s.youtubeHandle} onChange={(v) => set("youtubeHandle", v)} />
          <TextField label="Instagram profile URL" mono value={s.instagramUrl} onChange={(v) => set("instagramUrl", v)} />
          <TextField label="Instagram handle" value={s.instagramHandle} onChange={(v) => set("instagramHandle", v)} />
        </Grid2>
        <TextField label="Shared contact email" mono value={s.contactEmail} onChange={(v) => set("contactEmail", v)} />

        <div className="space-y-4 pt-2">
          <FieldLabel>Contact people</FieldLabel>
          {s.contacts.map((c, i) => (
            <div key={i} className="border border-white/10 p-4">
              <Grid2>
                <TextField label="Name" value={c.name} onChange={(v) => setContact(i, { name: v })} />
                <TextField label="Role" value={c.role} onChange={(v) => setContact(i, { role: v })} />
                <TextField label="Phone (shown)" value={c.phone} onChange={(v) => setContact(i, { phone: v })} placeholder="+91 99115 61887" />
                <TextField label="Dial number (tel/sms)" mono value={c.dial} onChange={(v) => setContact(i, { dial: v })} placeholder="+919911561887" />
              </Grid2>
              <div className="mt-3">
                <TextField label="Email (optional)" mono value={c.email ?? ""} onChange={(v) => setContact(i, { email: v || undefined })} />
              </div>
              {s.contacts.length > 1 ? (
                <button
                  type="button"
                  onClick={() => set("contacts", s.contacts.filter((_, idx) => idx !== i))}
                  className="mt-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#8a8a8a] transition-colors hover:text-red-400"
                >
                  Remove contact
                </button>
              ) : null}
            </div>
          ))}
          {s.contacts.length < 4 ? (
            <button
              type="button"
              onClick={() =>
                set("contacts", [
                  ...s.contacts,
                  { name: "", role: "", phone: "", dial: "" },
                ])
              }
              className="border border-dashed border-white/25 px-3.5 py-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#8a8a8a] transition-colors hover:border-[#D97F3E] hover:text-[#D97F3E]"
            >
              + Add contact
            </button>
          ) : null}
          <p className="text-xs text-[#6a6a6a]">Contacts power the Join section, the ride popup and the ride detail pages (max 4).</p>
        </div>
      </Panel>

      {/* bottom save */}
      <div className="flex justify-end pb-6">
        <button
          onClick={save}
          disabled={saving}
          className="inline-flex items-center gap-2 bg-white px-6 py-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-black transition-colors duration-300 hover:bg-[#D97F3E] disabled:opacity-60"
        >
          {saving ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" strokeWidth={2} /> : <Save className="h-3.5 w-3.5" strokeWidth={1.75} />}
          Save changes
        </button>
      </div>
    </div>
  );
}
