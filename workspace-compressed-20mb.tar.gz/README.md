# BROSONROADS

**Two wheels. Endless roads. Real experiences.**

The official website of BrosonRoads — a motorcycle touring brand documenting journeys through Uttarakhand, Himachal Pradesh and the Himalayas. The site ships with a built-in content management system, so every heading, paragraph, image, ride, gallery photo and story is editable from an admin panel — no code changes required.

![Tech](https://img.shields.io/badge/Next.js-16-black) ![Tech](https://img.shields.io/badge/TypeScript-5-blue) ![Tech](https://img.shields.io/badge/Prisma-6-2D3748) ![Tech](https://img.shields.io/badge/Tailwind_CSS-4-38BDF8)

---

## Features

- **Cinematic homepage** — full-screen hero video, featured rides, upcoming rides, about, gallery with lightbox, YouTube integration, Instagram section with an Instagram-style post viewer, stories teaser and contact section
- **Internal pages** — `/rides` + ride detail pages, `/stories` + full article pages, `/about`, `/gallery`, `/watch`, `/join`
- **Real Stories** — a magazine-style article vertical with covers, pull quotes, inline figures and prev/next navigation
- **Built-in CMS at `/admin`** — edit every section heading, text and image; manage rides, gallery, videos, Instagram posts and stories; upload images; change password
- **SEO-ready** — auto-generated `sitemap.xml` (includes all published rides and stories), `robots.txt`, Open Graph/Twitter metadata, JSON-LD structured data, canonical URLs
- **Responsive & accessible** — mobile-first layouts, reduced-motion support, keyboard-friendly modals

## Tech Stack

| Layer      | Technology                          |
| ---------- | ----------------------------------- |
| Framework  | Next.js 16 (App Router) + React 19  |
| Language   | TypeScript                          |
| Styling    | Tailwind CSS 4 + shadcn/ui          |
| Database   | SQLite via Prisma ORM               |
| Runtime    | Bun (Node.js works too)             |

## Quick Start

### 1. Prerequisites

- [Bun](https://bun.sh/) v1.1+ (or Node.js 20+ with npm/pnpm)
- Git

### 2. Install & configure

```bash
git clone https://github.com/<your-username>/brosonroads.git
cd brosonroads
bun install                # runs `prisma generate` automatically

# create your environment file
cp .env.example .env
```

Open `.env` and set:

| Variable              | Purpose                                                        |
| --------------------- | -------------------------------------------------------------- |
| `DATABASE_URL`        | SQLite file path (default template value works out of the box) |
| `NEXT_PUBLIC_SITE_URL`| Your production domain — used for metadata, sitemap and robots |
| `ADMIN_SECRET`        | Long random string used to sign admin session cookies          |

### 3. Create the database & your admin account

```bash
bun run db:push            # creates the SQLite schema

# create your personal admin login (never committed to git)
ADMIN_USERNAME="your-username" ADMIN_PASSWORD="your-strong-password" bun run seed
```

The seed script fills the site with starter content (rides, stories, gallery, settings) and stores your admin login **only as a scrypt hash** in the database. The plain password is never printed, logged or committed.

### 4. Run

```bash
bun run dev                # http://localhost:3000
```

- Public site → `http://localhost:3000`
- Admin panel → `http://localhost:3000/admin` (sign in with the credentials you seeded)

## Managing Content

Everything on the site is editable from the admin panel:

- **Site Content** — hero (incl. video), every homepage section heading/text/image, internal-page banners, social links, contact people
- **Rides** — create/edit/publish/delete featured & upcoming rides with highlights, routes and images
- **Gallery / YouTube / Instagram** — full CRUD with image upload and Instagram-style captions
- **Real Stories** — write, edit, publish and order articles with covers, tags and rich bodies
- **Account** — change password, sign out

New content appears on the public site immediately after saving. If the database is ever unreachable, the site falls back to bundled default content so it never goes down.

To swap the hero film, simply replace `public/videos/hero.mp4` and `public/videos/hero-poster.jpg` (keep the file names).

## Search Engine Optimization

- `GET /sitemap.xml` — generated dynamically; always lists all static pages **plus every published ride and story**
- `GET /robots.txt` — allows all crawlers, points to the sitemap, blocks `/admin` and `/api`
- Admin pages are `noindex`, public pages carry canonical URLs, Open Graph and Twitter card metadata
- **Before going live:** set `NEXT_PUBLIC_SITE_URL` in `.env` to your real domain so the sitemap, robots and canonical URLs use it, then submit `https://your-domain.com/sitemap.xml` in [Google Search Console](https://search.google.com/search-console)

## Deployment Notes

The project uses **SQLite** (a file database). This works on any host with a persistent filesystem (VPS, Railway, Fly.io, Docker, self-hosted). On serverless platforms such as Vercel, the filesystem is ephemeral — either attach a hosted database or run the app on a persistent host.

```bash
bun run build              # production build (standalone output)
bun run start              # serves on the port you configure
```

Remember to set `DATABASE_URL`, `NEXT_PUBLIC_SITE_URL` and `ADMIN_SECRET` in your host's environment variables, and run the seed step once against the production database.

## Project Structure

```
src/
├── app/
│   ├── (site)/            # public pages (home, rides, stories, gallery…)
│   ├── admin/             # CMS: login + dashboard
│   ├── api/               # admin APIs (auth-guarded) + media serving
│   ├── sitemap.ts         # dynamic sitemap.xml
│   └── robots.ts          # dynamic robots.txt
├── components/
│   ├── site/              # homepage & page sections
│   └── admin/             # dashboard editors
└── lib/
    ├── site.ts            # central brand config (social links, contacts)
    ├── defaults.ts        # bundled fallback content
    ├── store.ts           # CMS data layer (DB → public site)
    └── auth.ts            # session cookies, scrypt hashing, rate limiting
prisma/schema.prisma       # CMS database schema
scripts/seed.ts            # DB seed + admin account creation
public/videos/             # self-hosted hero film + poster
public/instagram/          # Instagram section media
```

## Security Model

- Admin credentials exist only as a **scrypt hash** inside the SQLite database — never in code or git
- Sessions are **HMAC-signed HttpOnly cookies** with automatic expiry; sign the cookie with a strong `ADMIN_SECRET`
- Login is **rate-limited** and returns generic errors (no username enumeration)
- Every admin API route independently verifies the session
- The login page and admin panel contain no credential hints of any kind
