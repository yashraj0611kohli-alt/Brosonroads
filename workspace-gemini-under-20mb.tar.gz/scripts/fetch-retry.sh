#!/bin/bash
# Sequential retry pass for failed image searches
cd /home/z/my-project/assets-search

fetch() {
  local name="$1"; local query="$2"; local count="$3"
  for attempt in 1 2 3 4; do
    if grep -q '"success": true' "$name.json" 2>/dev/null; then
      echo "OK $name (already)"
      return 0
    fi
    echo "fetch $name (attempt $attempt)..."
    z-ai image-search -q "$query" -c "$count" --gl us --no-rank > "$name.json" 2> "$name.err"
    sleep 2
  done
  grep -q '"success": true' "$name.json" && echo "OK $name" || echo "FAIL $name"
}

fetch hero "motorcycle rider riding on a Himalayan mountain road in Uttarakhand India, cinematic landscape" 8
fetch valley "Valley of Flowers National Park Uttarakhand Himalayan meadow with wildflowers" 5
fetch chopta "Tungnath temple Chopta Uttarakhand Himalayan mountains trail" 5
fetch waterfall "beautiful waterfall in green forest Uttarakhand Himalayas India" 5
fetch kedarnath "Kedarnath valley Uttarakhand Himalayan mountains temple" 5
fetch nainital "Nainital lake Uttarakhand hill station mountains India" 4
fetch rider "motorcycle adventure rider on high altitude Himalayan mountain pass road India" 8
fetch sunset "motorcycle on mountain road at golden sunset Himalayas" 5
fetch road "winding mountain road through green Himalayan valley Uttarakhand" 6
fetch portrait "motorcyclist standing next to motorcycle with Himalayan mountains background" 5

echo "RETRY PASS COMPLETE"
