/**
 * Assigns searched images to BROSONROADS design slots.
 * - Reads JSON results from /home/z/my-project/assets-search/*.json
 * - Picks landscape, high-res images where large slots need them
 * - Dedupes across slots
 * - HEAD-checks every selected URL; swaps in spares if any fail
 * - Writes src/lib/images.ts with a SLOT -> URL record
 */
const fs = require("fs");
const path = require("path");

const DIR = "/home/z/my-project/assets-search";
const OUT = "/home/z/my-project/src/lib/images.ts";

const files = [
  "hero", "valley", "chopta", "waterfall", "spiti", "kedarnath",
  "nainital", "rider", "camping", "sunset", "road", "portrait",
];

/* Stock-agency sources ship watermarked comps — never use them */
const BLOCKLIST = /alamy|shutterstock|gettyimages|istockphoto|dreamstime|123rf|depositphotos|agefotostock|picfair|bigstock/i;

function load() {
  const pool = [];
  for (const f of files) {
    const p = path.join(DIR, `${f}.json`);
    if (!fs.existsSync(p)) { console.warn(`missing ${f}.json`); continue; }
    const raw = fs.readFileSync(p, "utf8");
    const json = JSON.parse(raw.slice(raw.indexOf("{")));
    if (!json.success) continue;
    for (const r of json.results) {
      if (BLOCKLIST.test(r.source || "")) continue;
      const w = parseInt(r.original_width) || 0;
      const h = parseInt(r.original_height) || 0;
      pool.push({
        file: f,
        url: r.original_url,
        w, h,
        ratio: h > 0 ? w / h : 1,
        px: w * h,
        source: r.source || "",
      });
    }
  }
  // dedupe by url
  const seen = new Set();
  return pool.filter((i) => (seen.has(i.url) ? false : (seen.add(i.url), true)));
}

/* Prefer wide, high-res images for a slot */
function pick(pool, file, { minRatio = 1.2, minPx = 400000, used } = {}) {
  let cands = pool.filter(
    (i) => i.file === file && i.ratio >= minRatio && i.px >= minPx && !used.has(i.url)
  );
  if (cands.length === 0) {
    // relax constraints but keep dedupe
    cands = pool.filter((i) => i.file === file && !used.has(i.url));
  }
  if (cands.length === 0) {
    // last resort: any unused image from anywhere
    cands = pool.filter((i) => !used.has(i.url));
  }
  cands.sort((a, b) => b.px - a.px);
  const chosen = cands[0];
  if (chosen) used.add(chosen.url);
  return chosen ? chosen.url : null;
}

const pool = load();
console.log(`pool size: ${pool.length}`);
const used = new Set();

const slots = {};

/* Hero + big backdrops: prefer wide cinematic */
slots.IMG_HERO_POSTER = pick(pool, "hero", { minRatio: 1.3, minPx: 800000, used });
slots.IMG_UPCOMING_BG = pick(pool, "road", { minRatio: 1.4, minPx: 600000, used }) || pick(pool, "hero", { used });
slots.IMG_JOIN_BG = pick(pool, "sunset", { minRatio: 1.3, minPx: 600000, used }) || pick(pool, "rider", { used });
slots.IMG_ABOUT = pick(pool, "portrait", { minRatio: 1.1, minPx: 500000, used }) || pick(pool, "rider", { used });

/* Ride cards */
slots.IMG_VALLEY = pick(pool, "valley", { minRatio: 1.2, minPx: 400000, used });
slots.IMG_CHOPTA = pick(pool, "chopta", { minRatio: 1.0, minPx: 350000, used });
slots.IMG_WATERFALL = pick(pool, "waterfall", { minRatio: 1.0, minPx: 350000, used });
slots.IMG_SPITI = pick(pool, "spiti", { minRatio: 1.2, minPx: 500000, used });

/* Upcoming cards */
slots.IMG_KEDARNATH = pick(pool, "kedarnath", { minRatio: 1.0, minPx: 350000, used });
slots.IMG_SPITI_2 = pick(pool, "spiti", { minRatio: 1.0, minPx: 350000, used });
slots.IMG_NAINITAL = pick(pool, "nainital", { minRatio: 1.0, minPx: 300000, used });

/* Gallery — mix across everything, 12 images */
const galleryFiles = ["rider", "road", "spiti", "waterfall", "camping", "hero", "sunset", "chopta", "nainital", "rider", "road", "valley"];
for (let g = 0; g < 12; g++) {
  slots[`IMG_G${g + 1}`] = pick(pool, galleryFiles[g], { used });
}

/* Instagram — 8 more */
const igFiles = ["sunset", "portrait", "road", "camping", "hero", "spiti", "valley", "rider"];
for (let g = 0; g < 8; g++) {
  slots[`IMG_IG${g + 1}`] = pick(pool, igFiles[g], { used });
}

/* -------- verify every URL responds 200 (image) -------- */
async function check(url) {
  try {
    const res = await fetch(url, { method: "HEAD" });
    return res.ok;
  } catch {
    return false;
  }
}

(async () => {
  const entries = Object.entries(slots);
  const bad = [];
  // verify with limited concurrency
  const CHUNK = 8;
  for (let i = 0; i < entries.length; i += CHUNK) {
    await Promise.all(
      entries.slice(i, i + CHUNK).map(async ([k, url]) => {
        if (!url) { bad.push([k, null]); return; }
        const ok = await check(url);
        if (!ok) bad.push([k, url]);
      })
    );
  }

  // replace bad slots with unused verified images
  const sparePool = pool.filter((i) => !used.has(i.url));
  const verifiedGood = [];
  for (const [k, url] of bad) {
    let replacement = null;
    while (sparePool.length > 0) {
      const cand = sparePool.shift();
      if (await check(cand.url)) { replacement = cand.url; used.add(cand.url); break; }
    }
    slots[k] = replacement;
    if (!replacement) console.error(`NO REPLACEMENT FOR ${k}`);
  }

  const still = [];
  for (const [k, url] of Object.entries(slots)) {
    if (!url || !(await check(url))) still.push(k);
  }

  if (still.length) {
    console.error("FAILED SLOTS:", still);
    process.exit(1);
  }

  // emit TS file
  const lines = [
    "/**",
    " * BROSONROADS — image slot URLs.",
    " * Generated from verified, reachable sources (each URL HEAD-checked).",
    " * Replace any slot with your own BrosonRoads photography when ready.",
    " */",
    "",
    "export const IMAGES: Record<string, string> = {",
  ];
  for (const [k, url] of Object.entries(slots)) {
    lines.push(`  ${k}: "${url}",`);
  }
  lines.push("};", "");

  fs.writeFileSync(OUT, lines.join("\n"));
  console.log(`WROTE ${OUT} with ${entries.length} verified slots`);
  console.log("used images:", used.size, "| pool:", pool.length);
})();
