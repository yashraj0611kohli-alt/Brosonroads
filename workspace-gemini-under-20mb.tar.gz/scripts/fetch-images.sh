#!/bin/bash
# Fetch destination images for BROSONROADS — stdout captured to files.
cd /home/z/my-project/assets-search

z-ai image-search -q "motorcycle rider riding on a Himalayan mountain road in Uttarakhand India, cinematic landscape" -c 8 --gl us --no-rank > hero.json 2> hero.err &
z-ai image-search -q "Valley of Flowers National Park Uttarakhand Himalayan meadow with wildflowers" -c 5 --gl us --no-rank > valley.json 2> valley.err &
z-ai image-search -q "Tungnath temple Chopta Uttarakhand Himalayan mountains trail" -c 5 --gl us --no-rank > chopta.json 2> chopta.err &
z-ai image-search -q "beautiful waterfall in green forest Uttarakhand Himalayas India" -c 5 --gl us --no-rank > waterfall.json 2> waterfall.err &
z-ai image-search -q "Spiti Valley Himachal Pradesh barren mountain landscape with road" -c 6 --gl us --no-rank > spiti.json 2> spiti.err &
z-ai image-search -q "Kedarnath valley Uttarakhand Himalayan mountains temple" -c 5 --gl us --no-rank > kedarnath.json 2> kedarnath.err &
z-ai image-search -q "Nainital lake Uttarakhand hill station mountains India" -c 4 --gl us --no-rank > nainital.json 2> nainital.err &
z-ai image-search -q "motorcycle adventure rider on high altitude Himalayan mountain pass road India" -c 8 --gl us --no-rank > rider.json 2> rider.err &
z-ai image-search -q "camping tents in Himalayan mountains at dusk" -c 4 --gl us --no-rank > camping.json 2> camping.err &
z-ai image-search -q "motorcycle on mountain road at golden sunset Himalayas" -c 5 --gl us --no-rank > sunset.json 2> sunset.err &
z-ai image-search -q "winding mountain road through green Himalayan valley Uttarakhand" -c 6 --gl us --no-rank > road.json 2> road.err &
z-ai image-search -q "motorcyclist standing next to motorcycle with Himalayan mountains background" -c 5 --gl us --no-rank > portrait.json 2> portrait.err &

wait
echo "ALL IMAGE SEARCHES DONE"
wc -c *.json
