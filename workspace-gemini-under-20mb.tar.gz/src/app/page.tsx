import { Header } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { FeaturedRides } from "@/components/site/rides";
import { UpcomingRides } from "@/components/site/upcoming";
import { About } from "@/components/site/about";
import { Gallery } from "@/components/site/gallery";
import { YouTubeSection, InstagramSection } from "@/components/site/social";
import { JoinUs } from "@/components/site/join";
import { Footer } from "@/components/site/footer";
import { RidePopup } from "@/components/site/ride-popup";
import { BROSONROADS } from "@/lib/site";

/**
 * BROSONROADS — cinematic motorcycle touring & travel publication.
 * Single-page editorial site assembled from reusable components;
 * all content is data-driven via src/lib/site.ts and src/lib/data.ts.
 */

const structuredData = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: BROSONROADS.name,
  alternateName: "BrosOnRoads",
  url: BROSONROADS.siteUrl,
  description:
    "Motorcycle touring and adventure travel brand documenting journeys through Uttarakhand, Himachal Pradesh and the Himalayas.",
  slogan: BROSONROADS.tagline,
  sameAs: [BROSONROADS.social.youtube, BROSONROADS.social.instagram],
};

export default function Home() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <Header />

      <main className="flex-1">
        <Hero />
        <FeaturedRides />
        <UpcomingRides />
        <About />
        <Gallery />
        <YouTubeSection />
        <InstagramSection />
        <JoinUs />
      </main>

      <Footer />

      {/* 20-second "ride with us" popup — call / text / email */}
      <RidePopup />
    </>
  );
}
