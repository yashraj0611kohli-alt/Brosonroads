/**
 * ============================================================
 *  BROSONROADS — CENTRAL SITE CONFIGURATION
 * ============================================================
 *  Everything brand-related lives here. Update social links,
 *  hero video and channel info in ONE place — no layout edits.
 * ============================================================
 */

export const BROSONROADS = {
  name: "BROSONROADS",
  /** Display name split for editorial typography (used in places like the footer) */
  wordmark: "BROSONROADS",
  tagline: "Two wheels. Endless roads. Real experiences.",
  description:
    "We ride beyond the usual routes, chasing mountain roads, hidden places, changing weather and the stories that only happen when you travel on two wheels.",

  /**
   * SOCIAL LINKS — change these once, they update across the whole site.
   * Official handles: YouTube @bros_on_roads · Instagram @bros_on_roads
   */
  social: {
    youtube: "https://youtube.com/@bros_on_roads?si=hl5cgYvfhLmsXoJa",
    youtubeHandle: "@bros_on_roads",
    instagram: "https://www.instagram.com/bros_on_roads/",
    instagramHandle: "@bros_on_roads",
  },

  /**
   * CONTACT — used by the Join section and the 20-second ride popup.
   * People to call / text, plus the shared inbox.
   */
  contactEmail: "yashraj0611kohli@gmail.com",

  /**
   * HERO VIDEO — self-hosted film that plays as the hero background
   * (muted, looped) and inside the cinematic "Watch Our Journey" modal
   * (with sound + controls).
   *
   * ▶ TO SWAP: replace the files at public/videos/hero.mp4 and
   *   public/videos/hero-poster.jpg (a still frame of the new video,
   *   shown instantly while it loads and as the offline fallback).
   *   Keep the same file names — no code changes needed.
   *
   * Current film: BrosonRoads ride montage (1920×1080 · 12.7s loop),
   * H.264 MP4 with faststart for instant streaming.
   */
  heroVideoUrl: "/videos/hero.mp4",
  heroVideoPoster: "/videos/hero-poster.jpg",

  /**
   * Canonical URL placeholder — set to the production domain when live.
   */
  siteUrl: "https://brosonroads.vercel.app",
} as const;

/**
 * HEADER / FOOTER NAVIGATION
 * hrefs are in-page section ids — smooth scrolled by the browser.
 */
export const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "Rides", href: "#rides" },
  { label: "Upcoming", href: "#upcoming" },
  { label: "About", href: "#about" },
  { label: "Gallery", href: "#gallery" },
  { label: "Join Us", href: "#join" },
] as const;

/**
 * RIDE INQUIRY CONTACTS — people you can call or text to join a ride,
 * plus the shared email for queries and notifications.
 * `tel` is used for Call, `sms` for Text, both dialled as-is.
 */
export interface RideContact {
  name: string;
  role: string;
  /** Display format, e.g. "+91 99115 61887" */
  phone: string;
  /** Dialable format, e.g. "+919911561887" */
  dial: string;
  email?: string;
}

export const RIDE_CONTACTS: RideContact[] = [
  {
    name: "Yashraj Kohli",
    role: "Ride Lead · Founder",
    phone: "+91 99115 61887",
    dial: "+919911561887",
    email: "yashraj0611kohli@gmail.com",
  },
  {
    name: "Akshay Rana",
    role: "Ride Captain",
    phone: "+91 84494 16642",
    dial: "+918449416642",
  },
];
