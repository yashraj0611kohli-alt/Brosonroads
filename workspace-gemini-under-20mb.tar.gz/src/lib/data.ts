/**
 * ============================================================
 *  BROSONROADS — CONTENT DATA
 * ============================================================
 *  All rides, upcoming rides, gallery images, videos and social
 *  cards are plain data objects. Edit this file to update the
 *  site — the layout never needs to change.
 *
 *  IMAGE NOTE: destination photography is stock imagery used as
 *  a visual representation of each destination. Replace any URL
 *  with actual BrosonRoads photographs whenever available.
 * ============================================================
 */

import { BROSONROADS } from "./site";
import { IMAGES } from "./images";

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */

export interface Ride {
  id: string;
  title: string;
  location: string;
  date: string;
  distance: string;
  days: string;
  image: string;
  alt: string;
  excerpt: string;
  description: string;
  highlights: string[];
}

export interface UpcomingRide {
  id: string;
  title: string;
  location: string;
  dates: string;
  distance: string;
  duration: string;
  image: string;
  alt: string;
  excerpt: string;
  route: string[];
}

export interface GalleryImage {
  src: string;
  alt: string;
  caption: string;
  category: string;
}

export interface VideoItem {
  id: string; // "" → renders as an "Open channel" card instead of an embed
  title: string;
  location: string;
  description: string;
  publishedAt?: string;
}

/* ------------------------------------------------------------------ */
/*  FEATURED RIDES                                                     */
/* ------------------------------------------------------------------ */

export const RIDES: Ride[] = [
  {
    id: "valley-of-flowers",
    title: "Valley of Flowers Ride",
    location: "Uttarakhand",
    date: "Jun 2024",
    distance: "320 KM",
    days: "4 Days",
    image: IMAGES.IMG_VALLEY,
    alt: "Blossoming Himalayan meadow in Valley of Flowers National Park, Uttarakhand",
    excerpt: "A monsoon ride into UNESCO's blooming high-altitude valley.",
    description:
      "The Valley of Flowers is one of those rides where the road feels like a warm-up act. We pushed through winding Himalayan roads, monsoon-washed ghat sections and river valleys before the trail opened into meadows that don't look real — hundreds of species of wildflowers framed by snow-dusted peaks. This ride is a reminder that Uttarakhand saves its best colours for the people willing to ride further.",
    highlights: [
      "Rishikesh to Joshimath along the Alaknanda river",
      "UNESCO World Heritage valley trek",
      "Monsoon waterfalls around every bend",
      "High-altitude meadows above 3,600 m",
    ],
  },
  {
    id: "chopta-tungnath",
    title: "Chopta – Tungnath – Chandrashila",
    location: "Uttarakhand",
    date: "May 2024",
    distance: "280 KM",
    days: "3 Days",
    image: IMAGES.IMG_CHOPTA,
    alt: "Tungnath temple trail above Chopta with Himalayan peaks, Uttarakhand",
    excerpt: "The highest Shiva temple on earth, reached on two wheels.",
    description:
      "Chopta, the 'Mini Switzerland' of Uttarakhand, is where this ride drops you into pure mountain silence. From the roadhead we climbed to Tungnath — the highest Shiva temple in the world — and then on to Chandrashila summit for a 360° panorama of Nanda Devi, Trishul and Chaukhamba. Short distance, massive reward. One of the most complete weekends you can have on a motorcycle in the Himalayas.",
    highlights: [
      "Sunrise views from Chandrashila summit",
      "World's highest Shiva temple at 3,680 m",
      "Dense deodar forests of the Mandakini valley",
      "Meadow campsites under clear Himalayan skies",
    ],
  },
  {
    id: "hidden-waterfalls",
    title: "Hidden Waterfalls Ride",
    location: "Uttarakhand",
    date: "Aug 2024",
    distance: "210 KM",
    days: "3 Days",
    image: IMAGES.IMG_WATERFALL,
    alt: "Monsoon waterfall falling through green forest in Uttarakhand, India",
    excerpt: "Chasing monsoon waterfalls through Kumaon's green tunnels.",
    description:
      "August in Uttarakhand means one thing — water. We rode the monsoon-soaked backroads of the Kedarnath valley and beyond, hunting falls that don't appear on any map: curtain falls beside iron bridges, roadside cascades you can hear before you see, and jungle streams crossing the tarmac itself. The shortest ride we've documented, and somehow one of the richest.",
    highlights: [
      "Backroad ghat sections through rainforest",
      "Roadside falls you can ride right up to",
      "Rain, mist and mountain light for days",
      "Village chai stops in the middle of nowhere",
    ],
  },
  {
    id: "spiti-expedition",
    title: "Spiti Valley Expedition",
    location: "Himachal",
    date: "Jul 2024",
    distance: "1,200 KM",
    days: "7 Days",
    image: IMAGES.IMG_SPITI,
    alt: "Barren high-altitude mountain landscape of Spiti Valley, Himachal Pradesh",
    excerpt: "A week in cold desert country — the ultimate Himalayan ride.",
    description:
      "Spiti is not a ride, it's an expedition. Over 1,200 kilometres we crossed the Kunzum La, rode alongside the Spiti river, and slept in some of the highest inhabited villages on the planet. Moonlike landscapes, ancient monasteries hanging over cliffs, and roads that demand everything from you and the machine. The benchmark every future ride will be measured against.",
    highlights: [
      "Kunzum La pass at 4,551 m",
      "Key Monastery and Dhankar cliffs",
      "Camping beside Chandratal lake",
      "Some of the highest motorable villages on earth",
    ],
  },
];

/* ------------------------------------------------------------------ */
/*  UPCOMING RIDES                                                     */
/* ------------------------------------------------------------------ */

export const UPCOMING_RIDES: UpcomingRide[] = [
  {
    id: "kedarnath-valley",
    title: "Kedarnath Valley Ride",
    location: "Uttarakhand",
    dates: "Oct 12–16, 2025",
    distance: "450 KM",
    duration: "4 Days",
    image: IMAGES.IMG_KEDARNATH,
    alt: "Kedarnath valley surrounded by snow-capped Himalayan peaks, Uttarakhand",
    excerpt:
      "Deep into the Mandakini valley — temple towns, river roads and autumn light across the Garhwal Himalaya.",
    route: [
      "Rishikesh → Rudraprayag → Agastyamuni",
      "Mandakini river gorge roads",
      "Ukhimath & Chopta side-loop",
      "Autumn ridgeline views of Kedarnath range",
    ],
  },
  {
    id: "spiti-ultimate",
    title: "Spiti Valley – The Ultimate Ride",
    location: "Himachal",
    dates: "Nov 08–12, 2025",
    distance: "1,200 KM",
    duration: "5 Days",
    image: IMAGES.IMG_SPITI_2,
    alt: "High altitude road winding through the cold desert of Spiti Valley, Himachal",
    excerpt:
      "The full cold-desert crossing — high passes, ancient monasteries and the emptiest, highest roads in India.",
    route: [
      "Shimla → Kinnaur → Nako climb",
      "Tabo & Dhankar monastery circuits",
      "Kaza → Key → Kibber high villages",
      "Kunzum La crossing (weather permitting)",
    ],
  },
  {
    id: "nainital-mukteshwar",
    title: "Nainital – Mukteshwar Ride",
    location: "Uttarakhand",
    dates: "Dec 05–09, 2025",
    distance: "350 KM",
    duration: "4 Days",
    image: IMAGES.IMG_NAINITAL,
    alt: "Nainital lake nestled in Kumaon hills, Uttarakhand, India",
    excerpt:
      "A winter Kumaon classic — lakes, orchards and pine ridgelines with first-snow chances at the top.",
    route: [
      "Kathgodam climb to Nainital lake",
      "Bhimtal, Sattal & Naukuchiatal lake loop",
      "Mukteshwar orchard roads at 2,286 m",
      "Winter sunrise over Nanda Devi",
    ],
  },
];

/* ------------------------------------------------------------------ */
/*  YOUTUBE VIDEOS — official @bros_on_roads embeds only               */
/*  Add new videos by pasting their 11-character YouTube ID below.     */
/* ------------------------------------------------------------------ */

export const VIDEOS: VideoItem[] = [
  {
    id: "bFYuyV7l8Uc",
    title: "Bike Travel Vlog India — 20,000 KM Journey",
    location: "Feature Film",
    description:
      "20,000 kilometres across India on two wheels — the full Bros On Roads journey, packed into one film.",
  },
  {
    id: "aef_zNnnDw8",
    title: "Men On Their Way",
    location: "YouTube Short",
    description:
      "Raw monsoon trails, misty peaks and two brothers chasing the kind of peace that only exists up in the mountains.",
  },
  {
    id: "4SzYD8Cptvg",
    title: "River Rafting Ka Sabse Crazy Experience",
    location: "Rishikesh",
    description:
      "Off the bikes and into the rapids — the whole crew takes on Rishikesh river rafting and it goes exactly as crazy as you'd expect.",
  },
  // ▶ ADD MORE BROS ON ROADS VIDEOS HERE, e.g.:
  // {
  //   id: "PASTE_YOUTUBE_VIDEO_ID",
  //   title: "Spiti Valley — The Ultimate Ride",
  //   location: "Himachal",
  //   description: "Full expedition film.",
  // },
];

/* ------------------------------------------------------------------ */
/*  GALLERY                                                            */
/* ------------------------------------------------------------------ */

export const GALLERY_IMAGES: GalleryImage[] = [
  { src: IMAGES.IMG_G1, alt: "Motorcyclist riding a Himalayan mountain road in Uttarakhand", caption: "Morning light on the climb", category: "Uttarakhand" },
  { src: IMAGES.IMG_G2, alt: "Winding mountain road cutting through a green Himalayan valley", caption: "The road knows the way", category: "Himalayan Roads" },
  { src: IMAGES.IMG_G3, alt: "Barren high-altitude landscape of Spiti Valley, Himachal Pradesh", caption: "Cold desert country", category: "Spiti" },
  { src: IMAGES.IMG_G4, alt: "Waterfall crashing through monsoon forest in the Himalayas", caption: "Monsoon overflow", category: "Waterfalls" },
  { src: IMAGES.IMG_G5, alt: "Camping tents glowing at dusk in the Himalayan mountains", caption: "Home for the night", category: "Camps" },
  { src: IMAGES.IMG_G6, alt: "Riders resting beside motorcycles high in the mountains", caption: "Brothers of the road", category: "Riders" },
  { src: IMAGES.IMG_G7, alt: "Sunset over a mountain pass with a lone motorcycle", caption: "Golden hour on the pass", category: "Sunset Rides" },
  { src: IMAGES.IMG_G8, alt: "Temple trail above Chopta with snow peaks behind, Uttarakhand", caption: "Steps to Tungnath", category: "Uttarakhand" },
  { src: IMAGES.IMG_G9, alt: "Nainital lake surrounded by Kumaon hills after rain", caption: "Lake country", category: "Uttarakhand" },
  { src: IMAGES.IMG_G10, alt: "Motorcycle parked on a mountain road with valley view", caption: "Somewhere past the map", category: "Riders" },
  { src: IMAGES.IMG_G11, alt: "High Himalayan pass road with prayer flags", caption: "Above the treeline", category: "Mountain Passes" },
  { src: IMAGES.IMG_G12, alt: "River running through a green valley in Himachal Pradesh", caption: "Glacier water roads", category: "Himachal" },
];

/* ------------------------------------------------------------------ */
/*  INSTAGRAM CARDS                                                    */
/*  Static curated cards linking to the profile. To embed real IG      */
/*  posts later, set `permalink` to the post URL and swap in the       */
/*  official Instagram embed block.                                    */
/* ------------------------------------------------------------------ */

export interface InstagramCard {
  src: string;
  alt: string;
  permalink?: string;
}

export const INSTAGRAM_POSTS: InstagramCard[] = [
  { src: IMAGES.IMG_IG1, alt: "Motorcycle on a Himalayan road at sunrise", permalink: BROSONROADS.social.instagram },
  { src: IMAGES.IMG_IG2, alt: "Rider silhouette against mountain peaks", permalink: BROSONROADS.social.instagram },
  { src: IMAGES.IMG_IG3, alt: "Mountain switchbacks in Uttarakhand", permalink: BROSONROADS.social.instagram },
  { src: IMAGES.IMG_IG4, alt: "Campfire in the Himalayas at night", permalink: BROSONROADS.social.instagram },
  { src: IMAGES.IMG_IG5, alt: "Motorcycle crossing a mountain river", permalink: BROSONROADS.social.instagram },
  { src: IMAGES.IMG_IG6, alt: "Clouds rolling over Himachal valleys", permalink: BROSONROADS.social.instagram },
  { src: IMAGES.IMG_IG7, alt: "Rider gear detail on a mountain road", permalink: BROSONROADS.social.instagram },
  { src: IMAGES.IMG_IG8, alt: "Sunset ridge road in Kumaon", permalink: BROSONROADS.social.instagram },
];

/* ------------------------------------------------------------------ */
/*  SECTION MEDIA (hero / about / upcoming backgrounds)                */
/* ------------------------------------------------------------------ */

export const SECTION_MEDIA = {
  heroPoster: IMAGES.IMG_HERO_POSTER,
  about: IMAGES.IMG_ABOUT,
  upcomingBg: IMAGES.IMG_UPCOMING_BG,
  joinBg: IMAGES.IMG_JOIN_BG,
  ridePopup: IMAGES.IMG_POPUP_RIDE,
};
