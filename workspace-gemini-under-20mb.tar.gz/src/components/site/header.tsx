"use client";

import { useEffect, useState, useCallback } from "react";
import { Menu, X, Youtube, Instagram } from "lucide-react";
import { BROSONROADS, NAV_LINKS } from "@/lib/site";

/**
 * Sticky header — transparent over the hero, solidifies on scroll.
 * Mobile hamburger opens a full-screen menu (real open/close,
 * body scroll lock, ESC to close, link click closes).
 */
export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* Track which section is in view for the active nav state */
  useEffect(() => {
    const ids = NAV_LINKS.map((l) => l.href.replace("#", ""));
    const sections = ids
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));
    if (sections.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 }
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  /* Lock body scroll while the mobile menu is open */
  useEffect(() => {
    if (!menuOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);

  const closeMenu = useCallback(() => setMenuOpen(false), []);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
          scrolled || menuOpen
            ? "bg-[#0B0B0B]/90 backdrop-blur-md border-b border-white/10"
            : "bg-transparent border-b border-transparent"
        }`}
      >
        <div className="mx-auto flex h-16 md:h-20 max-w-[1600px] items-center justify-between px-5 md:px-10">
          {/* Wordmark */}
          <a
            href="#home"
            onClick={closeMenu}
            className="group flex items-baseline gap-1.5"
            aria-label="BrosonRoads — home"
          >
            <span
              className={`display-title text-lg md:text-xl font-bold tracking-[-0.02em] transition-colors duration-300 ${
                menuOpen ? "text-white" : "text-white"
              }`}
            >
              BROS<span className="text-[#D97F3E]">ON</span>ROADS
            </span>
          </a>

          {/* Desktop nav */}
          <nav aria-label="Primary" className="hidden lg:flex items-center gap-8">
            {NAV_LINKS.map((link) => {
              const id = link.href.replace("#", "");
              return (
                <a
                  key={link.href}
                  href={link.href}
                  className={`group relative text-[11px] font-medium uppercase tracking-[0.22em] transition-colors duration-300 ${
                    active === id ? "text-white" : "text-[#929292] hover:text-white"
                  }`}
                >
                  {link.label}
                  <span
                    className={`absolute -bottom-1.5 left-0 h-px bg-[#D97F3E] transition-all duration-300 ${
                      active === id ? "w-full" : "w-0 group-hover:w-full"
                    }`}
                  />
                </a>
              );
            })}
          </nav>

          {/* Right cluster */}
          <div className="hidden lg:flex items-center gap-5">
            <div className="flex items-center gap-1">
              <a
                href={BROSONROADS.social.youtube}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="BrosonRoads on YouTube"
                className="flex h-9 w-9 items-center justify-center text-[#929292] transition-colors duration-300 hover:text-white"
              >
                <Youtube className="h-[18px] w-[18px]" strokeWidth={1.5} />
              </a>
              <a
                href={BROSONROADS.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="BrosonRoads on Instagram"
                className="flex h-9 w-9 items-center justify-center text-[#929292] transition-colors duration-300 hover:text-white"
              >
                <Instagram className="h-[18px] w-[18px]" strokeWidth={1.5} />
              </a>
            </div>
            <a
              href={BROSONROADS.social.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="border border-white/25 px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.2em] text-white transition-all duration-300 hover:bg-white hover:text-black hover:border-white"
            >
              Subscribe
            </a>
          </div>

          {/* Mobile hamburger */}
          <button
            className="lg:hidden relative z-[60] flex h-11 w-11 items-center justify-center text-white"
            onClick={() => setMenuOpen((v) => !v)}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
          >
            {menuOpen ? <X className="h-6 w-6" strokeWidth={1.5} /> : <Menu className="h-6 w-6" strokeWidth={1.5} />}
          </button>
        </div>
      </header>

      {/* Mobile full-screen menu */}
      {menuOpen && (
        <div
          id="mobile-menu"
          className="mobile-menu-panel fixed inset-0 z-40 flex flex-col bg-[#0B0B0B]/98 backdrop-blur-xl lg:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation"
        >
          <div className="flex h-full flex-col justify-between px-6 pb-10 pt-24">
            <nav aria-label="Mobile" className="flex flex-col gap-1">
              {NAV_LINKS.map((link, i) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={closeMenu}
                  className="mobile-menu-item group flex items-center justify-between border-b border-white/10 py-4"
                  style={{ animationDelay: `${60 + i * 55}ms` }}
                >
                  <span className="display-title text-3xl font-bold uppercase text-white transition-colors group-hover:text-[#D97F3E]">
                    {link.label}
                  </span>
                  <span className="text-[10px] tracking-[0.3em] text-[#929292]">
                    0{i + 1}
                  </span>
                </a>
              ))}
            </nav>

            <div
              className="mobile-menu-item flex flex-col gap-6"
              style={{ animationDelay: "420ms" }}
            >
              <a
                href={BROSONROADS.social.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 bg-white px-6 py-4 text-[12px] font-semibold uppercase tracking-[0.22em] text-black"
              >
                <Youtube className="h-4 w-4" strokeWidth={1.75} /> Subscribe on YouTube
              </a>
              <div className="flex items-center justify-center gap-8">
                <a
                  href={BROSONROADS.social.youtube}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="BrosonRoads on YouTube"
                  className="flex items-center gap-2 text-[#929292]"
                >
                  <Youtube className="h-5 w-5" strokeWidth={1.5} />
                  <span className="text-xs tracking-[0.15em]">{BROSONROADS.social.youtubeHandle}</span>
                </a>
                <a
                  href={BROSONROADS.social.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="BrosonRoads on Instagram"
                  className="flex items-center gap-2 text-[#929292]"
                >
                  <Instagram className="h-5 w-5" strokeWidth={1.5} />
                  <span className="text-xs tracking-[0.15em]">{BROSONROADS.social.instagramHandle}</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
