"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { GALLERY_IMAGES } from "@/lib/data";
import { Reveal } from "./reveal";
import { SafeImage } from "./safe-image";

/**
 * Immersive editorial gallery.
 * - Masonry-style grid (CSS columns)
 * - Full-screen lightbox: next/prev, arrow keys, ESC, touch swipe,
 *   backdrop + button close, counter & captions.
 */
export function Gallery() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const touchStartX = useRef<number | null>(null);

  const openLightbox = useCallback((index: number) => setLightboxIndex(index), []);
  const closeLightbox = useCallback(() => setLightboxIndex(null), []);

  const showPrev = useCallback(() => {
    setLightboxIndex((cur) =>
      cur === null ? cur : (cur - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length
    );
  }, []);

  const showNext = useCallback(() => {
    setLightboxIndex((cur) =>
      cur === null ? cur : (cur + 1) % GALLERY_IMAGES.length
    );
  }, []);

  /* Keyboard navigation + scroll lock while the lightbox is open */
  useEffect(() => {
    if (lightboxIndex === null) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowLeft") showPrev();
      if (e.key === "ArrowRight") showNext();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener("keydown", onKey);
    };
  }, [lightboxIndex, closeLightbox, showPrev, showNext]);

  const current = lightboxIndex === null ? null : GALLERY_IMAGES[lightboxIndex];

  return (
    <section id="gallery" aria-labelledby="gallery-heading" className="scroll-mt-20 bg-[#0B0B0B] py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
        {/* Header */}
        <div className="mb-14 flex flex-col gap-6 md:mb-20 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <p className="eyebrow mb-4">04 — Gallery</p>
            <h2 id="gallery-heading" className="display-title text-4xl font-bold text-white sm:text-5xl md:text-6xl">
              Frames From<br />
              <span className="text-outline">The Road</span>
            </h2>
          </Reveal>
          <Reveal delay={120}>
            <p className="max-w-xs text-sm leading-relaxed text-[#929292] md:text-right">
              Moments collected between Ukhimath and Kaza — tap any frame to view it full screen.
            </p>
          </Reveal>
        </div>

        {/* Masonry grid */}
        <div className="columns-2 gap-3 [column-fill:_balance] md:columns-3 md:gap-4 xl:columns-4">
          {GALLERY_IMAGES.map((img, i) => (
            <Reveal
              key={img.src}
              as="figure"
              variant="image"
              delay={(i % 4) * 70}
              className="group relative mb-3 break-inside-avoid overflow-hidden bg-[#151515] md:mb-4"
            >
              <button
                onClick={() => openLightbox(i)}
                className="block w-full cursor-pointer"
                aria-label={`Open photo: ${img.caption}`}
              >
                <div
                  className={`relative w-full overflow-hidden ${
                    i % 5 === 0 ? "aspect-[3/4]" : i % 5 === 1 ? "aspect-square" : i % 5 === 2 ? "aspect-[4/5]" : i % 5 === 3 ? "aspect-[3/4]" : "aspect-[4/3]"
                  }`}
                >
                  <SafeImage
                    src={img.src}
                    alt={img.alt}
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1100ms] ease-out group-hover:scale-[1.07]"
                    draggable={false}
                  />
                  <div
                    className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                    aria-hidden="true"
                  />
                  <figcaption className="absolute inset-x-0 bottom-0 translate-y-2 p-4 text-left opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                    <p className="text-[10px] uppercase tracking-[0.25em] text-[#D97F3E]">{img.category}</p>
                    <p className="mt-1 text-sm font-medium text-white">{img.caption}</p>
                  </figcaption>
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      {/* Full-screen lightbox */}
      {current && (
        <div
          className="modal-backdrop fixed inset-0 z-[95] flex flex-col bg-black/95 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label={`Photo ${lightboxIndex! + 1} of ${GALLERY_IMAGES.length}: ${current.caption}`}
          onClick={closeLightbox}
          onTouchStart={(e) => {
            touchStartX.current = e.touches[0].clientX;
          }}
          onTouchEnd={(e) => {
            if (touchStartX.current === null) return;
            const dx = e.changedTouches[0].clientX - touchStartX.current;
            if (dx > 60) showPrev();
            if (dx < -60) showNext();
            touchStartX.current = null;
          }}
        >
          {/* Top bar */}
          <div className="flex items-center justify-between px-5 py-4 sm:px-8">
            <p className="font-mono text-xs tracking-[0.25em] text-[#929292]">
              {String(lightboxIndex! + 1).padStart(2, "0")}&ensp;/&ensp;{String(GALLERY_IMAGES.length).padStart(2, "0")}
            </p>
            <button
              onClick={closeLightbox}
              aria-label="Close gallery"
              className="flex h-11 w-11 items-center justify-center border border-white/25 text-white transition-colors duration-300 hover:bg-white hover:text-black"
            >
              <X className="h-5 w-5" strokeWidth={1.5} />
            </button>
          </div>

          {/* Image area */}
          <div className="relative flex flex-1 items-center justify-center px-14 pb-4 sm:px-20">
            <div
              key={current.src}
              className="lightbox-img relative max-h-full max-w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <SafeImage
                src={current.src}
                alt={current.alt}
                priority
                className="max-h-[74vh] w-auto max-w-full object-contain"
                draggable={false}
              />
            </div>

            {/* Prev / Next */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                showPrev();
              }}
              aria-label="Previous photo"
              className="absolute left-3 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center border border-white/20 bg-black/40 text-white transition-colors duration-300 hover:bg-white hover:text-black sm:left-6"
            >
              <ChevronLeft className="h-5 w-5" strokeWidth={1.5} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                showNext();
              }}
              aria-label="Next photo"
              className="absolute right-3 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center border border-white/20 bg-black/40 text-white transition-colors duration-300 hover:bg-white hover:text-black sm:right-6"
            >
              <ChevronRight className="h-5 w-5" strokeWidth={1.5} />
            </button>
          </div>

          {/* Caption */}
          <div className="px-5 pb-6 text-center sm:px-8" onClick={(e) => e.stopPropagation()}>
            <p className="text-[10px] uppercase tracking-[0.3em] text-[#D97F3E]">{current.category}</p>
            <p className="mt-1.5 text-sm text-[#D7D7D7]">{current.caption}</p>
          </div>
        </div>
      )}
    </section>
  );
}
