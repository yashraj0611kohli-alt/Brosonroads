"use client";

import { useState } from "react";
import { ArrowUpRight, Calendar, Route } from "lucide-react";
import { RIDES, type Ride } from "@/lib/data";
import { Reveal } from "./reveal";
import { SafeImage } from "./safe-image";
import { RideDetailModal, type RideDetailData } from "./ride-detail-modal";

function rideToDetail(ride: Ride): RideDetailData {
  return {
    title: ride.title,
    location: ride.location,
    image: ride.image,
    alt: ride.alt,
    description: ride.description,
    bullets: { heading: "Ride highlights", items: ride.highlights },
    stats: [
      { label: "Distance", value: ride.distance },
      { label: "Days", value: ride.days },
      { label: "Date", value: ride.date },
    ],
  };
}

/**
 * "Some Journeys Never End" — premium four-card editorial grid.
 * Asymmetric spans, hover zoom + reveal, each card opens a detail view.
 */
export function FeaturedRides() {
  const [detail, setDetail] = useState<RideDetailData | null>(null);

  /* asymmetric editorial spans */
  const spans = ["md:col-span-7", "md:col-span-5", "md:col-span-5", "md:col-span-7"];
  const heights = ["h-[380px] md:h-[460px]", "h-[380px] md:h-[560px]", "h-[380px] md:h-[560px]", "h-[380px] md:h-[460px]"];

  return (
    <section id="rides" aria-labelledby="rides-heading" className="scroll-mt-20 bg-[#F5F4F0] py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
        {/* Section header */}
        <div className="mb-14 flex flex-col gap-6 md:mb-20 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <p className="eyebrow eyebrow-dark mb-4">01 — Featured Rides</p>
            <h2 id="rides-heading" className="display-title max-w-2xl text-4xl font-bold text-[#111111] sm:text-5xl md:text-6xl">
              Some Journeys<br />
              <span className="text-outline-dark">Never End</span>
            </h2>
          </Reveal>
          <Reveal delay={120}>
            <p className="max-w-xs text-sm leading-relaxed text-[#6E6C66] md:text-right">
              Every road leaves a story.
            </p>
          </Reveal>
        </div>

        {/* Editorial grid */}
        <div className="grid grid-cols-1 gap-5 md:grid-cols-12 md:gap-6">
          {RIDES.map((ride, i) => (
            <Reveal
              key={ride.id}
              as="article"
              variant="image"
              delay={(i % 2) * 90}
              className={`group relative col-span-1 ${spans[i]} ${heights[i]} cursor-pointer overflow-hidden bg-[#E8E6E1]`}
            >
              <button
                onClick={() => setDetail(rideToDetail(ride))}
                className="block h-full w-full text-left"
                aria-label={`Open details for ${ride.title}`}
              >
                <SafeImage
                  src={ride.image}
                  alt={ride.alt}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-[1.06]"
                  draggable={false}
                />
                <div
                  className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-black/10 transition-opacity duration-500 group-hover:opacity-90"
                  aria-hidden="true"
                />

                {/* Top meta row */}
                <div className="absolute inset-x-0 top-0 flex items-start justify-between p-5 md:p-7">
                  <p className="text-[10px] font-medium uppercase tracking-[0.28em] text-[#D7D7D7]">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                  <span className="flex h-11 w-11 translate-y-1 items-center justify-center border border-white/30 bg-black/30 text-white opacity-0 backdrop-blur-sm transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                    <ArrowUpRight className="h-4 w-4" strokeWidth={1.5} />
                  </span>
                </div>

                {/* Bottom content */}
                <div className="absolute inset-x-0 bottom-0 p-5 md:p-7">
                  <p className="eyebrow mb-2.5">{ride.location}</p>
                  <h3 className="display-title text-xl font-bold text-white sm:text-2xl md:text-[1.7rem]">
                    {ride.title}
                  </h3>
                  <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-1.5 text-[10px] uppercase tracking-[0.2em] text-[#929292] md:text-[11px]">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="h-3 w-3" strokeWidth={1.5} />
                      {ride.date}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Route className="h-3 w-3" strokeWidth={1.5} />
                      {ride.distance}
                    </span>
                  </div>
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      <RideDetailModal
        open={detail !== null}
        onClose={() => setDetail(null)}
        ride={detail}
      />
    </section>
  );
}
