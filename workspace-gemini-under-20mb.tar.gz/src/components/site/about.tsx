"use client";

import { SECTION_MEDIA } from "@/lib/data";
import { Reveal } from "./reveal";
import { SafeImage } from "./safe-image";

/**
 * "More Than Just Rides" — split-screen editorial layout:
 * sticky image on one side, narrative copy on the other.
 */
export function About() {
  return (
    <section id="about" aria-labelledby="about-heading" className="scroll-mt-20 bg-[#F5F4F0] py-24 md:py-36">
      <div className="mx-auto grid max-w-[1600px] grid-cols-1 gap-12 px-5 sm:px-8 md:px-10 lg:grid-cols-2 lg:gap-16">
        {/* Image — cinematic reveal */}
        <Reveal variant="image" className="relative order-2 min-h-[420px] overflow-hidden bg-[#E8E6E1] lg:order-1 lg:min-h-[640px]">
          <SafeImage
            src={SECTION_MEDIA.about}
            alt="Motorcyclist on a Himalayan mountain road with peaks stretching into the distance"
            className="absolute inset-0 h-full w-full object-cover"
            draggable={false}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B]/70 via-transparent to-black/20" />
          <div className="absolute bottom-0 left-0 flex items-center gap-3 p-6">
            <span className="h-1.5 w-1.5 rounded-full bg-[#D97F3E]" aria-hidden="true" />
            <p className="text-[10px] uppercase tracking-[0.28em] text-[#D7D7D7]">
              Somewhere in Garhwal — 6:12 AM
            </p>
          </div>
        </Reveal>

        {/* Copy */}
        <div className="order-1 flex flex-col justify-center lg:order-2 lg:py-10">
          <Reveal>
            <p className="eyebrow eyebrow-dark mb-4">03 — About</p>
            <h2 id="about-heading" className="display-title text-4xl font-bold text-[#111111] sm:text-5xl md:text-6xl">
              More Than<br />
              <span className="text-outline-dark">Just Rides</span>
            </h2>
            <p className="mt-7 text-lg font-medium text-[#3D3B36] md:text-xl">
              BrosonRoads is about the places between the destinations.
            </p>
          </Reveal>

          <Reveal delay={130}>
            <div className="mt-7 space-y-1.5">
              <p className="text-[15px] leading-relaxed text-[#6E6C66]">The mountain roads.</p>
              <p className="text-[15px] leading-relaxed text-[#6E6C66]">The early starts.</p>
              <p className="text-[15px] leading-relaxed text-[#6E6C66]">The unexpected weather.</p>
              <p className="text-[15px] leading-relaxed text-[#6E6C66]">The roadside conversations.</p>
              <p className="text-[15px] leading-relaxed text-[#6E6C66]">The broken plans.</p>
              <p className="text-[15px] leading-relaxed text-[#6E6C66]">
                The views you only find when you take the longer route.
              </p>
            </div>
          </Reveal>

          <Reveal delay={220}>
            <p className="mt-8 max-w-lg border-l-2 border-[#D97F3E] pl-5 text-[15px] leading-relaxed text-[#3D3B36]">
              We document motorcycle journeys through the Himalayas and beyond —
              sharing the roads, destinations, experiences and stories that make
              every ride worth remembering.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
