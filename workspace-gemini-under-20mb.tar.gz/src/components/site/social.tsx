"use client";

import { useState } from "react";
import { Instagram, Youtube, ArrowUpRight, Play, Users } from "lucide-react";
import { BROSONROADS } from "@/lib/site";
import { INSTAGRAM_POSTS, VIDEOS, type VideoItem } from "@/lib/data";
import { Reveal } from "./reveal";
import { SafeImage } from "./safe-image";
import { VideoModal } from "./video-modal";

/* ------------------------------------------------------------------ */
/*  YOUTUBE SECTION — official embeds of the real BrosonRoads channel  */
/* ------------------------------------------------------------------ */

function YouTubeThumb({ videoId, alt }: { videoId: string; alt: string }) {
  return (
    <SafeImage
      src={`https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`}
      alt={alt}
      className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1100ms] ease-out group-hover:scale-[1.05]"
      draggable={false}
    />
  );
}

function ChannelCard() {
  return (
    <a
      href={BROSONROADS.social.youtube}
      target="_blank"
      rel="noopener noreferrer"
      className="group relative flex aspect-video flex-col items-center justify-center gap-4 overflow-hidden border border-white/15 bg-[#151515] transition-colors duration-500 hover:border-[#D97F3E]/60"
      aria-label="Watch more on the BrosonRoads YouTube channel"
    >
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-white/10 transition-colors duration-500 group-hover:bg-[#D97F3E]">
        <Users className="h-6 w-6 text-white" strokeWidth={1.25} />
      </span>
      <p className="display-title px-6 text-center text-lg font-bold text-white">
        More films on the channel
      </p>
      <p className="flex items-center gap-2 text-[11px] uppercase tracking-[0.22em] text-[#929292] transition-colors group-hover:text-[#D7D7D7]">
        youtube.com/{BROSONROADS.social.youtubeHandle}
        <ArrowUpRight className="h-3.5 w-3.5" strokeWidth={1.5} />
      </p>
    </a>
  );
}

function VideoCard({ video, onPlay }: { video: VideoItem; onPlay: (v: VideoItem) => void }) {
  return (
    <div className="group relative overflow-hidden bg-[#151515]">
      <button
        onClick={() => onPlay(video)}
        className="block w-full text-left"
        aria-label={`Play video: ${video.title}`}
      >
        <div className="relative aspect-video w-full overflow-hidden">
          <YouTubeThumb videoId={video.id} alt={`YouTube thumbnail — ${video.title}`} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" aria-hidden="true" />
          {/* Play badge */}
          <span className="absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-white/40 bg-black/40 backdrop-blur-sm transition-all duration-500 group-hover:scale-110 group-hover:border-[#D97F3E] group-hover:bg-[#D97F3E]">
            <Play className="ml-0.5 h-5 w-5 fill-white text-white" strokeWidth={0} />
          </span>
          <span className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center bg-black/60 text-white backdrop-blur-sm">
            <Youtube className="h-4 w-4" strokeWidth={1.5} />
          </span>
        </div>
        <div className="p-5">
          <p className="eyebrow mb-2">{video.location}</p>
          <h3 className="display-title line-clamp-2 text-base font-bold text-white transition-colors duration-300 group-hover:text-[#D7D7D7]">
            {video.title}
          </h3>
          <p className="mt-2 line-clamp-2 text-[13px] leading-relaxed text-[#929292]">
            {video.description}
          </p>
        </div>
      </button>
    </div>
  );
}

export function YouTubeSection() {
  const [playing, setPlaying] = useState<VideoItem | null>(null);

  return (
    <section id="watch" aria-labelledby="watch-heading" className="bg-[#0B0B0B] py-24 md:py-36">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
        <div className="mb-14 flex flex-col gap-6 md:mb-16 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <p className="eyebrow mb-4">05 — YouTube</p>
            <h2 id="watch-heading" className="display-title text-4xl font-bold text-white sm:text-5xl md:text-6xl">
              Watch The<br />
              <span className="text-outline">Journey</span>
            </h2>
          </Reveal>
          <Reveal delay={120}>
            <p className="max-w-sm text-sm leading-relaxed text-[#929292] md:text-right">
              The roads look different when you experience them from behind the bars.
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-3 md:gap-6">
          {VIDEOS.map((video, i) => (
            <Reveal key={video.id} delay={i * 90}>
              <VideoCard video={video} onPlay={setPlaying} />
            </Reveal>
          ))}
          <Reveal delay={VIDEOS.length * 90}>
            <ChannelCard />
          </Reveal>
        </div>

        <Reveal delay={150} className="mt-12 flex justify-center">
          <a
            href={BROSONROADS.social.youtube}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-3 bg-white px-8 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-black transition-colors duration-300 hover:bg-[#D97F3E]"
          >
            <Youtube className="h-4 w-4" strokeWidth={1.75} />
            Subscribe on YouTube
            <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" strokeWidth={1.5} />
          </a>
        </Reveal>
      </div>

      <VideoModal
        open={playing !== null}
        onClose={() => setPlaying(null)}
        videoId={playing?.id ?? ""}
        title={playing?.title ?? ""}
        caption={playing?.description}
      />
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  INSTAGRAM SECTION — curated cards → real profile links             */
/*  To go live later: replace each card with the official Instagram    */
/*  embed snippet inside this grid; the data structure already         */
/*  carries an optional `permalink` per post.                          */
/* ------------------------------------------------------------------ */

export function InstagramSection() {
  return (
    <section id="instagram" aria-labelledby="instagram-heading" className="bg-[#F5F4F0] py-24 md:py-32">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 md:px-10">
        <div className="mb-14 flex flex-col gap-6 md:mb-16 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <p className="eyebrow eyebrow-dark mb-4">06 — Instagram</p>
            <h2 id="instagram-heading" className="display-title text-4xl font-bold text-[#111111] sm:text-5xl md:text-6xl">
              Follow The<br />
              <span className="text-outline-dark">Journey</span>
            </h2>
          </Reveal>
          <Reveal delay={120}>
            <a
              href={BROSONROADS.social.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2 text-lg font-medium text-[#111111] transition-colors hover:text-[#D97F3E] md:text-xl"
            >
              <Instagram className="h-5 w-5" strokeWidth={1.5} />
              {BROSONROADS.social.instagramHandle}
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" strokeWidth={1.5} />
            </a>
          </Reveal>
        </div>

        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:gap-3 lg:grid-cols-4">
          {INSTAGRAM_POSTS.map((post, i) => (
            <Reveal
              key={post.src}
              as="a"
              href={post.permalink ?? BROSONROADS.social.instagram}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`View on Instagram: ${post.alt}`}
              variant="image"
              delay={(i % 4) * 60}
              className="group relative block aspect-square overflow-hidden bg-[#E8E6E1]"
            >
              <SafeImage
                src={post.src}
                alt={post.alt}
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1000ms] ease-out group-hover:scale-[1.08]"
                draggable={false}
              />
              <div
                className="absolute inset-0 flex items-center justify-center bg-black/45 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                aria-hidden="true"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full border border-white/50 text-white backdrop-blur-sm">
                  <Instagram className="h-4.5 w-4.5" strokeWidth={1.5} />
                </span>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={140} className="mt-12 flex justify-center">
          <a
            href={BROSONROADS.social.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-3 border border-black/25 px-8 py-4 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#111111] transition-all duration-300 hover:border-[#111111] hover:bg-[#111111] hover:text-white"
          >
            <Instagram className="h-4 w-4" strokeWidth={1.75} />
            Follow on Instagram
            <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" strokeWidth={1.5} />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
